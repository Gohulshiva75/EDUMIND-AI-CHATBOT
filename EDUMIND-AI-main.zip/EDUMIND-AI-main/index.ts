// Core Domain Types for Edumind AI - Universal Academic Student Companion

export type TutorMode = 'socratic' | 'deepExplanation' | 'designThinking' | 'examPrep';

export type AcademicSubject = 
  | 'Mathematics'
  | 'Physics & Astronomy'
  | 'Chemistry & BioChem'
  | 'Biology & Medicine'
  | 'Computer Science & AI'
  | 'History & Social Studies'
  | 'Literature & Philosophy'
  | 'Economics & Business'
  | 'Engineering'
  | 'General Academia';

export interface StudentProfile {
  name: string;
  major: string;
  activeSubject: AcademicSubject;
  targetExamOrGoal: string;
  experienceLevel: 'Beginner' | 'Intermediate' | 'Advanced';
  preferredLearningStyle: 'Visual & Conceptual' | 'Step-by-Step Problem Solving' | 'Socratic & Discussion' | 'Exam-Cram & High-Yield';
  streakDays: number;
  totalStudyMinutes: number;
  completedTasksCount: number;
  masteryScores: {
    conceptualUnderstanding: number;
    analyticalProblemSolving: number;
    criticalThinking: number;
    retentionAndRecall: number;
    designThinkingMethod: number;
    examReadiness: number;
  };
  testHistory?: TestAttemptResult[];
}

export interface SubjectTestQuestion {
  id: string;
  questionText: string;
  snippetOrFormula?: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  conceptTag: string;
  marks: number;
  difficulty: 'Easy' | 'Medium' | 'Hard';
}

export interface SubjectTest {
  id: string;
  title: string;
  subject: AcademicSubject;
  durationMinutes: number;
  totalMarks: number;
  passingMarks: number;
  description: string;
  instructions: string[];
  questions: SubjectTestQuestion[];
}

export interface TopicPerformance {
  topic: string;
  marksObtained: number;
  totalMarks: number;
  percentage: number;
}

export interface TestAttemptResult {
  id: string;
  testId: string;
  testTitle: string;
  subject: AcademicSubject;
  date: string;
  timestamp: number;
  timeSpentSeconds: number;
  marksObtained: number;
  totalMarks: number;
  percentage: number;
  grade: string;
  isPassed: boolean;
  accuracy: number;
  answers: Record<string, number>;
  topicBreakdown: TopicPerformance[];
  strengths: string[];
  weaknesses: string[];
  questions: SubjectTestQuestion[];
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
  mode?: TutorMode;
  subject?: AcademicSubject;
  codeSnippets?: { language: string; code: string; title?: string }[];
  suggestedFollowUps?: string[];
  designThinkingPhase?: 'Empathize' | 'Define' | 'Ideate' | 'Prototype' | 'Test';
}

export interface StudyPlanModule {
  day: number;
  topic: string;
  description: string;
  estimatedMinutes: number;
  learningObjectives: string[];
  practiceTask: string;
  keyQuestions?: string[];
  completed?: boolean;
}

export interface StudyPlanPhase {
  phaseNumber: number;
  phaseName: string;
  focus: string;
  daysSpan: string;
  modules: StudyPlanModule[];
}

export interface StudyPlan {
  id: string;
  title: string;
  subject: string;
  overview: string;
  totalEstimatedHours: number;
  methodology: string;
  phases: StudyPlanPhase[];
  tipsForSuccess: string[];
  createdAt: string;
}

export interface QuizQuestion {
  id: string;
  subject?: string;
  questionText: string;
  snippetOrFormula?: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  conceptTag: string;
  studentSelectedIndex?: number;
}

export interface Flashcard {
  id: string;
  subject: AcademicSubject | string;
  category: string;
  front: string;
  back: string;
  formulaOrExample?: string;
  mastered?: boolean;
}

export interface DesignThinkingArtifact {
  phase: 'Empathize' | 'Define' | 'Ideate' | 'Prototype' | 'Test';
  academicTopicOrProblem: string;
  subject: string;
  notes: string;
  empathyInsights?: {
    confusionPoints: string[];
    mentalBlockers: string[];
    context: string[];
  };
  hmwStatements: string[];
  ideas: { id: string; text: string; category: string; votes: number }[];
  prototypeNotes: string;
  testValidationCriteria: string[];
}

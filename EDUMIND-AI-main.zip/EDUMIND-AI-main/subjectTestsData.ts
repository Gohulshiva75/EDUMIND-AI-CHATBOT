import { AcademicSubject } from '../types';

export interface SubjectTestQuestion {
  id: string;
  questionText: string;
  snippetOrFormula?: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  conceptTag: string;
  marks: number;
  difficulty: 'Easy' | 'Medium' | 'Hard';
}

export interface SubjectTest {
  id: string;
  title: string;
  subject: AcademicSubject;
  durationMinutes: number;
  totalMarks: number;
  passingMarks: number;
  description: string;
  instructions: string[];
  questions: SubjectTestQuestion[];
}

export const CURATED_SUBJECT_TESTS: Record<AcademicSubject, SubjectTest> = {
  'Mathematics': {
    id: 'test-math-core',
    title: 'Advanced Mathematics: Calculus & Linear Algebra Mastery Exam',
    subject: 'Mathematics',
    durationMinutes: 15,
    totalMarks: 30,
    passingMarks: 18,
    description: 'Comprehensive diagnostic evaluation covering differentiation, integration, matrix eigenvalues, and optimization theorems.',
    instructions: [
      'Each question carries specified marks based on conceptual depth.',
      'Mathematical formulas are rendered in rigorous LaTeX notation.',
      'Select the most precise mathematical answer among the options.'
    ],
    questions: [
      {
        id: 'math-q1',
        questionText: 'Consider the function $f(x) = x^3 - 6x^2 + 9x + 2$. At which point does $f(x)$ attain a local maximum?',
        snippetOrFormula: 'f\'(x) = 3x^2 - 12x + 9 = 0',
        options: [
          '$x = 1$',
          '$x = 3$',
          '$x = 2$',
          '$x = 0$'
        ],
        correctIndex: 0,
        explanation: 'Taking the first derivative: $f\'(x) = 3(x-1)(x-3) = 0$, giving critical points at $x = 1$ and $x = 3$. The second derivative is $f\'\'(x) = 6x - 12$. Evaluating at $x = 1$: $f\'\'(1) = -6 < 0$, which proves a local maximum at $x = 1$.',
        conceptTag: 'Calculus & Optimization',
        marks: 6,
        difficulty: 'Medium'
      },
      {
        id: 'math-q2',
        questionText: 'What is the value of the definite integral $\\int_{0}^{\\pi/2} \\sin^2(x) \\, dx$?',
        snippetOrFormula: '\\sin^2(x) = \\frac{1 - \\cos(2x)}{2}',
        options: [
          '$\\frac{\\pi}{4}$',
          '$\\frac{\\pi}{2}$',
          '$1$',
          '$\\frac{1}{2}$'
        ],
        correctIndex: 0,
        explanation: 'Using the half-angle identity $\\sin^2(x) = \\frac{1 - \\cos(2x)}{2}$: $\\int_0^{\\pi/2} \\frac{1 - \\cos(2x)}{2} dx = \\left[ \\frac{x}{2} - \\frac{\\sin(2x)}{4} \\right]_0^{\\pi/2} = \\frac{\\pi}{4} - 0 = \\frac{\\pi}{4}$.',
        conceptTag: 'Integral Calculus',
        marks: 6,
        difficulty: 'Medium'
      },
      {
        id: 'math-q3',
        questionText: 'For a $2 \\times 2$ matrix $A = \\begin{pmatrix} 4 & 1 \\\\ 2 & 3 \\end{pmatrix}$, what are its eigenvalues $\\lambda$?',
        snippetOrFormula: '\\det(A - \\lambda I) = (4-\\lambda)(3-\\lambda) - 2 = 0',
        options: [
          '$\\lambda = 5$ and $\\lambda = 2$',
          '$\\lambda = 4$ and $\\lambda = 3$',
          '$\\lambda = 6$ and $\\lambda = 1$',
          '$\\lambda = 3$ and $\\lambda = 2$'
        ],
        correctIndex: 0,
        explanation: 'The characteristic polynomial is $\\lambda^2 - \\text{tr}(A)\\lambda + \\det(A) = \\lambda^2 - 7\\lambda + (12 - 2) = \\lambda^2 - 7\\lambda + 10 = 0$. Factoring gives $(\\lambda - 5)(\\lambda - 2) = 0$, so $\\lambda = 5, 2$.',
        conceptTag: 'Linear Algebra',
        marks: 6,
        difficulty: 'Hard'
      },
      {
        id: 'math-q4',
        questionText: 'What is the limit $\\lim_{x \\to 0} \\frac{e^{2x} - 1 - 2x}{x^2}$?',
        snippetOrFormula: '\\text{Apply L\'Hôpital\'s Rule or Taylor Expansion}',
        options: [
          '$2$',
          '$1$',
          '$4$',
          'Does not exist'
        ],
        correctIndex: 0,
        explanation: 'Using Taylor expansion $e^{2x} = 1 + 2x + \\frac{(2x)^2}{2!} + \\dots = 1 + 2x + 2x^2 + O(x^3)$. Then numerator is $2x^2 + O(x^3)$. Dividing by $x^2$ gives limit $2$. Or apply L\'Hôpital\'s Rule twice.',
        conceptTag: 'Limits & Series',
        marks: 6,
        difficulty: 'Medium'
      },
      {
        id: 'math-q5',
        questionText: 'In probability, if random variable $X \\sim \\text{Poisson}(\\lambda = 3)$, what is the variance $\\text{Var}(X)$?',
        snippetOrFormula: '\\text{Poisson Distribution Properties}',
        options: [
          '$3$',
          '$9$',
          '$\\sqrt{3}$',
          '$6$'
        ],
        correctIndex: 0,
        explanation: 'For any Poisson distribution with parameter $\\lambda$, both the mean and the variance are identically equal to $\\lambda$. Thus $\\text{Var}(X) = 3$.',
        conceptTag: 'Probability & Statistics',
        marks: 6,
        difficulty: 'Easy'
      }
    ]
  },

  'Physics & Astronomy': {
    id: 'test-physics-core',
    title: 'Physics & Astronomy: Mechanics, Thermodynamics & Quantum Exam',
    subject: 'Physics & Astronomy',
    durationMinutes: 15,
    totalMarks: 30,
    passingMarks: 18,
    description: 'Comprehensive diagnostic test evaluating core physical laws, thermodynamics, gravitational mechanics, and quantum concepts.',
    instructions: [
      'Apply first-principles conservation laws and dimensional analysis.',
      'SI units are assumed for all numerical parameters.'
    ],
    questions: [
      {
        id: 'phys-q1',
        questionText: 'A rocket of initial mass $m_0$ ejects fuel at constant exhaust velocity $v_e$. According to Tsiolkovsky\'s rocket equation, what is the final velocity $\\Delta v$ when mass decreases to $m_f$?',
        snippetOrFormula: '\\Delta v = v_e \\ln\\left(\\frac{m_0}{m_f}\\right)',
        options: [
          '$\\Delta v = v_e \\ln(m_0 / m_f)$',
          '$\\Delta v = v_e (m_0 - m_f) / m_0$',
          '$\\Delta v = \\frac{1}{2} v_e (m_0 / m_f)^2$',
          '$\\Delta v = g \\cdot t \\cdot (m_0 / m_f)$'
        ],
        correctIndex: 0,
        explanation: 'From momentum conservation $m \\, dv = -v_e \\, dm$, integrating from $m_0$ to $m_f$ yields Tsiolkovsky\'s rocket equation: $\\Delta v = v_e \\ln(m_0 / m_f)$.',
        conceptTag: 'Classical Mechanics & Momentum',
        marks: 6,
        difficulty: 'Medium'
      },
      {
        id: 'phys-q2',
        questionText: 'A reversible heat engine operates between temperatures $T_H = 600\\text{ K}$ and $T_C = 300\\text{ K}$. If it absorbs $1200\\text{ J}$ of heat from the hot reservoir, what is the work output $W$?',
        snippetOrFormula: '\\eta_{\\text{Carnot}} = 1 - \\frac{T_C}{T_H} = \\frac{W}{Q_H}',
        options: [
          '$600\\text{ J}$',
          '$400\\text{ J}$',
          '$900\\text{ J}$',
          '$300\\text{ J}$'
        ],
        correctIndex: 0,
        explanation: 'Carnot efficiency is $\\eta = 1 - (300/600) = 0.50$ (50%). The work output is $W = \\eta \\cdot Q_H = 0.50 \\times 1200\\text{ J} = 600\\text{ J}$.',
        conceptTag: 'Thermodynamics & Heat Engines',
        marks: 6,
        difficulty: 'Easy'
      },
      {
        id: 'phys-q3',
        questionText: 'According to de Broglie\'s hypothesis, what is the wavelength $\\lambda$ associated with a particle having linear momentum $p$?',
        snippetOrFormula: '\\lambda = \\frac{h}{p}',
        options: [
          '$\\lambda = \\frac{h}{p}$',
          '$\\lambda = \\frac{p}{h}$',
          '$\\lambda = h \\cdot p$',
          '$\\lambda = \\frac{\\hbar}{2p}$'
        ],
        correctIndex: 0,
        explanation: 'De Broglie postulated that matter exhibits wave-particle duality with wavelength inversely proportional to momentum: $\\lambda = h / p$, where $h$ is Planck\'s constant.',
        conceptTag: 'Quantum Physics',
        marks: 6,
        difficulty: 'Easy'
      },
      {
        id: 'phys-q4',
        questionText: 'A satellite orbits Earth in a circular orbit of radius $R$ with speed $v$. If the orbital radius is quadrupled to $4R$, what is the new orbital speed?',
        snippetOrFormula: 'v = \\sqrt{\\frac{GM}{R}}',
        options: [
          '$v / 2$',
          '$v / 4$',
          '$2v$',
          '$v$'
        ],
        correctIndex: 0,
        explanation: 'Orbital velocity is $v = \\sqrt{GM/R}$. When $R\' = 4R$, $v\' = \\sqrt{GM/(4R)} = \\frac{1}{2}\\sqrt{GM/R} = v/2$.',
        conceptTag: 'Gravitation & Astrophysics',
        marks: 6,
        difficulty: 'Medium'
      },
      {
        id: 'phys-q5',
        questionText: 'In electromagnetic induction, what does Lenz\'s Law state regarding the direction of the induced current?',
        snippetOrFormula: '\\mathcal{E} = -\\frac{d\\Phi_B}{dt}',
        options: [
          'The induced current always opposes the change in magnetic flux that produces it',
          'The induced current always amplifies the magnetic field',
          'The current flows in the direction of the electric field gradient',
          'The induced electromotive force is independent of flux rate'
        ],
        correctIndex: 0,
        explanation: 'Lenz\'s law, reflected by the negative sign in Faraday\'s law $\\mathcal{E} = -d\\Phi_B/dt$, is a consequence of conservation of energy: the induced current produces a magnetic field that opposes the flux change.',
        conceptTag: 'Electromagnetism',
        marks: 6,
        difficulty: 'Medium'
      }
    ]
  },

  'Chemistry & BioChem': {
    id: 'test-chem-core',
    title: 'Chemistry & BioChem: Equilibrium, Kinetics & Molecular Bonding Test',
    subject: 'Chemistry & BioChem',
    durationMinutes: 15,
    totalMarks: 30,
    passingMarks: 18,
    description: 'Assesses mastery of chemical thermodynamics, reaction kinetics, acid-base equilibria, and molecular orbital theory.',
    instructions: [
      'Use Le Chatelier\'s principle and Gibbs free energy relationships.'
    ],
    questions: [
      {
        id: 'chem-q1',
        questionText: 'For an exothermic reaction at equilibrium: $N_2(g) + 3H_2(g) \\rightleftharpoons 2NH_3(g) \\quad (\\Delta H < 0)$, what occurs if temperature is increased at constant volume?',
        snippetOrFormula: '\\text{Le Chatelier\'s Principle}',
        options: [
          'Equilibrium shifts left toward reactants, decreasing $K_{eq}$',
          'Equilibrium shifts right toward products, increasing $K_{eq}$',
          'No change in equilibrium position occurs',
          'Total pressure drops to zero'
        ],
        correctIndex: 0,
        explanation: 'Since the reaction is exothermic, heat is a product. Adding heat shifts the equilibrium left to consume heat, decreasing the equilibrium constant $K_{eq}$.',
        conceptTag: 'Chemical Equilibrium',
        marks: 6,
        difficulty: 'Medium'
      },
      {
        id: 'chem-q2',
        questionText: 'If a chemical reaction has $\\Delta H > 0$ (endothermic) and $\\Delta S > 0$ (increasing disorder), under what temperature conditions will it be thermodynamically spontaneous?',
        snippetOrFormula: '\\Delta G = \\Delta H - T\\Delta S < 0',
        options: [
          'Only at sufficiently high temperatures ($T > \\Delta H / \\Delta S$)',
          'Only at low temperatures',
          'At all temperatures',
          'Never spontaneous'
        ],
        correctIndex: 0,
        explanation: 'For $\\Delta G = \\Delta H - T\\Delta S$ to be negative, the $T\\Delta S$ term must exceed $\\Delta H$, which requires sufficiently high temperature ($T > \\Delta H / \\Delta S$).',
        conceptTag: 'Thermodynamics & Spontaneity',
        marks: 6,
        difficulty: 'Medium'
      },
      {
        id: 'chem-q3',
        questionText: 'What is the pH of a $0.001\\text{ M}$ solution of hydrochloric acid ($\\text{HCl}$) at $25^\\circ\\text{C}$?',
        snippetOrFormula: '\\text{pH} = -\\log_{10}[\\text{H}^+]',
        options: [
          '$3.0$',
          '$1.0$',
          '$11.0$',
          '$7.0$'
        ],
        correctIndex: 0,
        explanation: '$\\text{HCl}$ is a strong monoprotic acid that fully dissociates: $[\\text{H}^+] = 10^{-3}\\text{ M}$. Therefore $\\text{pH} = -\\log_{10}(10^{-3}) = 3.0$.',
        conceptTag: 'Acid-Base Equilibria',
        marks: 6,
        difficulty: 'Easy'
      },
      {
        id: 'chem-q4',
        questionText: 'According to VSEPR theory, what is the molecular geometry of sulfur hexafluoride ($\\text{SF}_6$)?',
        snippetOrFormula: '\\text{Steric Number} = 6 \\text{ bonding pairs, } 0 \\text{ lone pairs}',
        options: [
          'Octahedral',
          'Trigonal bipyramidal',
          'Tetrahedral',
          'Square planar'
        ],
        correctIndex: 0,
        explanation: '$\\text{SF}_6$ has 6 bonding pairs around the central sulfur atom with no lone pairs (steric number 6, $sp^3d^2$ hybridization), giving a regular octahedral geometry with $90^\\circ$ bond angles.',
        conceptTag: 'Molecular Structure & Bonding',
        marks: 6,
        difficulty: 'Easy'
      },
      {
        id: 'chem-q5',
        questionText: 'For a second-order reaction $2A \\to B$, a plot of which variable versus time yields a straight line?',
        snippetOrFormula: '\\frac{1}{[A]_t} = kt + \\frac{1}{[A]_0}',
        options: [
          '$1/[A]$ versus time',
          '$\\ln[A]$ versus time',
          '$[A]$ versus time',
          '$[A]^2$ versus time'
        ],
        correctIndex: 0,
        explanation: 'The integrated rate law for a second-order reaction is $1/[A]_t = kt + 1/[A]_0$. Hence, plotting $1/[A]$ against time $t$ gives a straight line with slope $k$.',
        conceptTag: 'Reaction Kinetics',
        marks: 6,
        difficulty: 'Hard'
      }
    ]
  },

  'Biology & Medicine': {
    id: 'test-bio-core',
    title: 'Biology & Medicine: Genetics, Cellular Bioenergetics & Anatomy Exam',
    subject: 'Biology & Medicine',
    durationMinutes: 15,
    totalMarks: 30,
    passingMarks: 18,
    description: 'Rigorous assessment covering molecular genetics, cellular respiration, enzymatic kinetics, and organ system physiology.',
    instructions: [
      'Focus on molecular mechanisms and physiological feedback loops.'
    ],
    questions: [
      {
        id: 'bio-q1',
        questionText: 'During aerobic cellular respiration, which complex in the electron transport chain (ETC) directly reduces molecular oxygen ($O_2$) to water ($H_2O$)?',
        snippetOrFormula: 'O_2 + 4H^+ + 4e^- \\to 2H_2O',
        options: [
          'Complex IV (Cytochrome c oxidase)',
          'Complex I (NADH dehydrogenase)',
          'Complex II (Succinate dehydrogenase)',
          'Complex III (Cytochrome bc1)'
        ],
        correctIndex: 0,
        explanation: 'Complex IV (Cytochrome c oxidase) transfers electrons from Cytochrome c to terminal molecular oxygen, reducing it to form water while pumping protons into the intermembrane space.',
        conceptTag: 'Cellular Bioenergetics',
        marks: 6,
        difficulty: 'Medium'
      },
      {
        id: 'bio-q2',
        questionText: 'In DNA replication, which enzyme removes RNA primers and replaces them with deoxyribonucleotides in prokaryotes?',
        snippetOrFormula: '5\' \\to 3\' \\text{ exonuclease activity}',
        options: [
          'DNA Polymerase I',
          'DNA Polymerase III',
          'Helicase',
          'DNA Ligase'
        ],
        correctIndex: 0,
        explanation: 'DNA Polymerase I utilizes its 5\' to 3\' exonuclease activity to degrade RNA primers and fills the resulting gaps with DNA nucleotides. DNA Ligase then seals the nick in the phosphodiester backbone.',
        conceptTag: 'Molecular Genetics',
        marks: 6,
        difficulty: 'Medium'
      },
      {
        id: 'bio-q3',
        questionText: 'In human renal physiology, which nephron segment is the primary site for the reabsorption of the majority of filtered water, sodium, and 100% of filtered glucose?',
        snippetOrFormula: '\\text{Nephron Filtration & Transport}',
        options: [
          'Proximal Convoluted Tubule (PCT)',
          'Loop of Henle (descending limb)',
          'Distal Convoluted Tubule (DCT)',
          'Collecting Duct'
        ],
        correctIndex: 0,
        explanation: 'The proximal convoluted tubule reabsorbs ~65-70% of filtered water and sodium, and virtually 100% of filtered glucose and amino acids via secondary active transport with sodium symporters (SGLT2).',
        conceptTag: 'Human Organ Physiology',
        marks: 6,
        difficulty: 'Medium'
      },
      {
        id: 'bio-q4',
        questionText: 'How does a competitive enzyme inhibitor affect the maximum reaction velocity ($V_{\\max}$) and the Michaelis constant ($K_m$)?',
        snippetOrFormula: '\\text{Lineweaver-Burk Kinetics}',
        options: [
          '$V_{\\max}$ remains unchanged; $K_m$ increases',
          '$V_{\\max}$ decreases; $K_m$ remains unchanged',
          'Both $V_{\\max}$ and $K_m$ decrease',
          'Both $V_{\\max}$ and $K_m$ increase'
        ],
        correctIndex: 0,
        explanation: 'A competitive inhibitor binds reversibly to the active site. With high substrate concentration, inhibition is overcome, so $V_{\\max}$ is unchanged, but higher substrate is needed for half-maximal speed, increasing apparent $K_m$.',
        conceptTag: 'Enzymology & Kinetics',
        marks: 6,
        difficulty: 'Hard'
      },
      {
        id: 'bio-q5',
        questionText: 'What is the primary immunological mechanism of mRNA vaccines (such as for SARS-CoV-2)?',
        snippetOrFormula: '\\text{Antigen Presentation & Adaptive Immunity}',
        options: [
          'Host ribosomes translate mRNA into harmless viral antigen proteins, triggering B-cell and T-cell adaptive immunity',
          'mRNA incorporates permanently into the host genomic DNA inside the nucleus',
          'mRNA directly destroys viral particles like an antibiotic',
          'mRNA serves as passive donor antibodies'
        ],
        correctIndex: 0,
        explanation: 'mRNA vaccines deliver lipid nanoparticles containing transcript sequences. Host cell ribosomes translate the viral spike protein, which is presented on MHC molecules, training memory B-cells and cytotoxic T-cells without altering host DNA.',
        conceptTag: 'Immunology & Pathology',
        marks: 6,
        difficulty: 'Easy'
      }
    ]
  },

  'Computer Science & AI': {
    id: 'test-cs-core',
    title: 'Computer Science & AI: Algorithms, Complexity & Machine Learning Exam',
    subject: 'Computer Science & AI',
    durationMinutes: 15,
    totalMarks: 30,
    passingMarks: 18,
    description: 'Evaluates proficiency in asymptotic complexity, dynamic programming, tree traversals, and modern neural network architectures.',
    instructions: [
      'Analyze worst-case Big-O runtime and computational trade-offs.'
    ],
    questions: [
      {
        id: 'cs-q1',
        questionText: 'What is the worst-case time complexity of searching for an element in a self-balancing binary search tree (such as a Red-Black Tree or AVL Tree) with $N$ nodes?',
        snippetOrFormula: 'T(N) = O(\\log N)',
        options: [
          '$O(\\log N)$',
          '$O(N)$',
          '$O(1)$',
          '$O(N \\log N)$'
        ],
        correctIndex: 0,
        explanation: 'Self-balancing binary search trees enforce height invariance $h \\le c \\log_2 N$. Consequently, search, insertion, and deletion operations are strictly bounded by $O(\\log N)$ in the worst case.',
        conceptTag: 'Data Structures & Trees',
        marks: 6,
        difficulty: 'Easy'
      },
      {
        id: 'cs-q2',
        questionText: 'In the Transformer neural network architecture (Vaswani et al., 2017), what is the computational complexity of the scaled dot-product Self-Attention mechanism with respect to sequence length $N$?',
        snippetOrFormula: '\\text{Attention}(Q, K, V) = \\text{softmax}\\left(\\frac{QK^T}{\\sqrt{d_k}}\\right)V',
        options: [
          '$O(N^2)$ with respect to sequence length $N$',
          '$O(N)$ linear with sequence length',
          '$O(N \\log N)$',
          '$O(1)$ constant time'
        ],
        correctIndex: 0,
        explanation: 'Computing the product $Q K^T$ involves an $(N \\times d) \\times (d \\times N)$ matrix multiplication, producing an $N \\times N$ attention matrix. This gives quadratic $O(N^2)$ complexity with sequence length.',
        conceptTag: 'Machine Learning & Transformers',
        marks: 6,
        difficulty: 'Medium'
      },
      {
        id: 'cs-q3',
        questionText: 'Which sorting algorithm has guaranteed worst-case time complexity of $O(N \\log N)$ while performing sorting in-place with $O(1)$ auxiliary memory?',
        snippetOrFormula: '\\text{Asymptotic Sorting Bounds}',
        options: [
          'Heapsort',
          'Mergesort',
          'Quicksort',
          'Insertion Sort'
        ],
        correctIndex: 0,
        explanation: 'Heapsort builds a binary max-heap in $O(N)$ and repeatedly extracts the root in $O(\\log N)$, guaranteeing $O(N \\log N)$ worst-case time with $O(1)$ auxiliary space. Mergesort requires $O(N)$ auxiliary space, and standard Quicksort is $O(N^2)$ in the worst case.',
        conceptTag: 'Algorithm Design & Analysis',
        marks: 6,
        difficulty: 'Hard'
      },
      {
        id: 'cs-q4',
        questionText: 'What is the key principle of Dynamic Programming that distinguishes it from simple divide-and-conquer?',
        snippetOrFormula: '\\text{Bellman Optimality & Memoization}',
        options: [
          'Optimal substructure combined with overlapping subproblems (memoization/tabulation)',
          'Greedy local choice at every step',
          'Randomized pivot selection',
          'Breadth-first frontier expansion'
        ],
        correctIndex: 0,
        explanation: 'Dynamic programming requires two key properties: optimal substructure (optimal solution to the problem contains optimal solutions to subproblems) and overlapping subproblems (avoiding exponential recomputation by storing results).',
        conceptTag: 'Dynamic Programming',
        marks: 6,
        difficulty: 'Medium'
      },
      {
        id: 'cs-q5',
        questionText: 'In relational database theory, which normal form (NF) ensures that every non-key attribute is non-transitively dependent on the primary key?',
        snippetOrFormula: 'X \\to Y \\text{ where } X \\text{ is a superkey}',
        options: [
          'Third Normal Form (3NF)',
          'First Normal Form (1NF)',
          'Second Normal Form (2NF)',
          'Unnormalized Form'
        ],
        correctIndex: 0,
        explanation: 'Third Normal Form (3NF) requires 2NF and additionally eliminates transitive functional dependencies: no non-prime attribute may depend transitively on the primary key.',
        conceptTag: 'Database Architecture',
        marks: 6,
        difficulty: 'Medium'
      }
    ]
  },

  'Economics & Business': {
    id: 'test-econ-core',
    title: 'Economics & Business: Micro, Macro & Strategic Finance Exam',
    subject: 'Economics & Business',
    durationMinutes: 15,
    totalMarks: 30,
    passingMarks: 18,
    description: 'Diagnostic assessment covering market equilibrium, elasticity, fiscal/monetary policy, and game-theoretic strategy.',
    instructions: [
      'Apply economic axioms, marginal reasoning, and equilibrium models.'
    ],
    questions: [
      {
        id: 'econ-q1',
        questionText: 'If the price elasticity of demand for a product is $\\epsilon_d = -2.5$, what will happen to total revenue if the firm raises its price by $10\\%$?',
        snippetOrFormula: '\\%\\Delta Q = \\epsilon_d \\times \\%\\Delta P',
        options: [
          'Total revenue will decrease, because quantity demanded drops by $25\\%$',
          'Total revenue will increase by $15\\%$',
          'Total revenue will remain unchanged',
          'Quantity demanded increases by $25\\%$'
        ],
        correctIndex: 0,
        explanation: 'Demand is elastic ($|\\epsilon_d| > 1$). A $10\\%$ price increase causes quantity demanded to plunge by $2.5 \\times 10\\% = 25\\%$. The drop in volume heavily outweighs the price gain, shrinking total revenue.',
        conceptTag: 'Elasticity & Demand Theory',
        marks: 6,
        difficulty: 'Medium'
      },
      {
        id: 'econ-q2',
        questionText: 'In game theory, what defines a Nash Equilibrium in a simultaneous-move game?',
        snippetOrFormula: 'u_i(s_i^*, s_{-i}^*) \\ge u_i(s_i, s_{-i}^*) \\quad \\forall s_i \\in S_i',
        options: [
          'A state where no player can unilaterally deviate and increase their payoff',
          'A state that maximizes the sum of all players\' total utilities',
          'A state where both players make random randomized moves',
          'A state where the first player receives maximum possible payoff'
        ],
        correctIndex: 0,
        explanation: 'A Nash Equilibrium is a set of strategies where each player\'s strategy is an optimal response to the other players\' strategies; no single player has an incentive to unilaterally switch strategies.',
        conceptTag: 'Game Theory & Strategy',
        marks: 6,
        difficulty: 'Easy'
      },
      {
        id: 'econ-q3',
        questionText: 'When a central bank engages in expansionary monetary policy by conducting open market operations to purchase government bonds, what is the immediate effect on the money supply and interest rates?',
        snippetOrFormula: '\\text{Central Bank Operations}',
        options: [
          'Money supply increases; short-term interest rates fall',
          'Money supply decreases; interest rates rise',
          'Money supply and interest rates both increase',
          'Inflation drops to zero immediately'
        ],
        correctIndex: 0,
        explanation: 'Buying bonds injects bank reserves into the banking system, expanding the money supply. Higher supply of loanable funds drives down short-term benchmark interest rates.',
        conceptTag: 'Macroeconomics & Monetary Policy',
        marks: 6,
        difficulty: 'Medium'
      },
      {
        id: 'econ-q4',
        questionText: 'What is the opportunity cost of an economic decision?',
        snippetOrFormula: '\\text{Opportunity Cost Definition}',
        options: [
          'The value of the next best alternative foregone when a choice is made',
          'The accounting money expenditure incurred',
          'The sunk cost of past investments',
          'The marginal tax rate of the transaction'
        ],
        correctIndex: 0,
        explanation: 'Opportunity cost represents the prospective benefit or utility that an individual or business misses out on when choosing one alternative over the next best alternative.',
        conceptTag: 'Foundational Microeconomics',
        marks: 6,
        difficulty: 'Easy'
      },
      {
        id: 'econ-q5',
        questionText: 'In corporate finance, what does the Capital Asset Pricing Model (CAPM) determine?',
        snippetOrFormula: 'E(R_i) = R_f + \\beta_i(E(R_m) - R_f)',
        options: [
          'The expected return of an asset based on its systematic risk (beta) relative to the market',
          'The liquidation book value of corporate inventory',
          'The foreign currency exchange rate parity',
          'The exact default probability of high-yield debt'
        ],
        correctIndex: 0,
        explanation: 'CAPM calculates the expected return on equity: $E(R) = R_f + \\beta (E(R_m) - R_f)$, linking expected return directly to non-diversifiable systematic risk (beta).',
        conceptTag: 'Corporate Finance & Risk',
        marks: 6,
        difficulty: 'Hard'
      }
    ]
  },

  'History & Social Studies': {
    id: 'test-history-core',
    title: 'History & Social Studies: Modern Civilizations & Governance Exam',
    subject: 'History & Social Studies',
    durationMinutes: 15,
    totalMarks: 30,
    passingMarks: 18,
    description: 'Examines historical causal timelines, constitutionalism, political revolutions, and geopolitical transformations.',
    instructions: [
      'Evaluate primary source contexts, cause-and-effect relationships, and constitutional principles.'
    ],
    questions: [
      {
        id: 'hist-q1',
        questionText: 'Which political philosopher articulated the principle of Separation of Powers into legislative, executive, and judicial branches in "The Spirit of the Laws" (1748)?',
        snippetOrFormula: '\\text{Enlightenment Political Philosophy}',
        options: [
          'Baron de Montesquieu',
          'Thomas Hobbes',
          'John Locke',
          'Jean-Jacques Rousseau'
        ],
        correctIndex: 0,
        explanation: 'Montesquieu argued that to prevent tyranny and preserve political liberty, governing power must be divided among three distinct branches that check and balance one another.',
        conceptTag: 'Constitutional Theory & Enlightenment',
        marks: 6,
        difficulty: 'Easy'
      },
      {
        id: 'hist-q2',
        questionText: 'What 1648 diplomatic agreements marked the transition to modern state sovereignty and the secular nation-state system in Europe?',
        snippetOrFormula: '\\text{European Geopolitics}',
        options: [
          'The Peace of Westphalia',
          'The Congress of Vienna',
          'The Treaty of Versailles',
          'The Treaty of Utrecht'
        ],
        correctIndex: 0,
        explanation: 'The Peace of Westphalia concluded the Thirty Years\' War and established "Westphalian sovereignty": territorial integrity, non-intervention in domestic affairs, and equality of sovereign states.',
        conceptTag: 'Modern Geopolitics & Sovereignty',
        marks: 6,
        difficulty: 'Medium'
      },
      {
        id: 'hist-q3',
        questionText: 'Which economic factor was primary in catalyzing the First Industrial Revolution in Great Britain in the late 18th century?',
        snippetOrFormula: '\\text{Economic History}',
        options: [
          'Abundant coal and iron reserves, secure property rights, and steam power mechanization',
          'Immediate nationalization of all agricultural land',
          'Discovery of gold in the Thames basin',
          'Strict prohibition of maritime trade'
        ],
        correctIndex: 0,
        explanation: 'Britain\'s unique combination of accessible coal, commercial capital, legal patent protections, agricultural surpluses, and mechanized steam looms propelled industrialization.',
        conceptTag: 'Industrialization & Economic History',
        marks: 6,
        difficulty: 'Medium'
      },
      {
        id: 'hist-q4',
        questionText: 'In United States constitutional law, which Supreme Court landmark decision established the doctrine of Judicial Review?',
        snippetOrFormula: 'Marbury v. Madison (1803)',
        options: [
          'Marbury v. Madison (1803)',
          'McCulloch v. Maryland (1819)',
          'Brown v. Board of Education (1954)',
          'Gibbons v. Ogden (1824)'
        ],
        correctIndex: 0,
        explanation: 'Chief Justice John Marshall ruled that it is emphatically the province and duty of the judicial department to say what the law is, granting federal courts the authority to strike down unconstitutional legislation.',
        conceptTag: 'Judicial Review & Jurisprudence',
        marks: 6,
        difficulty: 'Medium'
      },
      {
        id: 'hist-q5',
        questionText: 'What was the strategic objective of the Marshall Plan (European Recovery Program) initiated in 1948?',
        snippetOrFormula: '\\text{Cold War Reconstruction}',
        options: [
          'Rebuild war-torn Western European economies to foster democracy and prevent the spread of Soviet communism',
          'Extract heavy war reparations from defeated axis powers',
          'Establish a single worldwide gold currency',
          'Dismantle European heavy manufacturing completely'
        ],
        correctIndex: 0,
        explanation: 'The US provided over $13 billion in economic assistance to revitalize European industries and infrastructure, stabilizing democratic regimes against Soviet communist expansion.',
        conceptTag: 'Cold War History',
        marks: 6,
        difficulty: 'Easy'
      }
    ]
  },

  'Literature & Philosophy': {
    id: 'test-lit-core',
    title: 'Literature & Philosophy: Ethics, Epistemology & Literary Theory Exam',
    subject: 'Literature & Philosophy',
    durationMinutes: 15,
    totalMarks: 30,
    passingMarks: 18,
    description: 'Rigorous philosophical evaluation examining normative ethical frameworks, epistemological skepticism, and literary rhetoric.',
    instructions: [
      'Examine philosophical axioms, syllogisms, and rhetorical devices.'
    ],
    questions: [
      {
        id: 'lit-q1',
        questionText: 'In normative ethics, what distinguishes Immanuel Kant\'s Deontological Ethics from Utilitarianism (Bentham & Mill)?',
        snippetOrFormula: '\\text{Categorical Imperative vs Utility Principle}',
        options: [
          'Deontology evaluates actions based on duty and intrinsic moral maxims regardless of consequences; Utilitarianism evaluates morality by outcomes',
          'Deontology prioritizes emotional empathy over rationality',
          'Utilitarianism forbids all forms of cost-benefit analysis',
          'Both frameworks state that morality is purely subjective'
        ],
        correctIndex: 0,
        explanation: 'Kant\'s deontological ethics asserts moral duties are absolute (Categorical Imperative: act only according to maxims you can will as universal law). Consequentialist utilitarianism judges acts solely by net happiness/suffering produced.',
        conceptTag: 'Normative Ethics',
        marks: 6,
        difficulty: 'Medium'
      },
      {
        id: 'lit-q2',
        questionText: 'In Plato\'s "Republic", what does the Allegory of the Cave illustrate regarding epistemology and reality?',
        snippetOrFormula: '\\text{The Divided Line & The Forms}',
        options: [
          'Sensory perception perceives mere shadow reflections; true knowledge (episteme) requires philosophical dialectic understanding of immaterial Forms',
          'Human senses provide perfect, undeniable truth about physical matter',
          'All scientific knowledge is impossible and nihilistic',
          'Art and poetry are superior to mathematical logic'
        ],
        correctIndex: 0,
        explanation: 'Plato contrasts the chained prisoners watching shadows on the cave wall (sensory illusions/doxa) with the philosopher who escapes into the sunlight to perceive the True Forms (intelligible reality).',
        conceptTag: 'Epistemology & Metaphysics',
        marks: 6,
        difficulty: 'Medium'
      },
      {
        id: 'lit-q3',
        questionText: 'In classical Aristotelian tragedy (Poetics), what is "Hamartia"?',
        snippetOrFormula: '\\text{Aristotelian Poetics}',
        options: [
          'The fatal tragic flaw or error of judgment in an otherwise noble protagonist',
          'The comedic relief provided by minor characters',
          'The musical chorus interlude',
          'The physical weapon that causes the protagonist\'s death'
        ],
        correctIndex: 0,
        explanation: 'Hamartia refers to the tragic error, frailty, or miscalculation in judgment made by the protagonist (e.g. Oedipus\'s hubris, Hamlet\'s hesitation) that inevitably triggers their catastrophe.',
        conceptTag: 'Literary Theory & Drama',
        marks: 6,
        difficulty: 'Easy'
      },
      {
        id: 'lit-q4',
        questionText: 'Which 20th-century existentialist philosopher asserted in "Existentialism is a Humanism" that "existence precedes essence"?',
        snippetOrFormula: 'L\'existence précède l\'essence',
        options: [
          'Jean-Paul Sartre',
          'Friedrich Nietzsche',
          'Albert Camus',
          'Martin Heidegger'
        ],
        correctIndex: 0,
        explanation: 'Sartre argued that human beings first exist, encounter themselves in the world, and only through conscious choices define their purpose ("essence"). We are radically free and responsible.',
        conceptTag: 'Existential Philosophy',
        marks: 6,
        difficulty: 'Easy'
      },
      {
        id: 'lit-q5',
        questionText: 'In classical rhetoric, what is the rhetorical device where contradictory terms appear in conjunction (e.g., "deafening silence", "cruel kindness")?',
        snippetOrFormula: '\\text{Rhetorical Figures}',
        options: [
          'Oxymoron',
          'Metonymy',
          'Synecdoche',
          'Hyperbole'
        ],
        correctIndex: 0,
        explanation: 'An oxymoron juxtaposes two mutually contradictory words to reveal a paradoxical deeper truth or heightened dramatic effect.',
        conceptTag: 'Rhetoric & Stylistics',
        marks: 6,
        difficulty: 'Easy'
      }
    ]
  },

  'Engineering': {
    id: 'test-eng-core',
    title: 'Engineering: Statics, Circuit Dynamics & Signals Exam',
    subject: 'Engineering',
    durationMinutes: 15,
    totalMarks: 30,
    passingMarks: 18,
    description: 'Comprehensive engineering diagnostic covering stress-strain tensor mechanics, Kirchhoff circuit laws, and heat dissipation.',
    instructions: [
      'Apply standard engineering conventions, free body diagrams, and nodal equations.'
    ],
    questions: [
      {
        id: 'eng-q1',
        questionText: 'In mechanics of materials, what does Young\'s Modulus ($E$) measure in the linear elastic regime of a material stress-strain curve?',
        snippetOrFormula: '\\sigma = E \\cdot \\epsilon',
        options: [
          'The tensile stiffness or resistance to elastic deformation ($E = \\sigma / \\epsilon$)',
          'The total plastic fracture energy density',
          'The thermal conductivity coefficient',
          'The shear strain angle at failure'
        ],
        correctIndex: 0,
        explanation: 'Hooke\'s Law states that in the elastic region, axial stress $\\sigma$ is directly proportional to strain $\\epsilon$: $\\sigma = E \\epsilon$. Young\'s Modulus $E$ is the slope of this line, quantifying tensile stiffness.',
        conceptTag: 'Mechanics of Materials & Statics',
        marks: 6,
        difficulty: 'Easy'
      },
      {
        id: 'eng-q2',
        questionText: 'In an RLC series AC circuit driven at angular frequency $\\omega$, under what condition does electrical resonance occur?',
        snippetOrFormula: 'Z = R + j\\left(\\omega L - \\frac{1}{\\omega C}\\right)',
        options: [
          '$\\omega = \\frac{1}{\\sqrt{LC}}$ (inductive reactance equals capacitive reactance)',
          '$\\omega = \\sqrt{R / L}$',
          '$\\omega = 0$ (DC condition)',
          '$R = \\omega L$'
        ],
        correctIndex: 0,
        explanation: 'Resonance occurs when inductive reactance $X_L = \\omega L$ cancels capacitive reactance $X_C = 1/(\\omega C)$. The imaginary impedance vanishes ($Z = R$), maximizing current at $\\omega_0 = 1/\\sqrt{LC}$.',
        conceptTag: 'Electrical Circuits & Signals',
        marks: 6,
        difficulty: 'Medium'
      },
      {
        id: 'eng-q3',
        questionText: 'According to Fourier\'s Law of Thermal Conduction, how does heat transfer rate $\\dot{Q}$ relate to temperature gradient $dT/dx$ and surface area $A$?',
        snippetOrFormula: '\\dot{Q} = -k A \\frac{dT}{dx}',
        options: [
          'Directly proportional to surface area $A$ and negative temperature gradient (heat flows hot to cold)',
          'Inversely proportional to thermal conductivity $k$',
          'Independent of distance $x$',
          'Proportional to $T^4$ radiation'
        ],
        correctIndex: 0,
        explanation: 'Fourier\'s Law $\\dot{Q} = -k A (dT/dx)$ states that heat transfer conduction rate is proportional to cross-sectional area and thermal gradient, flowing down the temperature gradient.',
        conceptTag: 'Thermodynamics & Heat Transfer',
        marks: 6,
        difficulty: 'Medium'
      },
      {
        id: 'eng-q4',
        questionText: 'In classical control systems, a negative feedback system is BIBO (Bounded-Input Bounded-Output) stable if and only if all poles of the closed-loop transfer function lie where in the s-plane?',
        snippetOrFormula: '\\text{Laplace Domain Poles}',
        options: [
          'Strictly in the open Left-Half Plane (real parts $< 0$)',
          'Strictly on the imaginary axis',
          'Anywhere in the Right-Half Plane',
          'Inside a unit circle centered at $+1$'
        ],
        correctIndex: 0,
        explanation: 'For continuous-time systems, poles with negative real parts ($e^{\\sigma t}$ with $\\sigma < 0$) decay exponentially to zero over time, guaranteeing asymptotic stability.',
        conceptTag: 'Control Systems & Automation',
        marks: 6,
        difficulty: 'Hard'
      },
      {
        id: 'eng-q5',
        questionText: 'In structural truss analysis, what assumption is universally made regarding the joints between structural members?',
        snippetOrFormula: '\\sum F_x = 0, \\quad \\sum F_y = 0',
        options: [
          'Joints are frictionless pin connections carrying only axial tension or compression forces',
          'Joints carry large bending moments at all angles',
          'Members have infinite distributed transverse mass',
          'Joints are rigid welded clamps resistant to rotation'
        ],
        correctIndex: 0,
        explanation: 'Ideal truss theory assumes straight members connected by frictionless pins with loads applied only at joints, ensuring members act as two-force members under pure axial tension or compression.',
        conceptTag: 'Structural Engineering & Statics',
        marks: 6,
        difficulty: 'Medium'
      }
    ]
  },

  'General Academia': {
    id: 'test-gen-core',
    title: 'Interdisciplinary Reasoning: Scientific Inquiry & Logic Exam',
    subject: 'General Academia',
    durationMinutes: 15,
    totalMarks: 30,
    passingMarks: 18,
    description: 'Diagnostic assessment evaluating inductive/deductive reasoning, experimental design, and critical cognitive heuristics.',
    instructions: [
      'Evaluate empirical claims, falsifiability, and logical validity.'
    ],
    questions: [
      {
        id: 'gen-q1',
        questionText: 'According to philosopher Karl Popper, what is the primary demarcation criterion that distinguishes empirical science from non-science?',
        snippetOrFormula: '\\text{Philosophy of Science}',
        options: [
          'Falsifiability (a scientific theory must make risky predictions that can potentially be disproven)',
          'Inductive certainty (proving a hypothesis with absolute 100% mathematical proof)',
          'Public opinion consensus',
          'Complexity of the terminology used'
        ],
        correctIndex: 0,
        explanation: 'Popper argued that no finite amount of observation can verify a universal hypothesis, but a single counterexample can falsify it. Therefore, falsifiability is the hallmark of genuine science.',
        conceptTag: 'Scientific Method & Epistemology',
        marks: 6,
        difficulty: 'Easy'
      },
      {
        id: 'gen-q2',
        questionText: 'In statistical research methodology, what is a "Type I Error" ($\\alpha$)?',
        snippetOrFormula: '\\alpha = P(\\text{Reject } H_0 \\mid H_0 \\text{ is True})',
        options: [
          'Rejecting the null hypothesis ($H_0$) when it is actually true (a false positive)',
          'Failing to reject the null hypothesis when an effect actually exists (a false negative)',
          'Incorrect sample size arithmetic',
          'Confusing mean with median'
        ],
        correctIndex: 0,
        explanation: 'A Type I error is a false positive: claiming a statistically significant effect or finding when in reality the null hypothesis is true.',
        conceptTag: 'Experimental Design & Statistics',
        marks: 6,
        difficulty: 'Medium'
      },
      {
        id: 'gen-q3',
        questionText: 'In deductive formal logic, what is the valid argument form: "If P then Q; P is true; therefore Q is true"?',
        snippetOrFormula: 'P \\to Q, \\quad P \\vdash Q',
        options: [
          'Modus Ponens (affirming the antecedent)',
          'Modus Tollens (denying the consequent)',
          'Affirming the Consequent (logical fallacy)',
          'Reductio ad Absurdum'
        ],
        correctIndex: 0,
        explanation: 'Modus Ponens is the fundamental rule of inference: from $P \\to Q$ and premise $P$, we necessarily infer $Q$.',
        conceptTag: 'Formal Logic & Deductive Systems',
        marks: 6,
        difficulty: 'Easy'
      },
      {
        id: 'gen-q4',
        questionText: 'What cognitive bias causes people to search for, interpret, and recall information in a way that confirms prior beliefs while disregarding contradictory evidence?',
        snippetOrFormula: '\\text{Cognitive Psychology}',
        options: [
          'Confirmation Bias',
          'Anchoring Heuristic',
          'Availability Cascade',
          'Sunk Cost Fallacy'
        ],
        correctIndex: 0,
        explanation: 'Confirmation bias is the tendency to favor information that corroborates pre-existing hypotheses or worldviews while systematically dismissing contrary data.',
        conceptTag: 'Critical Thinking & Cognitive Biases',
        marks: 6,
        difficulty: 'Easy'
      },
      {
        id: 'gen-q5',
        questionText: 'Why does correlation not inherently imply causation in observational empirical studies?',
        snippetOrFormula: '\\text{Causal Inference}',
        options: [
          'Because an unobserved confounding variable (lurking variable) or reverse causation may account for the relationship',
          'Because correlation is always an error in arithmetic calculation',
          'Because causation cannot exist in physical systems',
          'Because statistical samples cannot exceed 100 observations'
        ],
        correctIndex: 0,
        explanation: 'Two variables $A$ and $B$ may correlate strongly due to an unmeasured third confounding variable $C$ causing both, or reverse causality ($B$ causes $A$), requiring randomized controlled trials to isolate causal mechanics.',
        conceptTag: 'Causal Inference & Methodology',
        marks: 6,
        difficulty: 'Medium'
      }
    ]
  }
};

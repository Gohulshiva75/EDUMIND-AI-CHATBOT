import React, { useState, useEffect } from 'react';
import { 
  BarChart3, 
  Flame, 
  Clock, 
  Award, 
  CheckCircle2, 
  Sparkles, 
  BookOpen, 
  Microscope, 
  Lightbulb, 
  User, 
  TrendingUp, 
  Settings, 
  ArrowRight,
  GraduationCap,
  Loader2,
  RefreshCw,
  Download
} from 'lucide-react';
import { StudentProfile, AcademicSubject, TestAttemptResult } from '../../types';
import { renderMasteryRadarChart } from '../../utils/pythonVisualizer';

interface StudentDashboardProps {
  studentProfile: StudentProfile;
  onUpdateProfile: (updated: Partial<StudentProfile>) => void;
  onNavigateToTab: (tab: any) => void;
}

const ACADEMIC_SUBJECTS: AcademicSubject[] = [
  'Mathematics',
  'Physics & Astronomy',
  'Chemistry & BioChem',
  'Biology & Medicine',
  'Computer Science & AI',
  'History & Social Studies',
  'Literature & Philosophy',
  'Economics & Business',
  'Engineering',
  'General Academia'
];

export const StudentDashboard: React.FC<StudentDashboardProps> = ({
  studentProfile,
  onUpdateProfile,
  onNavigateToTab,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [tempName, setTempName] = useState(studentProfile.name);
  const [tempSubject, setTempSubject] = useState(studentProfile.activeSubject);
  const [tempGoal, setTempGoal] = useState(studentProfile.targetExamOrGoal);
  const [tempStyle, setTempStyle] = useState(studentProfile.preferredLearningStyle);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile({
      name: tempName,
      activeSubject: tempSubject,
      targetExamOrGoal: tempGoal,
      preferredLearningStyle: tempStyle as any,
    });
    setIsEditing(false);
  };

  const competencyItems = [
    { label: 'Conceptual Depth & Intuition', score: studentProfile.masteryScores.conceptualUnderstanding, color: 'from-amber-500 to-orange-500', icon: BookOpen },
    { label: 'Analytical Problem Solving', score: studentProfile.masteryScores.analyticalProblemSolving, color: 'from-cyan-500 to-blue-500', icon: Microscope },
    { label: 'Critical Thinking & Synthesis', score: studentProfile.masteryScores.criticalThinking, color: 'from-indigo-500 to-purple-500', icon: Sparkles },
    { label: 'Active Recall & Retention', score: studentProfile.masteryScores.retentionAndRecall, color: 'from-rose-500 to-pink-500', icon: Award },
    { label: 'Design Thinking Method (5 Phases)', score: studentProfile.masteryScores.designThinkingMethod, color: 'from-emerald-500 to-teal-500', icon: Lightbulb },
    { label: 'Exam Readiness & Trap Avoidance', score: studentProfile.masteryScores.examReadiness, color: 'from-sky-500 to-indigo-500', icon: TrendingUp },
  ];

  const [pythonRadarUrl, setPythonRadarUrl] = useState<string | null>(null);
  const [isRadarLoading, setIsRadarLoading] = useState(false);
  const [radarError, setRadarError] = useState<string | null>(null);

  const loadPythonRadar = async () => {
    setIsRadarLoading(true);
    setRadarError(null);
    try {
      let history: TestAttemptResult[] = studentProfile.testHistory || [];
      if (history.length === 0) {
        try {
          const saved = localStorage.getItem('edumind_test_history');
          if (saved) history = JSON.parse(saved);
        } catch {
          // ignore localStorage read errors
        }
      }
      const imgUrl = await renderMasteryRadarChart(
        studentProfile.masteryScores,
        studentProfile.activeSubject,
        history
      );
      setPythonRadarUrl(imgUrl);
    } catch (err: any) {
      setRadarError(err?.message || 'Could not render Python Matplotlib radar plot.');
    } finally {
      setIsRadarLoading(false);
    }
  };

  useEffect(() => {
    loadPythonRadar();
  }, [studentProfile.activeSubject, studentProfile.completedTasksCount]);

  const avgMastery = Math.round(
    Object.values(studentProfile.masteryScores).reduce((a, b) => a + b, 0) /
    Object.values(studentProfile.masteryScores).length
  );

  return (
    <div className="h-full flex flex-col bg-slate-950/60 overflow-hidden">
      {/* Top Banner */}
      <div className="p-4 border-b border-slate-800/80 bg-slate-900/60 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-sky-500/20 text-sky-400 border border-sky-500/30 flex items-center justify-center">
            <BarChart3 className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              Academic Mastery & Growth Analytics
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-sky-500/10 text-sky-300 border border-sky-500/20">
                Cognitive Competency Radar
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              Cross-disciplinary progress tracking, focus analytics, and active recall metrics
            </p>
          </div>
        </div>

        <button
          onClick={() => setIsEditing(!isEditing)}
          className="px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700/60 flex items-center gap-1.5 transition-colors"
        >
          <Settings className="w-3.5 h-3.5" />
          <span>{isEditing ? 'Cancel Editing' : 'Personalize Goals'}</span>
        </button>
      </div>

      {/* Main Dashboard Grid */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6 max-w-5xl mx-auto w-full">
        {/* Profile Edit Drawer */}
        {isEditing && (
          <form onSubmit={handleSaveProfile} className="p-5 rounded-2xl bg-slate-900 border border-slate-700 shadow-xl space-y-4 text-xs">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <User className="w-4 h-4 text-sky-400" /> Update Student Profile & Subject Goals
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
              <div>
                <label className="font-semibold text-slate-300 block mb-1">Your Name</label>
                <input
                  type="text"
                  value={tempName}
                  onChange={(e) => setTempName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white outline-none"
                  required
                />
              </div>

              <div>
                <label className="font-semibold text-slate-300 block mb-1">Active Subject</label>
                <select
                  value={tempSubject}
                  onChange={(e: any) => setTempSubject(e.target.value as AcademicSubject)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white outline-none"
                >
                  {ACADEMIC_SUBJECTS.map(s => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="font-semibold text-slate-300 block mb-1">Target Exam / Goal</label>
                <input
                  type="text"
                  value={tempGoal}
                  onChange={(e) => setTempGoal(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white outline-none"
                  required
                />
              </div>

              <div>
                <label className="font-semibold text-slate-300 block mb-1">Preferred Learning Style</label>
                <select
                  value={tempStyle}
                  onChange={(e: any) => setTempStyle(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white outline-none"
                >
                  <option value="Step-by-Step Problem Solving">Step-by-Step Problem Solving</option>
                  <option value="Visual & Conceptual">Visual & Conceptual</option>
                  <option value="Socratic & Discussion">Socratic & Discussion</option>
                  <option value="Exam-Cram & High-Yield">Exam-Cram & High-Yield</option>
                </select>
              </div>
            </div>

            <div className="flex justify-end gap-2">
              <button
                type="submit"
                className="px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white font-semibold rounded-lg"
              >
                Save Preferences
              </button>
            </div>
          </form>
        )}

        {/* Top 4 KPI Metrics */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 shadow-sm">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-slate-400 font-medium">Study Streak</span>
              <Flame className="w-4 h-4 text-orange-400 fill-orange-500/20" />
            </div>
            <div className="text-2xl font-black text-white">{studentProfile.streakDays} Days</div>
            <span className="text-[10px] text-emerald-400 font-medium">🔥 Active Learning Habit</span>
          </div>

          <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 shadow-sm">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-slate-400 font-medium">Deep Work Logged</span>
              <Clock className="w-4 h-4 text-indigo-400" />
            </div>
            <div className="text-2xl font-black text-white">{studentProfile.totalStudyMinutes} mins</div>
            <span className="text-[10px] text-indigo-400 font-medium">Pomodoro Cycles Completed</span>
          </div>

          <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 shadow-sm">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-slate-400 font-medium">Tasks Mastered</span>
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-2xl font-black text-white">{studentProfile.completedTasksCount}</div>
            <span className="text-[10px] text-slate-400 font-medium">Milestones & Sprints</span>
          </div>

          <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 shadow-sm">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-slate-400 font-medium">Cumulative Mastery</span>
              <Sparkles className="w-4 h-4 text-cyan-400" />
            </div>
            <div className="text-2xl font-black text-transparent bg-gradient-to-r from-cyan-400 to-indigo-300 bg-clip-text">
              {avgMastery}%
            </div>
            <span className="text-[10px] text-cyan-400 font-medium">Across All Core Dimensions</span>
          </div>
        </div>

        {/* Python Matplotlib Radar & Subject Analytics */}
        <div className="p-6 rounded-2xl bg-slate-900/70 border border-slate-800 shadow-sm space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <span>Python Competency Radar & Subject Analytics</span>
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                  Matplotlib + NumPy
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Polar cognitive radar & cross-subject test averages rendered in-browser by Python
              </p>
            </div>
            <div className="flex items-center gap-2">
              {pythonRadarUrl && (
                <a
                  href={pythonRadarUrl}
                  download={`edumind-competency-radar-${studentProfile.activeSubject.toLowerCase().replace(/[^a-z0-9]+/g, '-')}.png`}
                  className="px-2.5 py-1 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 text-[11px] font-semibold flex items-center gap-1"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>PNG</span>
                </a>
              )}
              <button
                onClick={loadPythonRadar}
                disabled={isRadarLoading}
                className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-[11px] flex items-center gap-1 disabled:opacity-50"
              >
                <RefreshCw className={`w-3 h-3 ${isRadarLoading ? 'animate-spin' : ''}`} />
                <span>Re-plot</span>
              </button>
            </div>
          </div>

          {isRadarLoading && !pythonRadarUrl && (
            <div className="p-8 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center gap-3 text-xs text-slate-300">
              <Loader2 className="w-5 h-5 text-emerald-400 animate-spin" />
              <span>Plotting Python Matplotlib Competency Radar...</span>
            </div>
          )}

          {radarError && (
            <div className="p-3 rounded-xl bg-rose-950/30 border border-rose-500/40 text-xs text-rose-300">
              {radarError}
            </div>
          )}

          {pythonRadarUrl && (
            <div className="rounded-xl overflow-hidden border border-slate-800 bg-[#090e1a] p-2">
              <img
                src={pythonRadarUrl}
                alt="Python Matplotlib Competency Radar"
                className="w-full h-auto rounded-lg block"
              />
            </div>
          )}
        </div>

        {/* Competency Mastery Bars */}
        <div className="p-6 rounded-2xl bg-slate-900/70 border border-slate-800 shadow-sm space-y-5">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-sm font-bold text-white">Academic Competency Dimensions</h3>
              <p className="text-xs text-slate-400">
                Calibrated dynamically using Socratic inquiries, diagnostic quizzes, and problem lab evaluations
              </p>
            </div>
            <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-slate-800 text-cyan-300 flex items-center gap-1.5">
              <GraduationCap className="w-3.5 h-3.5" />
              {studentProfile.activeSubject}
            </span>
          </div>

          <div className="space-y-4">
            {competencyItems.map((item, idx) => {
              const Icon = item.icon;
              return (
                <div key={idx} className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-200 flex items-center gap-2">
                      <Icon className="w-3.5 h-3.5 text-slate-400" />
                      {item.label}
                    </span>
                    <span className="font-mono font-bold text-slate-300">{item.score}%</span>
                  </div>
                  <div className="w-full bg-slate-950 rounded-full h-2.5 overflow-hidden border border-slate-800">
                    <div
                      className={`bg-gradient-to-r ${item.color} h-2.5 rounded-full transition-all duration-700`}
                      style={{ width: `${item.score}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Actionable Recommendations from Edumind AI */}
        <div className="p-6 rounded-2xl bg-gradient-to-br from-indigo-950/40 via-slate-900 to-slate-900 border border-indigo-500/30 shadow-md space-y-4">
          <div className="flex items-center gap-2 text-indigo-300">
            <Sparkles className="w-5 h-5 text-indigo-400" />
            <h3 className="text-sm font-bold text-white">
              Edumind AI Academic Guidance for {studentProfile.activeSubject}
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800/80 flex flex-col justify-between">
              <div>
                <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wide block mb-1">
                  1. Multi-Step Problem Solving
                </span>
                <p className="font-bold text-white text-sm mb-1">
                  Work through Benchmark Derivations
                </p>
                <p className="text-slate-400 leading-relaxed">
                  Your analytical problem solving score is at {studentProfile.masteryScores.analyticalProblemSolving}%. Use the Problem Lab to inspect step-by-step model solutions and avoid common exam traps.
                </p>
              </div>
              <button
                onClick={() => onNavigateToTab('problemLab')}
                className="mt-3 text-amber-400 hover:text-amber-300 font-semibold flex items-center gap-1 self-start"
              >
                <span>Open Problem Lab</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800/80 flex flex-col justify-between">
              <div>
                <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wide block mb-1">
                  2. Design Thinking Innovation
                </span>
                <p className="font-bold text-white text-sm mb-1">
                  Frame "How Might We" Statements
                </p>
                <p className="text-slate-400 leading-relaxed">
                  Break down difficult questions using the 5-phase Design Thinking canvas to deconstruct ambiguity and prototype solutions.
                </p>
              </div>
              <button
                onClick={() => onNavigateToTab('designThinking')}
                className="mt-3 text-emerald-400 hover:text-emerald-300 font-semibold flex items-center gap-1 self-start"
              >
                <span>Open Design Thinking</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="p-4 rounded-xl bg-slate-950/80 border border-purple-500/30 flex flex-col justify-between">
              <div>
                <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wide block mb-1">
                  3. Rigorous Subject Testing
                </span>
                <p className="font-bold text-white text-sm mb-1">
                  Take Timed {studentProfile.activeSubject} Exam
                </p>
                <p className="text-slate-400 leading-relaxed">
                  Test your actual marks and generate graphical analytics with performance curve plotting and model step-by-step solutions.
                </p>
              </div>
              <button
                onClick={() => onNavigateToTab('testModule')}
                className="mt-3 text-purple-400 hover:text-purple-300 font-semibold flex items-center gap-1 self-start"
              >
                <span>Launch Subject Test</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

import { AcademicSubject, TestAttemptResult } from '../types';

declare global {
  interface Window {
    loadPyodide?: (config?: { indexURL?: string }) => Promise<PyodideInstance>;
  }
}

export interface PyodideInstance {
  loadPackage: (packages: string | string[]) => Promise<void>;
  runPythonAsync: (code: string) => Promise<any>;
  globals: {
    set: (name: string, value: any) => void;
    delete: (name: string) => void;
  };
}

const PYODIDE_INDEX_URL = 'https://cdn.jsdelivr.net/pyodide/v0.26.4/full/';
const PYODIDE_SCRIPT_URL = `${PYODIDE_INDEX_URL}pyodide.js`;

let pyodideInstancePromise: Promise<PyodideInstance> | null = null;
let packagesLoadedPromise: Promise<void> | null = null;

function injectPyodideScript(): Promise<void> {
  if (typeof window === 'undefined') {
    return Promise.reject(new Error('Pyodide can only run in a browser environment.'));
  }

  if (window.loadPyodide) {
    return Promise.resolve();
  }

  return new Promise((resolve, reject) => {
    const existing = document.querySelector(`script[src="${PYODIDE_SCRIPT_URL}"]`) as HTMLScriptElement | null;
    if (existing) {
      if (window.loadPyodide) {
        resolve();
        return;
      }
      existing.addEventListener('load', () => resolve(), { once: true });
      existing.addEventListener('error', () => reject(new Error('Failed to load Pyodide runtime script.')), { once: true });
      return;
    }

    const script = document.createElement('script');
    script.src = PYODIDE_SCRIPT_URL;
    script.async = true;
    script.onload = () => resolve();
    script.onerror = () => reject(new Error('Failed to fetch Pyodide from CDN.'));
    document.head.appendChild(script);
  });
}

export async function getPyodideCore(): Promise<PyodideInstance> {
  if (!pyodideInstancePromise) {
    pyodideInstancePromise = (async () => {
      await injectPyodideScript();
      if (!window.loadPyodide) {
        throw new Error('window.loadPyodide is unavailable after script load.');
      }
      const pyodide = await window.loadPyodide({ indexURL: PYODIDE_INDEX_URL });
      return pyodide;
    })().catch((err) => {
      pyodideInstancePromise = null;
      throw err;
    });
  }

  return await pyodideInstancePromise;
}

export async function getPyodideMatplotlib(): Promise<PyodideInstance> {
  const pyodide = await getPyodideCore();

  if (!packagesLoadedPromise) {
    packagesLoadedPromise = (async () => {
      await pyodide.loadPackage(['matplotlib', 'numpy']);
      await pyodide.runPythonAsync(`
import os
os.environ["MPLBACKEND"] = "Agg"
import matplotlib
matplotlib.use("Agg")
`);
    })().catch((err) => {
      packagesLoadedPromise = null;
      throw err;
    });
  }

  await packagesLoadedPromise;
  return pyodide;
}

export interface PythonChartOutput {
  imageDataUrl: string;
  pythonCode: string;
  renderTimeMs: number;
}

const PYTHON_PLOTTING_CODE = `
import json
import io
import base64
import textwrap
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

def render_edumind_chart(payload_str):
    data = json.loads(payload_str)

    plt.rcParams.update({
        "figure.facecolor": "#090e1a",
        "axes.facecolor": "#0f172a",
        "axes.edgecolor": "#334155",
        "axes.labelcolor": "#cbd5e1",
        "text.color": "#f8fafc",
        "xtick.color": "#94a3b8",
        "ytick.color": "#cbd5e1",
        "grid.color": "#1e293b",
        "font.sans-serif": ["DejaVu Sans"],
    })

    fig, axes = plt.subplots(2, 2, figsize=(13.5, 8.6), dpi=150)
    fig.subplots_adjust(left=0.14, right=0.96, top=0.88, bottom=0.09, wspace=0.28, hspace=0.38)

    subject = data.get("subject", "Subject")
    marks_obt = data.get("marksObtained", 0)
    total_marks = max(1, data.get("totalMarks", 1))
    pct = data.get("percentage", 0)
    grade = data.get("grade", "")

    fig.suptitle(
        f"Edumind AI — Python Matplotlib Performance Diagnostics ({subject})",
        fontsize=14,
        fontweight="bold",
        color="#f8fafc",
        y=0.96
    )
    fig.text(
        0.5, 0.92,
        f"Score: {marks_obt}/{total_marks} Marks ({pct}%)  |  Grade: {grade}  |  Accuracy: {data.get('accuracy', 0)}%",
        ha="center",
        fontsize=10,
        color="#38bdf8",
        fontweight="bold"
    )

    # 1. TOP LEFT: Topic Competency Horizontal Bar Chart
    ax1 = axes[0, 0]
    topics = data.get("topics", [])
    if topics:
        labels = [textwrap.fill(t["topic"], width=22) for t in topics][::-1]
        pcts = [t["percentage"] for t in topics][::-1]
        marks_labels = [f"{t['percentage']}% ({t['marksObtained']}/{t['totalMarks']})" for t in topics][::-1]
        colors = [
            "#10b981" if p >= 80 else ("#f59e0b" if p >= 50 else "#f43f5e")
            for p in pcts
        ]

        y_pos = np.arange(len(labels))
        bars = ax1.barh(y_pos, pcts, color=colors, height=0.58, edgecolor="#020617", linewidth=0.8)
        ax1.axvline(80, color="#818cf8", linestyle="--", linewidth=1.4, label="80% Mastery Target")
        ax1.set_yticks(y_pos)
        ax1.set_yticklabels(labels, fontsize=8.5)
        ax1.set_xlim(0, 118)
        ax1.set_xlabel("Score Percentage (%)", fontsize=9)
        ax1.set_title("1. Topic Mastery Breakdown", fontsize=11, fontweight="bold", loc="left", pad=10)
        ax1.grid(axis="x", linestyle=":", alpha=0.7)
        ax1.legend(loc="lower right", fontsize=8, facecolor="#020617", edgecolor="#334155")

        for bar, lbl in zip(bars, marks_labels):
            w = bar.get_width()
            ax1.text(min(w + 2, 102), bar.get_y() + bar.get_height() / 2, lbl,
                     va="center", ha="left", fontsize=8, color="#e2e8f0", fontweight="bold")
    else:
        ax1.text(0.5, 0.5, "No topic breakdown available", ha="center", va="center")
        ax1.set_title("1. Topic Mastery Breakdown", fontsize=11, fontweight="bold", loc="left")

    # 2. TOP RIGHT: Historical Score Progression & Trendline
    ax2 = axes[0, 1]
    hist = data.get("history", [])
    if hist:
        x_idx = np.arange(1, len(hist) + 1)
        y_vals = np.array([h["percentage"] for h in hist], dtype=float)

        ax2.plot(x_idx, y_vals, color="#06b6d4", linewidth=2.4, marker="o", markersize=6,
                 markerfacecolor="#06b6d4", markeredgecolor="#090e1a", label="Attempt Score (%)")
        if len(hist) > 1:
            ax2.fill_between(x_idx, y_vals, 0, color="#06b6d4", alpha=0.14)
            z = np.polyfit(x_idx, y_vals, 1)
            p_trend = np.poly1d(z)
            ax2.plot(x_idx, np.clip(p_trend(x_idx), 0, 100), color="#a855f7",
                     linestyle="-.", linewidth=1.5, label="Linear Growth Trend")

        for xi, yi, h in zip(x_idx, y_vals, hist):
            if h.get("isCurrent"):
                ax2.scatter([xi], [yi], color="#fbbf24", s=130, zorder=5, edgecolor="#090e1a", linewidth=1.5, label="Current Attempt")
            ax2.text(xi, min(yi + 4.5, 96), f"{int(yi)}%", ha="center", fontsize=8.5,
                     fontweight="bold", color="#fbbf24" if h.get("isCurrent") else "#e2e8f0")

        ax2.axhline(80, color="#10b981", linestyle="--", linewidth=1.0, alpha=0.75, label="80% Mastery")
        ax2.axhline(60, color="#f59e0b", linestyle=":", linewidth=1.0, alpha=0.75, label="60% Pass")
        ax2.set_ylim(0, 108)
        ax2.set_xticks(x_idx)
        ax2.set_xticklabels([f"#{int(i)}" for i in x_idx], fontsize=8.5)
        ax2.set_xlabel("Chronological Test Attempt", fontsize=9)
        ax2.set_ylabel("Percentage (%)", fontsize=9)
        ax2.set_title("2. Score Progression & Trend", fontsize=11, fontweight="bold", loc="left", pad=10)
        ax2.grid(True, linestyle=":", alpha=0.6)
        ax2.legend(loc="lower right", fontsize=7.5, ncol=2, facecolor="#020617", edgecolor="#334155")
    else:
        ax2.text(0.5, 0.5, "No historical attempts yet", ha="center", va="center")
        ax2.set_title("2. Score Progression & Trend", fontsize=11, fontweight="bold", loc="left")

    # 3. BOTTOM LEFT: Cognitive Depth (Difficulty Breakdown)
    ax3 = axes[1, 0]
    diff_list = data.get("difficulty", [])
    if diff_list:
        d_names = [d["level"] for d in diff_list]
        d_pcts = [d["percentage"] for d in diff_list]
        d_colors = ["#10b981", "#f59e0b", "#f43f5e"][:len(d_names)]
        x_d = np.arange(len(d_names))
        bars3 = ax3.bar(x_d, d_pcts, width=0.5, color=d_colors, edgecolor="#020617", linewidth=0.9)
        ax3.axhline(80, color="#818cf8", linestyle="--", linewidth=1.1, alpha=0.8)
        ax3.set_xticks(x_d)
        ax3.set_xticklabels([f"{d['level']}\\n({d['count']} Qs)" for d in diff_list], fontsize=8.5)
        ax3.set_ylim(0, 115)
        ax3.set_ylabel("Accuracy (%)", fontsize=9)
        ax3.set_title("3. Cognitive Depth by Difficulty", fontsize=11, fontweight="bold", loc="left", pad=10)
        ax3.grid(axis="y", linestyle=":", alpha=0.6)

        for bar, d in zip(bars3, diff_list):
            h = bar.get_height()
            ax3.text(bar.get_x() + bar.get_width() / 2, h + 3,
                     f"{d['percentage']}%\\n({d['scored']}/{d['total']}m)",
                     ha="center", va="bottom", fontsize=8, color="#e2e8f0", fontweight="bold")

    # 4. BOTTOM RIGHT: Marks Summary Donut Gauge
    ax4 = axes[1, 1]
    missed = max(0, total_marks - marks_obt)
    donut_vals = [marks_obt, missed] if (marks_obt + missed) > 0 else [1, 0]
    donut_colors = ["#06b6d4" if pct >= 60 else "#f43f5e", "#1e293b"]
    wedges, _ = ax4.pie(
        donut_vals,
        startangle=90,
        counterclock=False,
        colors=donut_colors,
        wedgeprops=dict(width=0.34, edgecolor="#0f172a", linewidth=2),
        radius=0.92
    )
    ax4.text(0, 0.12, f"{pct}%", ha="center", va="center", fontsize=22, fontweight="bold",
             color="#34d399" if pct >= 80 else ("#fbbf24" if pct >= 60 else "#fb7185"))
    ax4.text(0, -0.14, f"{marks_obt} / {total_marks} Marks", ha="center", va="center",
             fontsize=10, color="#cbd5e1", fontweight="bold")
    ax4.text(0, -0.34, grade, ha="center", va="center", fontsize=8.5, color="#94a3b8")
    ax4.set_title("4. Overall Marks Distribution", fontsize=11, fontweight="bold", loc="left", pad=10)

    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=150, facecolor=fig.get_facecolor())
    plt.close(fig)
    buf.seek(0)
    encoded = base64.b64encode(buf.read()).decode("utf-8")
    return "data:image/png;base64," + encoded
`;

export async function renderPythonPerformanceChart(
  currentResult: TestAttemptResult,
  history: TestAttemptResult[],
  activeSubject: AcademicSubject,
  historyScope: 'subject' | 'all' = 'subject'
): Promise<PythonChartOutput> {
  const startTime = performance.now();
  const pyodide = await getPyodideMatplotlib();

  const relevantHistory = (historyScope === 'subject'
    ? history.filter((h) => h.subject === activeSubject)
    : history
  ).slice().sort((a, b) => a.timestamp - b.timestamp);

  // Ensure currentResult is included in progression if history was empty
  const historyWithCurrent = relevantHistory.some((h) => h.id === currentResult.id)
    ? relevantHistory
    : [...relevantHistory, currentResult].sort((a, b) => a.timestamp - b.timestamp);

  const diffBuckets: Record<'Easy' | 'Medium' | 'Hard', { scored: number; total: number; count: number }> = {
    Easy: { scored: 0, total: 0, count: 0 },
    Medium: { scored: 0, total: 0, count: 0 },
    Hard: { scored: 0, total: 0, count: 0 },
  };

  currentResult.questions.forEach((q) => {
    const d = q.difficulty || 'Medium';
    diffBuckets[d].total += q.marks;
    diffBuckets[d].count += 1;
    if (currentResult.answers[q.id] === q.correctIndex) {
      diffBuckets[d].scored += q.marks;
    }
  });

  const payload = {
    subject: currentResult.subject,
    testTitle: currentResult.testTitle,
    date: currentResult.date,
    marksObtained: currentResult.marksObtained,
    totalMarks: currentResult.totalMarks,
    percentage: currentResult.percentage,
    grade: currentResult.grade,
    accuracy: currentResult.accuracy,
    topics: currentResult.topicBreakdown,
    history: historyWithCurrent.map((h) => ({
      date: h.date,
      percentage: h.percentage,
      title: h.testTitle,
      subject: h.subject,
      isCurrent: h.id === currentResult.id,
    })),
    difficulty: (['Easy', 'Medium', 'Hard'] as const).map((level) => {
      const b = diffBuckets[level];
      return {
        level,
        scored: b.scored,
        total: b.total,
        count: b.count,
        percentage: b.total > 0 ? Math.round((b.scored / b.total) * 100) : 0,
      };
    }),
  };

  const payloadJson = JSON.stringify(payload);
  pyodide.globals.set('edumind_payload_json', payloadJson);

  try {
    const imageDataUrl: string = await pyodide.runPythonAsync(`
${PYTHON_PLOTTING_CODE}
render_edumind_chart(edumind_payload_json)
`);
    const renderTimeMs = Math.round(performance.now() - startTime);

    const standaloneScript = `# Run locally with: pip install matplotlib numpy\n${PYTHON_PLOTTING_CODE.trim()}\n\nif __name__ == "__main__":\n    payload = '''${payloadJson.replace(/'''/g, "\\'\\'\\'")}'''\n    data_url = render_edumind_chart(payload)\n    print("Generated chart PNG data URL length:", len(data_url))\n`;

    return {
      imageDataUrl,
      pythonCode: standaloneScript,
      renderTimeMs,
    };
  } finally {
    try {
      pyodide.globals.delete('edumind_payload_json');
    } catch {
      // ignore cleanup error
    }
  }
}

const PYTHON_RADAR_CODE = `
import json
import io
import base64
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

def render_mastery_dashboard(payload_str):
    data = json.loads(payload_str)
    dims = data.get("dimensions", [])
    subj_scores = data.get("subjectAverages", [])
    active_subj = data.get("activeSubject", "Mathematics")

    plt.rcParams.update({
        "figure.facecolor": "#090e1a",
        "axes.facecolor": "#0f172a",
        "axes.edgecolor": "#334155",
        "text.color": "#f8fafc",
        "xtick.color": "#cbd5e1",
        "ytick.color": "#94a3b8",
        "font.sans-serif": ["DejaVu Sans"],
    })

    fig = plt.figure(figsize=(13, 5.4), dpi=150)
    ax1 = fig.add_subplot(121, polar=True)
    ax2 = fig.add_subplot(122)
    fig.subplots_adjust(left=0.07, right=0.96, top=0.82, bottom=0.14, wspace=0.34)

    fig.suptitle(
        f"Edumind AI — Python Cognitive Competency & Subject Analytics ({active_subj})",
        fontsize=13,
        fontweight="bold",
        color="#f8fafc",
        y=0.95
    )

    # Panel 1: Polar Radar Chart
    labels = [d["label"] for d in dims]
    values = [d["score"] for d in dims]
    angles = np.linspace(0, 2 * np.pi, len(labels), endpoint=False).tolist()
    values_closed = values + values[:1]
    angles_closed = angles + angles[:1]

    ax1.set_theta_offset(np.pi / 2)
    ax1.set_theta_direction(-1)
    ax1.set_facecolor("#0f172a")
    ax1.plot(angles_closed, values_closed, color="#38bdf8", linewidth=2.2, marker="o", markersize=5)
    ax1.fill(angles_closed, values_closed, color="#38bdf8", alpha=0.22)
    ax1.set_ylim(0, 100)
    ax1.set_yticks([25, 50, 75, 100])
    ax1.set_yticklabels(["25%", "50%", "75%", "100%"], fontsize=7.5, color="#64748b")
    ax1.set_xticks(angles)
    ax1.set_xticklabels(labels, fontsize=8.5, fontweight="bold", color="#e2e8f0")
    ax1.grid(color="#334155", linestyle=":", linewidth=0.9)
    ax1.spines["polar"].set_color("#334155")
    ax1.set_title("Cognitive Competency Radar", fontsize=10.5, fontweight="bold", pad=16, color="#f8fafc")

    # Panel 2: Subject Test Averages or Competency Bar Summary
    if subj_scores:
        s_names = [s["subject"] for s in subj_scores][::-1]
        s_vals = [s["avg"] for s in subj_scores][::-1]
        s_colors = ["#10b981" if v >= 80 else ("#f59e0b" if v >= 60 else "#f43f5e") for v in s_vals]
        y_pos = np.arange(len(s_names))
        bars = ax2.barh(y_pos, s_vals, color=s_colors, height=0.55, edgecolor="#020617")
        ax2.axvline(80, color="#818cf8", linestyle="--", linewidth=1.3, label="80% Mastery")
        ax2.set_yticks(y_pos)
        ax2.set_yticklabels(s_names, fontsize=8.5)
        ax2.set_xlim(0, 112)
        ax2.set_xlabel("Average Test Score (%)", fontsize=9)
        ax2.set_title("Test Averages by Subject", fontsize=10.5, fontweight="bold", loc="left", pad=12)
        ax2.grid(axis="x", linestyle=":", alpha=0.6)
        ax2.legend(loc="lower right", fontsize=8, facecolor="#020617", edgecolor="#334155")
        for bar, val in zip(bars, s_vals):
            ax2.text(min(val + 2, 100), bar.get_y() + bar.get_height() / 2, f"{val}%",
                     va="center", fontsize=8.5, fontweight="bold", color="#e2e8f0")
    else:
        y_pos = np.arange(len(labels))
        bars = ax2.barh(y_pos, values[::-1], color="#6366f1", height=0.55, edgecolor="#020617")
        ax2.axvline(80, color="#10b981", linestyle="--", linewidth=1.3, label="80% Target")
        ax2.set_yticks(y_pos)
        ax2.set_yticklabels(labels[::-1], fontsize=8.5)
        ax2.set_xlim(0, 112)
        ax2.set_xlabel("Competency Score (%)", fontsize=9)
        ax2.set_title("Competency Score Distribution", fontsize=10.5, fontweight="bold", loc="left", pad=12)
        ax2.grid(axis="x", linestyle=":", alpha=0.6)
        ax2.legend(loc="lower right", fontsize=8, facecolor="#020617", edgecolor="#334155")
        for bar, val in zip(bars, values[::-1]):
            ax2.text(min(val + 2, 100), bar.get_y() + bar.get_height() / 2, f"{val}%",
                     va="center", fontsize=8.5, fontweight="bold", color="#e2e8f0")

    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=150, facecolor=fig.get_facecolor())
    plt.close(fig)
    buf.seek(0)
    return "data:image/png;base64," + base64.b64encode(buf.read()).decode("utf-8")
`;

export async function renderMasteryRadarChart(
  masteryScores: {
    conceptualUnderstanding: number;
    analyticalProblemSolving: number;
    criticalThinking: number;
    retentionAndRecall: number;
    designThinkingMethod: number;
    examReadiness: number;
  },
  activeSubject: AcademicSubject,
  testHistory: TestAttemptResult[] = []
): Promise<string> {
  const pyodide = await getPyodideMatplotlib();

  const subjectMap: Record<string, { sum: number; count: number }> = {};
  testHistory.forEach((t) => {
    if (!subjectMap[t.subject]) subjectMap[t.subject] = { sum: 0, count: 0 };
    subjectMap[t.subject].sum += t.percentage;
    subjectMap[t.subject].count += 1;
  });

  const subjectAverages = Object.entries(subjectMap).map(([subject, stat]) => ({
    subject: subject.split('&')[0].trim(),
    avg: Math.round(stat.sum / stat.count),
  }));

  const payload = {
    activeSubject,
    dimensions: [
      { label: 'Conceptual\nDepth', score: masteryScores.conceptualUnderstanding },
      { label: 'Analytical\nSolving', score: masteryScores.analyticalProblemSolving },
      { label: 'Critical\nThinking', score: masteryScores.criticalThinking },
      { label: 'Active\nRecall', score: masteryScores.retentionAndRecall },
      { label: 'Design\nThinking', score: masteryScores.designThinkingMethod },
      { label: 'Exam\nReadiness', score: masteryScores.examReadiness },
    ],
    subjectAverages,
  };

  pyodide.globals.set('edumind_radar_payload', JSON.stringify(payload));
  try {
    const imgUrl: string = await pyodide.runPythonAsync(`
${PYTHON_RADAR_CODE}
render_mastery_dashboard(edumind_radar_payload)
`);
    return imgUrl;
  } finally {
    try {
      pyodide.globals.delete('edumind_radar_payload');
    } catch {
      // ignore
    }
  }
}

export interface PythonSandboxResult {
  stdout: string;
  stderr: string;
  imageDataUrl: string | null;
  executionTimeMs: number;
}

export async function runPythonSandbox(userCode: string): Promise<PythonSandboxResult> {
  const start = performance.now();
  const pyodide = await getPyodideMatplotlib();

  pyodide.globals.set('edumind_user_python_code', userCode);
  try {
    const jsonResult: string = await pyodide.runPythonAsync(`
import sys, io, json, base64, traceback
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

plt.close("all")
_stdout_buf = io.StringIO()
_stderr_buf = io.StringIO()
_old_stdout, _old_stderr = sys.stdout, sys.stderr
sys.stdout, sys.stderr = _stdout_buf, _stderr_buf

_img_data_url = None
try:
    exec_globals = {"np": np, "plt": plt, "__name__": "__main__"}
    exec(edumind_user_python_code, exec_globals)
    if plt.get_fignums():
        fig = plt.gcf()
        buf = io.BytesIO()
        fig.savefig(buf, format="png", dpi=140, bbox_inches="tight", facecolor=fig.get_facecolor())
        plt.close("all")
        buf.seek(0)
        _img_data_url = "data:image/png;base64," + base64.b64encode(buf.read()).decode("utf-8")
except Exception:
    traceback.print_exc(file=_stderr_buf)
finally:
    sys.stdout, sys.stderr = _old_stdout, _old_stderr
    plt.close("all")

json.dumps({
    "stdout": _stdout_buf.getvalue(),
    "stderr": _stderr_buf.getvalue(),
    "imageDataUrl": _img_data_url
})
`);
    const parsed = JSON.parse(jsonResult);
    return {
      stdout: parsed.stdout || '',
      stderr: parsed.stderr || '',
      imageDataUrl: parsed.imageDataUrl || null,
      executionTimeMs: Math.round(performance.now() - start),
    };
  } finally {
    try {
      pyodide.globals.delete('edumind_user_python_code');
    } catch {
      // ignore
    }
  }
}


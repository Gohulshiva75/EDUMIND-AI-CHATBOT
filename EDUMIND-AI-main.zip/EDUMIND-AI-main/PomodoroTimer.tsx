import React, { useState, useEffect, useRef } from 'react';
import { 
  Timer, 
  Play, 
  Pause, 
  RotateCcw, 
  Volume2, 
  VolumeX, 
  Sparkles, 
  Flame, 
  Coffee, 
  Brain,
  Headphones,
  CheckCircle2
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { soundscape } from '../../utils/audio';
import { StudentProfile } from '../../types';
import { calibrateMasteryWithPython } from '../../utils/pythonEngine';

interface PomodoroTimerProps {
  studentProfile: StudentProfile;
  onUpdateProfile: (updated: Partial<StudentProfile>) => void;
}

type Mode = 'focus' | 'shortBreak' | 'longBreak';

const MOTIVATIONAL_PROMPTS = [
  '“Small daily disciplines compound into technical mastery. Stay in flow.”',
  '“Focus on understanding the architecture first—the syntax is just mechanics.”',
  '“Design thinking begins with empathy, and studying begins with presence.”',
  '“Every error stack trace is a free diagnostic lesson from the JVM.”',
  '“Deep work for 25 minutes beats 3 hours of distracted browsing.”'
];

export const PomodoroTimer: React.FC<PomodoroTimerProps> = ({
  studentProfile,
  onUpdateProfile,
}) => {
  const [mode, setMode] = useState<Mode>('focus');
  const [timeLeft, setTimeLeft] = useState(25 * 60); // 25 minutes default
  const [isActive, setIsActive] = useState(false);
  const [soundMode, setSoundMode] = useState<'rain' | 'alpha' | 'library' | 'none'>('rain');
  const [sessionsCompleted, setSessionsCompleted] = useState(0);
  const [currentPromptIdx, setCurrentPromptIdx] = useState(0);

  const timerRef = useRef<any>(null);

  const getDuration = (m: Mode) => {
    switch (m) {
      case 'shortBreak': return 5 * 60;
      case 'longBreak': return 15 * 60;
      default: return 25 * 60;
    }
  };

  const switchMode = (newMode: Mode) => {
    setIsActive(false);
    setMode(newMode);
    setTimeLeft(getDuration(newMode));
  };

  useEffect(() => {
    if (isActive) {
      timerRef.current = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            clearInterval(timerRef.current);
            setIsActive(false);
            handleSessionComplete();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isActive, mode]);

  const handleSessionComplete = async () => {
    soundscape.playChime();

    if (mode === 'focus') {
      confetti({
        particleCount: 75,
        spread: 80,
        origin: { y: 0.6 },
      });

      const newSessions = sessionsCompleted + 1;
      setSessionsCompleted(newSessions);

      const newMastery = await calibrateMasteryWithPython(
        studentProfile.masteryScores,
        'FOCUS_COMPLETED',
        100
      );

      // Add 25 minutes to student profile and update Python-calibrated mastery
      onUpdateProfile({
        totalStudyMinutes: (studentProfile.totalStudyMinutes || 0) + 25,
        completedTasksCount: (studentProfile.completedTasksCount || 0) + 1,
        masteryScores: newMastery,
      });

      // Switch to break
      if (newSessions % 4 === 0) {
        switchMode('longBreak');
      } else {
        switchMode('shortBreak');
      }
    } else {
      switchMode('focus');
    }

    // Cycle motivational prompt
    setCurrentPromptIdx((prev) => (prev + 1) % MOTIVATIONAL_PROMPTS.length);
  };

  const handleTogglePlay = () => {
    if (!isActive) {
      if (soundMode !== 'none') {
        soundscape.playAmbient(soundMode);
      }
    }
    setIsActive(!isActive);
  };

  const handleReset = () => {
    setIsActive(false);
    setTimeLeft(getDuration(mode));
  };

  const handleSoundChange = (newSound: 'rain' | 'alpha' | 'library' | 'none') => {
    setSoundMode(newSound);
    if (newSound === 'none') {
      soundscape.stopAmbient();
    } else if (isActive) {
      soundscape.playAmbient(newSound);
    }
  };

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const formattedTime = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  const totalDuration = getDuration(mode);
  const progressPercent = Math.round(((totalDuration - timeLeft) / totalDuration) * 100);

  return (
    <div className="h-full flex flex-col bg-slate-950/60 overflow-hidden">
      {/* Top Header */}
      <div className="p-4 border-b border-slate-800/80 bg-slate-900/60 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-rose-500/20 text-rose-400 border border-rose-500/30 flex items-center justify-center">
            <Timer className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              Deep Work & Focus Timer
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-rose-500/10 text-rose-300 border border-rose-500/20">
                Pomodoro Technique
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              Synchronize focused coding sprints with cognitive recovery intervals
            </p>
          </div>
        </div>

        {/* Ambient audio toggles */}
        <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
          <Headphones className="w-3.5 h-3.5 text-cyan-400 ml-2 mr-1" />
          <button
            onClick={() => handleSoundChange('rain')}
            className={`px-2.5 py-1 rounded-lg transition-colors ${
              soundMode === 'rain' ? 'bg-cyan-500/20 text-cyan-300 font-semibold' : 'text-slate-400 hover:text-white'
            }`}
          >
            🌧️ Rain
          </button>
          <button
            onClick={() => handleSoundChange('alpha')}
            className={`px-2.5 py-1 rounded-lg transition-colors ${
              soundMode === 'alpha' ? 'bg-cyan-500/20 text-cyan-300 font-semibold' : 'text-slate-400 hover:text-white'
            }`}
          >
            🧠 Alpha
          </button>
          <button
            onClick={() => handleSoundChange('library')}
            className={`px-2.5 py-1 rounded-lg transition-colors ${
              soundMode === 'library' ? 'bg-cyan-500/20 text-cyan-300 font-semibold' : 'text-slate-400 hover:text-white'
            }`}
          >
            📚 Library
          </button>
          <button
            onClick={() => handleSoundChange('none')}
            className={`px-2.5 py-1 rounded-lg transition-colors ${
              soundMode === 'none' ? 'bg-slate-800 text-slate-300' : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            Mute
          </button>
        </div>
      </div>

      {/* Main Clock Area */}
      <div className="flex-1 overflow-y-auto p-6 flex flex-col items-center justify-center space-y-8 max-w-2xl mx-auto w-full">
        {/* Mode Selector Buttons */}
        <div className="flex items-center gap-2 p-1.5 rounded-2xl bg-slate-900 border border-slate-800 shadow-inner">
          <button
            onClick={() => switchMode('focus')}
            className={`px-5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              mode === 'focus'
                ? 'bg-rose-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Brain className="w-4 h-4" />
            <span>Focus Sprint (25m)</span>
          </button>

          <button
            onClick={() => switchMode('shortBreak')}
            className={`px-5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              mode === 'shortBreak'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Coffee className="w-4 h-4" />
            <span>Short Break (5m)</span>
          </button>

          <button
            onClick={() => switchMode('longBreak')}
            className={`px-5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              mode === 'longBreak'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>Long Break (15m)</span>
          </button>
        </div>

        {/* Big Circular Timer Display */}
        <div className="relative w-72 h-72 sm:w-80 sm:h-80 rounded-full bg-slate-900/80 border-4 border-slate-800 flex flex-col items-center justify-center shadow-2xl">
          {/* Subtle glow circle */}
          <div
            className={`absolute inset-0 rounded-full transition-opacity duration-1000 ${
              isActive ? 'opacity-30 blur-2xl bg-gradient-to-tr from-rose-500 to-indigo-500' : 'opacity-0'
            }`}
          />

          <span className="text-xs font-bold uppercase tracking-widest text-slate-400 mb-2">
            {mode === 'focus' ? 'Deep Focus Session' : mode === 'shortBreak' ? 'Cognitive Recovery' : 'Extended Rest'}
          </span>

          <div className="text-6xl sm:text-7xl font-mono font-black tracking-tight text-white select-none">
            {formattedTime}
          </div>

          <span className="text-xs text-rose-400 mt-2 font-medium">
            {progressPercent}% Elapsed
          </span>

          {/* Session badges */}
          <div className="flex items-center gap-1.5 mt-4">
            {[1, 2, 3, 4].map((s) => (
              <div
                key={s}
                className={`w-3 h-3 rounded-full transition-colors ${
                  s <= (sessionsCompleted % 4)
                    ? 'bg-rose-500 ring-2 ring-rose-500/30'
                    : 'bg-slate-800'
                }`}
                title={`Sprint #${s}`}
              />
            ))}
          </div>
        </div>

        {/* Play/Pause/Reset Controls */}
        <div className="flex items-center gap-4">
          <button
            onClick={handleTogglePlay}
            className={`px-8 py-3.5 rounded-2xl text-sm font-extrabold flex items-center gap-2.5 shadow-xl transition-all ${
              isActive
                ? 'bg-amber-600 hover:bg-amber-500 text-white shadow-amber-600/30'
                : 'bg-gradient-to-r from-rose-600 to-indigo-600 hover:from-rose-500 hover:to-indigo-500 text-white shadow-rose-600/30'
            }`}
          >
            {isActive ? <Pause className="w-5 h-5 fill-white" /> : <Play className="w-5 h-5 fill-white" />}
            <span>{isActive ? 'Pause Session' : 'Start Focus Sprint'}</span>
          </button>

          <button
            onClick={handleReset}
            className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
            title="Reset timer"
          >
            <RotateCcw className="w-5 h-5" />
          </button>
        </div>

        {/* Motivational Prompt Card */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-indigo-950/30 to-slate-900 border border-indigo-500/20 text-center max-w-lg shadow-sm">
          <div className="flex items-center justify-center gap-1.5 text-xs font-semibold text-indigo-400 mb-1">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Edumind Academic Mindset</span>
          </div>
          <p className="text-xs text-slate-300 italic leading-relaxed">
            {MOTIVATIONAL_PROMPTS[currentPromptIdx]}
          </p>
        </div>
      </div>
    </div>
  );
};

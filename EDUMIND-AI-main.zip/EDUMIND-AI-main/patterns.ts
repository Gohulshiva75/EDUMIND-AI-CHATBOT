/**
 * Java Design Patterns & Design Thinking Core Architecture
 * 
 * Implemented via object-oriented design patterns:
 * 1. Strategy Pattern (Pedagogical tutoring delivery)
 * 2. Factory & Builder Patterns (Study plan & syllabus construction)
 * 3. Observer Pattern (Student progress event bus)
 * 4. Chain of Responsibility Pattern (Academic subject & cognitive inquiry pipeline)
 */

import { StudentProfile, TutorMode, AcademicSubject, StudyPlan, QuizQuestion, Flashcard } from '../types';

// ==========================================
// 1. STRATEGY PATTERN (Behavioral Pattern)
// ==========================================
export interface ITutoringStrategy {
  readonly modeName: TutorMode;
  getPersonaTitle(): string;
  getPedagogicalContext(): string;
  formatResponseHeader(subject: AcademicSubject, topic: string): string;
  getSuggestedPills(subject: AcademicSubject): string[];
}

export class SocraticStrategy implements ITutoringStrategy {
  readonly modeName: TutorMode = 'socratic';

  getPersonaTitle(): string {
    return 'Socratic Academic Tutor';
  }

  getPedagogicalContext(): string {
    return 'Guide the student using guided questioning, scaffolding, and intuitive real-world analogies across any academic discipline.';
  }

  formatResponseHeader(subject: AcademicSubject, topic: string): string {
    return `🎓 **[${subject}] Socratic Exploration: ${topic}**\nLet's break down this concept from first principles:`;
  }

  getSuggestedPills(subject: AcademicSubject): string[] {
    switch (subject) {
      case 'Mathematics':
        return [
          'Explain the Fundamental Theorem of Calculus with an intuitive analogy',
          'Why does matrix multiplication work row-by-column?',
          'How do eigenvectors represent invariant directions?',
          'Help me understand Bayes Theorem step-by-step'
        ];
      case 'Physics & Astronomy':
        return [
          'Why does time dilate near the speed of light?',
          'Explain the Second Law of Thermodynamics and entropy',
          'How does electromagnetic induction generate electricity?',
          'Derive the simple harmonic oscillator equation'
        ];
      case 'Chemistry & BioChem':
        return [
          'Explain hybridization (sp3, sp2, sp) in molecular geometry',
          'Why do buffer solutions resist changes in pH?',
          'How do enzymes lower activation energy in metabolic pathways?',
          'Difference between SN1 and SN2 reaction mechanisms'
        ];
      case 'Biology & Medicine':
        return [
          'Trace the electron transport chain and ATP synthesis',
          'How does CRISPR-Cas9 locate and edit target DNA sequences?',
          'Explain the action potential propagation along an axon',
          'Humoral vs Cell-Mediated immunity mechanisms'
        ];
      case 'Economics & Business':
        return [
          'Explain the IS-LM macroeconomic equilibrium model',
          'What causes inflationary spirals and how do central banks react?',
          'Nash Equilibrium in non-cooperative game theory',
          'Price elasticity of demand vs total revenue'
        ];
      case 'History & Social Studies':
        return [
          'Analyze the socio-economic catalysts of the Industrial Revolution',
          'Compare and contrast the causes of WWI and WWII',
          'How did the Enlightenment shape modern constitutionalism?',
          'Evaluate the historical impact of the Silk Road'
        ];
      case 'Literature & Philosophy':
        return [
          'Analyze the tragic flaw in Shakespeare\'s Hamlet',
          'Explain Kant\'s Categorical Imperative vs Utilitarianism',
          'How to structure a persuasive literary thesis statement',
          'The allegory of Plato\'s Cave applied to modern information'
        ];
      default:
        return [
          'Break down this concept with an everyday physical analogy',
          'What are the core foundational axioms behind this topic?',
          'Give me a step-by-step example with a common trap to avoid',
          'How does this topic connect to real-world applications?'
        ];
    }
  }
}

export class ConceptualDeepDiveStrategy implements ITutoringStrategy {
  readonly modeName: TutorMode = 'deepExplanation';

  getPersonaTitle(): string {
    return 'Deep Conceptual Master';
  }

  getPedagogicalContext(): string {
    return 'Provide comprehensive, rigorous, first-principles academic breakdowns with derivations, diagrams, and historical/intellectual context.';
  }

  formatResponseHeader(subject: AcademicSubject, topic: string): string {
    return `🔬 **[${subject}] Deep Conceptual Dive: ${topic}**\nRigorous first-principles breakdown:`;
  }

  getSuggestedPills(subject: AcademicSubject): string[] {
    return [
      `Deep dive into the underlying axioms of ${subject}`,
      'Show the mathematical derivation or causal timeline',
      'Explain the edge cases and boundary conditions',
      'Compare competing theories or paradigms on this question'
    ];
  }
}

export class DesignThinkingProblemStrategy implements ITutoringStrategy {
  readonly modeName: TutorMode = 'designThinking';

  getPersonaTitle(): string {
    return 'Design Thinking Problem Solver';
  }

  getPedagogicalContext(): string {
    return 'Apply the 5-phase Design Thinking framework (Empathize, Define, Ideate, Prototype, Test) to solve complex academic problems, research questions, essays, and system designs.';
  }

  formatResponseHeader(subject: AcademicSubject, topic: string): string {
    return `💡 **[${subject}] Design Thinking Innovation: ${topic}**\nApplying the 5-Phase Problem Solving Engine:`;
  }

  getSuggestedPills(subject: AcademicSubject): string[] {
    return [
      'Empathize: Diagnose why students or researchers get stuck on this problem',
      'Define: Formulate a strong "How Might We" research question',
      'Ideate: Brainstorm 4 distinct solution hypotheses or thesis angles',
      'Prototype: Create a minimal proof-of-concept or essay outline'
    ];
  }
}

export class ExamDrillStrategy implements ITutoringStrategy {
  readonly modeName: TutorMode = 'examPrep';

  getPersonaTitle(): string {
    return 'Exam Prep & High-Yield Drill';
  }

  getPedagogicalContext(): string {
    return 'Deliver rapid bulleted summaries, mnemonics, cheat sheets, trap detection, and timed recall drills for upcoming exams.';
  }

  formatResponseHeader(subject: AcademicSubject, topic: string): string {
    return `⚡ **[${subject}] High-Yield Exam Drill: ${topic}**\nKey formulas, traps, and must-know flash points:`;
  }

  getSuggestedPills(subject: AcademicSubject): string[] {
    return [
      `Top 5 most tested exam questions in ${subject}`,
      'Create a 1-page formula & definition cheat sheet',
      'Highlight common trick questions and pitfalls to avoid',
      'Give me a rapid 3-question diagnostic sprint'
    ];
  }
}

// ====================================================
// 2. BUILDER & FACTORY PATTERNS (Creational Patterns)
// ==========================================
export class StudyPlanBuilder {
  private plan: Partial<StudyPlan> = {
    id: `plan-${Date.now()}`,
    createdAt: new Date().toISOString(),
    phases: [],
    tipsForSuccess: []
  };

  public setTitle(title: string): this {
    this.plan.title = title;
    return this;
  }

  public setSubject(subject: string): this {
    this.plan.subject = subject;
    return this;
  }

  public setOverview(overview: string): this {
    this.plan.overview = overview;
    return this;
  }

  public setTotalHours(hours: number): this {
    this.plan.totalEstimatedHours = hours;
    return this;
  }

  public setMethodology(methodology: string): this {
    this.plan.methodology = methodology;
    return this;
  }

  public addPhase(phaseNumber: number, phaseName: string, focus: string, daysSpan: string, modules: any[]): this {
    this.plan.phases?.push({
      phaseNumber,
      phaseName,
      focus,
      daysSpan,
      modules
    });
    return this;
  }

  public addTips(tips: string[]): this {
    this.plan.tipsForSuccess = tips;
    return this;
  }

  public build(): StudyPlan {
    if (!this.plan.title || !this.plan.subject) {
      throw new Error('StudyPlan must have title and subject');
    }
    return this.plan as StudyPlan;
  }
}

export class StudyPlanFactory {
  public static createDefaultPlanForSubject(subject: AcademicSubject): StudyPlan {
    const builder = new StudyPlanBuilder()
      .setSubject(subject)
      .setTitle(`${subject} Mastery & Exam Preparation Sprint`)
      .setOverview(`A comprehensive 14-day human-centered academic sprint for ${subject}, integrating the 5-phase Design Thinking cognitive framework (Empathize, Define, Ideate, Prototype, Test).`)
      .setTotalHours(28)
      .setMethodology('5-Phase Design Thinking & Active Recall Framework');

    // Phase 1: Empathize & Mental Models
    builder.addPhase(1, 'Phase 1: Foundations & Diagnostic Empathy', 'Diagnose knowledge gaps, build core intuition and physical analogies', 'Days 1 - 3', [
      {
        day: 1,
        topic: 'Foundational Axioms & Core Definitions',
        description: `Understand the primary principles of ${subject} without rote memorization.`,
        estimatedMinutes: 90,
        learningObjectives: ['Define key vocabulary', 'Identify foundational axioms', 'Build visual intuition'],
        practiceTask: 'Summarize the core theorem or thesis in under 3 sentences for a beginner.',
        completed: true
      },
      {
        day: 2,
        topic: 'Mechanism Breakdown & First Principles',
        description: 'Explore the causal relationships and underlying mechanisms driving the discipline.',
        estimatedMinutes: 90,
        learningObjectives: ['Trace cause-and-effect pipelines', 'Examine boundary conditions'],
        practiceTask: 'Draw a conceptual dependency graph connecting Day 1 and Day 2 concepts.',
        completed: false
      },
      {
        day: 3,
        topic: 'Historical Context & Key Experiments / Theses',
        description: 'Discover how this knowledge was originally discovered or theorized.',
        estimatedMinutes: 90,
        learningObjectives: ['Analyze pivotal discoveries', 'Evaluate historical paradigms'],
        practiceTask: 'Explain the counter-intuitive aspect of the landmark problem.',
        completed: false
      }
    ]);

    // Phase 2: Define & Analytical Rigor
    builder.addPhase(2, 'Phase 2: Define & Analytical Frameworks', 'Formalizing formulas, proofs, methodologies, and structural frameworks', 'Days 4 - 7', [
      {
        day: 4,
        topic: 'Analytical Frameworks & Quantitative Models',
        description: 'Deep dive into formal notation, mathematical models, or analytical lenses.',
        estimatedMinutes: 100,
        learningObjectives: ['Solve benchmark equations or text analyses', 'Master formal notations'],
        practiceTask: 'Work through 3 standard textbook benchmark problems with step-by-step commentary.',
        completed: false
      },
      {
        day: 5,
        topic: 'Complex Problem Solving & Edge Cases',
        description: 'Navigating ambiguous, multi-variable, or nuanced academic challenges.',
        estimatedMinutes: 100,
        learningObjectives: ['Decompose complex word problems', 'Spot subtle boundary traps'],
        practiceTask: 'Dissect an ambiguous case study and formulate a definitive solution.',
        completed: false
      },
      {
        day: 6,
        topic: 'Comparative Analysis & Alternative Theories',
        description: 'Contrasting competing paradigms or problem-solving approaches.',
        estimatedMinutes: 90,
        learningObjectives: ['Compare methodology A vs methodology B', 'Assess trade-offs'],
        practiceTask: 'Write a 1-page comparative synthesis highlighting key differences.',
        completed: false
      },
      {
        day: 7,
        topic: 'Mid-Sprint Synthesis & Knowledge Audit',
        description: 'Reflective checkpoint to seal conceptual leaks before advancing.',
        estimatedMinutes: 80,
        learningObjectives: ['Self-audit weak areas', 'Refine study cheat sheet'],
        practiceTask: 'Complete a 15-minute closed-book brain dump of all concepts learned so far.',
        completed: false
      }
    ]);

    // Phase 3: Ideate & Synthesis
    builder.addPhase(3, 'Phase 3: Ideate & Lateral Connections', 'Synthesizing cross-disciplinary links and advanced applications', 'Days 8 - 10', [
      {
        day: 8,
        topic: 'Interdisciplinary Synthesis',
        description: `Connecting ${subject} to adjacent fields and modern real-world systems.`,
        estimatedMinutes: 90,
        learningObjectives: ['Identify lateral transfer points', 'Synthesize novel arguments'],
        practiceTask: 'Apply this concept to solve a contemporary real-world problem.',
        completed: false
      },
      {
        day: 9,
        topic: 'Advanced Problem Sets & Research Applications',
        description: 'Tackling higher-order problems from advanced past papers or papers.',
        estimatedMinutes: 110,
        learningObjectives: ['High-level problem decomposition', 'Refine analytical speed'],
        practiceTask: 'Solve 2 advanced Olympiad/AP/University-level challenge questions.',
        completed: false
      },
      {
        day: 10,
        topic: 'Error Analysis & Common Exam Traps',
        description: 'Dissecting the top misconceptions that cost students points on exams.',
        estimatedMinutes: 80,
        learningObjectives: ['Identify negative trap patterns', 'Develop verification habits'],
        practiceTask: 'Create an "Anti-Pattern / Trap Sheet" documenting the 5 easiest mistakes to make.',
        completed: false
      }
    ]);

    // Phase 4: Prototype & Drill
    builder.addPhase(4, 'Phase 4: Prototype & Active Recall', 'Building speed, muscle memory, and structured cheat sheets', 'Days 11 - 12', [
      {
        day: 11,
        topic: 'Rapid Retrieval Drills & Flashcard Sprint',
        description: 'Spaced repetition drills across all definitions, formulas, and dates.',
        estimatedMinutes: 90,
        learningObjectives: ['Sub-second formula retrieval', 'Active recall fluency'],
        practiceTask: 'Test yourself on 25 flashcards with >85% accuracy.',
        completed: false
      },
      {
        day: 12,
        topic: 'Timed Exam Simulation Sprint',
        description: 'Practicing under realistic time constraints to eliminate exam anxiety.',
        estimatedMinutes: 100,
        learningObjectives: ['Pacing management', 'Triage difficult vs easy questions'],
        practiceTask: 'Simulate a 45-minute timed mock test without checking references.',
        completed: false
      }
    ]);

    // Phase 5: Test & Final Reflection
    builder.addPhase(5, 'Phase 5: Test & Capstone Mastery', 'Comprehensive mock exam, reflection, and final mastery sign-off', 'Days 13 - 14', [
      {
        day: 13,
        topic: 'Full Diagnostic Mock Exam & Review',
        description: 'Comprehensive test covering all 12 days of learning.',
        estimatedMinutes: 120,
        learningObjectives: ['Validate retention and problem solving', 'Score >80% accuracy'],
        practiceTask: 'Take the Edumind AI Full Diagnostic Exam and review explanations for any mistakes.',
        completed: false
      },
      {
        day: 14,
        topic: 'Final Design Thinking Reflection & Confidence Walk',
        description: 'Reflect on growth, solidify mental models, and finalize exam day strategy.',
        estimatedMinutes: 60,
        learningObjectives: ['Solidify confidence', 'Finalize summary sheet'],
        practiceTask: 'Celebrate sprint completion and review the 1-page high-yield cheat sheet.',
        completed: false
      }
    ]);

    builder.addTips([
      'Study in 25-minute Pomodoro intervals to prevent cognitive exhaustion.',
      'Explain difficult concepts aloud in simple words (Feynman Technique).',
      'Use the Design Thinking Studio whenever you encounter a tricky multi-step problem.',
      'Review mistakes immediately with Edumind AI rather than letting doubts linger.'
    ]);

    return builder.build();
  }
}

// ==========================================
// 3. OBSERVER PATTERN (Behavioral Pattern)
// ==========================================
export type LearningEventType = 
  | 'TASK_COMPLETED' 
  | 'POMODORO_FINISHED' 
  | 'QUIZ_SUBMITTED' 
  | 'STREAK_UPDATED';

export interface LearningEvent {
  type: LearningEventType;
  payload: any;
  timestamp: number;
}

export interface ILearningObserver {
  onLearningEvent(event: LearningEvent, profile: StudentProfile): Partial<StudentProfile> | void;
}

export class StreakCounterObserver implements ILearningObserver {
  onLearningEvent(event: LearningEvent, profile: StudentProfile): Partial<StudentProfile> | void {
    if (event.type === 'TASK_COMPLETED' || event.type === 'POMODORO_FINISHED') {
      return {
        completedTasksCount: (profile.completedTasksCount || 0) + 1,
      };
    }
  }
}

export class MasteryScoreObserver implements ILearningObserver {
  onLearningEvent(event: LearningEvent, profile: StudentProfile): Partial<StudentProfile> | void {
    if (event.type === 'QUIZ_SUBMITTED') {
      const { scorePercent } = event.payload;
      const updatedScores = { ...profile.masteryScores };
      
      // Update generalized academic scores
      updatedScores.retentionAndRecall = Math.min(100, Math.round((updatedScores.retentionAndRecall + scorePercent) / 2));
      updatedScores.examReadiness = Math.min(100, Math.round((updatedScores.examReadiness + scorePercent) / 2));
      updatedScores.analyticalProblemSolving = Math.min(100, Math.round((updatedScores.analyticalProblemSolving + scorePercent * 0.9) / 2));
      
      return { masteryScores: updatedScores };
    }
  }
}

export class LearningEventDispatcher {
  private observers: ILearningObserver[] = [];

  public register(observer: ILearningObserver): void {
    this.observers.push(observer);
  }

  public dispatch(event: LearningEvent, profile: StudentProfile): StudentProfile {
    let currentProfile = { ...profile };
    for (const observer of this.observers) {
      const update = observer.onLearningEvent(event, currentProfile);
      if (update) {
        currentProfile = { ...currentProfile, ...update };
      }
    }
    return currentProfile;
  }
}

// ========================================================
// 4. CHAIN OF RESPONSIBILITY PATTERN (Behavioral Pattern)
// ========================================================
export interface AcademicInquiryContext {
  query: string;
  detectedSubject?: AcademicSubject;
  cognitiveLevel?: 'Remember' | 'Understand' | 'Apply' | 'Analyze' | 'Evaluate' | 'Create';
  recommendedMode?: TutorMode;
  enrichedPrompt?: string;
}

export abstract class AcademicInquiryHandler {
  protected nextHandler?: AcademicInquiryHandler;

  public setNext(handler: AcademicInquiryHandler): AcademicInquiryHandler {
    this.nextHandler = handler;
    return handler;
  }

  public handle(context: AcademicInquiryContext): AcademicInquiryContext {
    const updated = this.process(context);
    if (this.nextHandler) {
      return this.nextHandler.handle(updated);
    }
    return updated;
  }

  protected abstract process(context: AcademicInquiryContext): AcademicInquiryContext;
}

export class SubjectClassifierHandler extends AcademicInquiryHandler {
  protected process(context: AcademicInquiryContext): AcademicInquiryContext {
    const q = context.query.toLowerCase();

    // Check for physics queries (forces, mechanics, astronomy, waves, energy)
    const physicsTerms = [
      'newton', 'force', 'friction', 'acceleration', 'velocity', 'gravity', 'momentum',
      'kinetic', 'potential energy', 'relativity', 'quantum', 'thermodynamics', 'optics',
      'magnetic', 'electron', 'circuit', 'voltage', 'current', 'resistance', 'wave',
      'frequency', 'photon', 'schrodinger', 'einstein', 'planet', 'galaxy', 'star',
      'black hole', 'torque', 'inertia', 'joule', 'watt', 'astronomy', 'kinematics',
      'dynamics', 'pendulum', 'projectile', 'centripetal', 'doppler'
    ];

    // Check for mathematics queries (algebra, calculus, geometry, equations)
    const mathTerms = [
      'derivative', 'integral', 'calculus', 'matrix', 'vector', 'algebra', 'polynomial',
      'geometry', 'probability', 'equation', 'solve for', 'formula', 'pythagor', 'triangle',
      'sine', 'cosine', 'tangent', 'trigonometry', 'logarithm', 'limit', 'fraction',
      'arithmetic', 'statistics', 'variance', 'proof', 'theorem', 'hypotenuse', 'eigenvalue',
      'quadratic', 'quadratic equation', 'differential equation', 'prime number', 'linear algebra'
    ];

    // Check for chemistry queries (reactions, bonding, elements)
    const chemistryTerms = [
      'acid', 'base', 'ph scale', 'molecule', 'stoichiometry', 'periodic table', 'orbital',
      'organic chemistry', 'equilibrium', 'compound', 'chemical reaction', 'ion', 'covalent',
      'enthalpy', 'redox', 'titration', 'catalyst', 'molar', 'mole', 'chemical bond',
      'polymer', 'isotope', 'distillation', 'electronegativity', 'valence'
    ];

    // Check for biology & medicine queries (cells, genetics, physiology)
    const biologyTerms = [
      'dna', 'rna', 'cell', 'gene', 'evolution', 'organism', 'mitochondria', 'enzyme',
      'photosynthesis', 'mitosis', 'meiosis', 'anatomy', 'organ', 'brain', 'heart',
      'disease', 'virus', 'bacteria', 'ecology', 'ecosystem', 'protein synthesis',
      'vaccine', 'immune', 'physiology', 'respiration', 'chromosome', 'biology'
    ];

    // Check for computer science queries (programming, algorithms)
    const csTerms = [
      'code', 'algorithm', 'python', 'java', 'c++', 'javascript', 'data structure',
      'binary tree', 'binary search', 'recursion', 'complexity', 'big o', 'database',
      'sql', 'api', 'machine learning', 'neural network', 'software', 'class', 'method',
      'compiler', 'debugging', 'frontend', 'backend', 'object oriented', 'git'
    ];

    // Check for economics queries (markets, finance, fiscal policy)
    const econTerms = [
      'inflation', 'gdp', 'monetary policy', 'market', 'fiscal', 'supply and demand',
      'elasticity', 'interest rate', 'stock market', 'finance', 'revenue', 'profit',
      'monopoly', 'trade deficit', 'macroeconomics', 'microeconomics', 'capitalism',
      'opportunity cost', 'pricing'
    ];

    // Check for history queries (events, eras, civil movements)
    const historyTerms = [
      'war', 'treaty', 'revolution', 'century', 'empire', 'constitution', 'civil rights',
      'ancient rome', 'ancient greece', 'medieval', 'cold war', 'world war', 'renaissance',
      'feudalism', 'monarchy', 'president', 'colonization', 'democracy', 'historian', 'historical'
    ];

    // Check for literature & philosophy queries (authors, themes, ethics)
    const litTerms = [
      'poem', 'poetry', 'metaphor', 'novel', 'philosophy', 'existentialism', 'thesis statement',
      'shakespeare', 'ethics', 'morality', 'socrates', 'plato', 'aristotle', 'kant',
      'nietzsche', 'epistemology', 'utilitarianism', 'literary', 'allegory', 'symbolism'
    ];

    // Check for engineering queries
    const engineeringTerms = [
      'stress and strain', 'truss', 'beam', 'structural', 'mechanical engineering',
      'civil engineering', 'cad', 'robotics', 'control system', 'fluid dynamics', 'heat transfer'
    ];

    // Score match helper
    const countMatches = (terms: string[]) => terms.reduce((acc, term) => acc + (q.includes(term) ? (term.includes(' ') ? 2 : 1) : 0), 0);

    const scores: { subject: AcademicSubject; score: number }[] = [
      { subject: 'Physics & Astronomy', score: countMatches(physicsTerms) },
      { subject: 'Mathematics', score: countMatches(mathTerms) },
      { subject: 'Chemistry & BioChem', score: countMatches(chemistryTerms) },
      { subject: 'Biology & Medicine', score: countMatches(biologyTerms) },
      { subject: 'Computer Science & AI', score: countMatches(csTerms) },
      { subject: 'Economics & Business', score: countMatches(econTerms) },
      { subject: 'History & Social Studies', score: countMatches(historyTerms) },
      { subject: 'Literature & Philosophy', score: countMatches(litTerms) },
      { subject: 'Engineering', score: countMatches(engineeringTerms) },
    ];

    scores.sort((a, b) => b.score - a.score);

    if (scores[0] && scores[0].score > 0) {
      context.detectedSubject = scores[0].subject;
    }

    return context;
  }
}

export class CognitiveBloomHandler extends AcademicInquiryHandler {
  protected process(context: AcademicInquiryContext): AcademicInquiryContext {
    const q = context.query.toLowerCase();

    if (q.includes('why') || q.includes('explain') || q.includes('how does')) {
      context.cognitiveLevel = 'Understand';
    } else if (q.includes('solve') || q.includes('calculate') || q.includes('find the') || q.includes('derive')) {
      context.cognitiveLevel = 'Apply';
    } else if (q.includes('compare') || q.includes('contrast') || q.includes('difference between') || q.includes('analyze')) {
      context.cognitiveLevel = 'Analyze';
    } else if (q.includes('evaluate') || q.includes('critique') || q.includes('is it true')) {
      context.cognitiveLevel = 'Evaluate';
    } else if (q.includes('design') || q.includes('create') || q.includes('brainstorm') || q.includes('write an outline')) {
      context.cognitiveLevel = 'Create';
      context.recommendedMode = 'designThinking';
    } else {
      context.cognitiveLevel = 'Remember';
    }

    return context;
  }
}

export class DesignThinkingContextEnricher extends AcademicInquiryHandler {
  protected process(context: AcademicInquiryContext): AcademicInquiryContext {
    const subjectPrefix = context.detectedSubject ? `[Academic Subject: ${context.detectedSubject}] ` : '';
    const cognitivePrefix = context.cognitiveLevel ? `[Cognitive Bloom Level: ${context.cognitiveLevel}] ` : '';
    
    context.enrichedPrompt = `${subjectPrefix}${cognitivePrefix}${context.query}`.trim();
    return context;
  }
}

// Assemble the Chain
export function createAcademicInquiryPipeline(): AcademicInquiryHandler {
  const subjectHandler = new SubjectClassifierHandler();
  const bloomHandler = new CognitiveBloomHandler();
  const enrichHandler = new DesignThinkingContextEnricher();

  subjectHandler.setNext(bloomHandler).setNext(enrichHandler);
  return subjectHandler;
}

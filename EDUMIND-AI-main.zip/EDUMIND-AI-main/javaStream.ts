/**
 * JavaStream<T>
 * 
 * An emulation of the Java 8+ java.util.stream.Stream interface implemented in TypeScript.
 * Demonstrates functional stream processing, lazy pipeline design, and intermediate/terminal operations.
 */
export class JavaStream<T> {
  private items: T[];

  private constructor(items: T[]) {
    this.items = items;
  }

  /**
   * Static factory method: Stream.of(...)
   */
  public static of<T>(...items: T[]): JavaStream<T> {
    return new JavaStream([...items]);
  }

  /**
   * Static factory method from an array or iterable
   */
  public static from<T>(iterable: Iterable<T>): JavaStream<T> {
    return new JavaStream(Array.from(iterable));
  }

  /**
   * Intermediate operation: filter
   * Returns a stream consisting of the elements that match the given predicate.
   */
  public filter(predicate: (item: T, index: number) => boolean): JavaStream<T> {
    return new JavaStream(this.items.filter(predicate));
  }

  /**
   * Intermediate operation: map
   * Returns a stream consisting of the results of applying the given function to the elements.
   */
  public map<R>(mapper: (item: T, index: number) => R): JavaStream<R> {
    return new JavaStream(this.items.map(mapper));
  }

  /**
   * Intermediate operation: flatMap
   */
  public flatMap<R>(mapper: (item: T) => R[]): JavaStream<R> {
    const flattened: R[] = [];
    for (const item of this.items) {
      flattened.push(...mapper(item));
    }
    return new JavaStream(flattened);
  }

  /**
   * Intermediate operation: distinct
   */
  public distinct(): JavaStream<T> {
    return new JavaStream(Array.from(new Set(this.items)));
  }

  /**
   * Intermediate operation: sorted
   */
  public sorted(comparator?: (a: T, b: T) => number): JavaStream<T> {
    return new JavaStream([...this.items].sort(comparator));
  }

  /**
   * Intermediate operation: limit
   */
  public limit(maxSize: number): JavaStream<T> {
    return new JavaStream(this.items.slice(0, maxSize));
  }

  /**
   * Intermediate operation: skip
   */
  public skip(n: number): JavaStream<T> {
    return new JavaStream(this.items.slice(n));
  }

  /**
   * Terminal operation: collect (to array)
   */
  public collect(): T[] {
    return [...this.items];
  }

  /**
   * Terminal operation: forEach
   */
  public forEach(action: (item: T) => void): void {
    this.items.forEach(action);
  }

  /**
   * Terminal operation: reduce
   */
  public reduce<U>(identity: U, accumulator: (acc: U, item: T) => U): U {
    return this.items.reduce(accumulator, identity);
  }

  /**
   * Terminal operation: count
   */
  public count(): number {
    return this.items.length;
  }

  /**
   * Terminal operation: anyMatch
   */
  public anyMatch(predicate: (item: T) => boolean): boolean {
    return this.items.some(predicate);
  }

  /**
   * Terminal operation: allMatch
   */
  public allMatch(predicate: (item: T) => boolean): boolean {
    return this.items.every(predicate);
  }

  /**
   * Terminal operation: findFirst
   */
  public findFirst(): T | undefined {
    return this.items.length > 0 ? this.items[0] : undefined;
  }
}

import React, { useState } from 'react';
import katex from 'katex';
import { Copy, Check, Terminal, Sigma } from 'lucide-react';

interface MathMarkdownRendererProps {
  content: string;
  msgId: string;
}

/**
 * Safely render KaTeX math string (block or inline)
 */
function renderKatexToString(math: string, displayMode: boolean): string {
  try {
    return katex.renderToString(math.trim(), {
      displayMode,
      throwOnError: false,
      output: 'htmlAndMathml',
    });
  } catch (err) {
    return `<span class="katex-error font-mono text-xs text-amber-400 bg-amber-950/40 px-1 py-0.5 rounded">${math}</span>`;
  }
}

/**
 * Helper to render inline markdown including bold, italic, code, and inline LaTeX ($...$ or \(...\))
 */
const InlineRenderer: React.FC<{ text: string }> = ({ text }) => {
  const tokens = text.split(
    /(\$\$[\s\S]*?\$\$|\\\[[\s\S]*?\\\]|(?<!\w)\$[^\$\n]+?\$(?!\w)|\\\(.+?\\\)|`[^`]+`|\*\*[^*]+?\*\*|\*[^*]+?\*)/g
  );

  return (
    <>
      {tokens.map((token, idx) => {
        if (!token) return null;

        // Block math within inline line (rare, but handle gracefully)
        if (token.startsWith('$$') && token.endsWith('$$')) {
          const math = token.slice(2, -2);
          const html = renderKatexToString(math, true);
          return (
            <span
              key={idx}
              className="block my-2 text-center overflow-x-auto text-cyan-200"
              dangerouslySetInnerHTML={{ __html: html }}
            />
          );
        }

        if (token.startsWith('\\[') && token.endsWith('\\]')) {
          const math = token.slice(2, -2);
          const html = renderKatexToString(math, true);
          return (
            <span
              key={idx}
              className="block my-2 text-center overflow-x-auto text-cyan-200"
              dangerouslySetInnerHTML={{ __html: html }}
            />
          );
        }

        // Inline math with $...$
        if (token.startsWith('$') && token.endsWith('$') && token.length > 2) {
          const math = token.slice(1, -1);
          // Check if it's just currency like "$10"
          if (/^\d+(\.\d+)?$/.test(math.trim())) {
            return <span key={idx}>${math}</span>;
          }
          const html = renderKatexToString(math, false);
          return (
            <span
              key={idx}
              className="inline-math px-1 py-0.5 rounded bg-indigo-950/40 text-cyan-200 mx-0.5 inline-block align-baseline hover:bg-indigo-900/40 transition-colors"
              title={math}
              dangerouslySetInnerHTML={{ __html: html }}
            />
          );
        }

        // Inline math with \(...\)
        if (token.startsWith('\\(') && token.endsWith('\\)') && token.length > 4) {
          const math = token.slice(2, -2);
          const html = renderKatexToString(math, false);
          return (
            <span
              key={idx}
              className="inline-math px-1 py-0.5 rounded bg-indigo-950/40 text-cyan-200 mx-0.5 inline-block align-baseline hover:bg-indigo-900/40 transition-colors"
              title={math}
              dangerouslySetInnerHTML={{ __html: html }}
            />
          );
        }

        // Inline code `...`
        if (token.startsWith('`') && token.endsWith('`') && token.length > 2) {
          return (
            <code
              key={idx}
              className="font-mono text-xs px-1.5 py-0.5 rounded bg-slate-800 text-indigo-300 border border-slate-700/60"
            >
              {token.slice(1, -1)}
            </code>
          );
        }

        // Bold **...**
        if (token.startsWith('**') && token.endsWith('**') && token.length > 4) {
          return (
            <strong key={idx} className="font-semibold text-white">
              <InlineRenderer text={token.slice(2, -2)} />
            </strong>
          );
        }

        // Italic *...*
        if (token.startsWith('*') && token.endsWith('*') && token.length > 2) {
          return (
            <em key={idx} className="italic text-slate-200">
              <InlineRenderer text={token.slice(1, -1)} />
            </em>
          );
        }

        return <span key={idx}>{token}</span>;
      })}
    </>
  );
};

export const MathMarkdownRenderer: React.FC<MathMarkdownRendererProps> = ({ content, msgId }) => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  // 1. First split content into major blocks: Code Blocks (```...```) and Block Math ($$...$$ and \[...\])
  const blocks = content.split(/(```[\s\S]*?```|\$\$[\s\S]*?\$\$|\\\[[\s\S]*?\\\])/g);

  return (
    <div className="space-y-2 text-sm leading-relaxed text-slate-200">
      {blocks.map((block, bIdx) => {
        if (!block) return null;

        // --- CODE BLOCK ---
        if (block.startsWith('```')) {
          const firstLineEnd = block.indexOf('\n');
          const lang = block.substring(3, firstLineEnd > -1 ? firstLineEnd : block.length).trim() || 'text';
          const code = firstLineEnd > -1 ? block.substring(firstLineEnd + 1, block.endsWith('```') ? block.length - 3 : block.length).trim() : '';
          const copyId = `${msgId}-code-${bIdx}`;

          return (
            <div
              key={bIdx}
              className="my-3 rounded-xl overflow-hidden border border-slate-700/80 bg-slate-950 shadow-md ring-1 ring-slate-800/60"
            >
              <div className="bg-slate-900/90 px-3.5 py-1.5 border-b border-slate-800 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 text-slate-400 font-mono text-[11px]">
                  <Terminal className="w-3.5 h-3.5 text-cyan-400" />
                  <span className="font-semibold text-slate-300">{lang.toUpperCase()}</span>
                </div>
                <button
                  onClick={() => copyToClipboard(code, copyId)}
                  className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] flex items-center gap-1 transition-colors"
                >
                  {copiedKey === copyId ? (
                    <>
                      <Check className="w-3 h-3 text-emerald-400" /> Copied
                    </>
                  ) : (
                    <>
                      <Copy className="w-3 h-3" /> Copy
                    </>
                  )}
                </button>
              </div>
              <pre className="p-4 text-xs font-mono text-emerald-300/90 overflow-x-auto leading-relaxed bg-slate-950/95 selection:bg-emerald-900/50">
                <code>{code}</code>
              </pre>
            </div>
          );
        }

        // --- DISPLAY / BLOCK EQUATION ($$...$$ or \[...\]) ---
        if (
          (block.startsWith('$$') && (block.endsWith('$$') || block.length > 2)) ||
          (block.startsWith('\\[') && (block.endsWith('\\]') || block.length > 2))
        ) {
          const isDollar = block.startsWith('$$');
          const math = isDollar
            ? block.slice(2, block.endsWith('$$') && block.length >= 4 ? -2 : undefined).trim()
            : block.slice(2, block.endsWith('\\]') && block.length >= 4 ? -2 : undefined).trim();

          const mathHtml = renderKatexToString(math, true);
          const copyId = `${msgId}-math-${bIdx}`;

          return (
            <div
              key={bIdx}
              className="my-3 relative group rounded-xl border border-indigo-500/30 bg-gradient-to-r from-slate-950 via-indigo-950/20 to-slate-950 p-4 shadow-md overflow-x-auto ring-1 ring-indigo-500/10"
            >
              <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800/80 text-[11px] text-indigo-400">
                <div className="flex items-center gap-1.5 font-semibold">
                  <Sigma className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Mathematical Derivation / Formula</span>
                </div>
                <button
                  onClick={() => copyToClipboard(math, copyId)}
                  className="opacity-60 group-hover:opacity-100 transition-opacity px-2 py-0.5 rounded bg-slate-800/80 hover:bg-slate-700 text-slate-300 text-[10px] flex items-center gap-1"
                  title="Copy LaTeX source"
                >
                  {copiedKey === copyId ? (
                    <>
                      <Check className="w-3 h-3 text-emerald-400" /> Copied LaTeX
                    </>
                  ) : (
                    <>
                      <Copy className="w-3 h-3" /> Copy LaTeX
                    </>
                  )}
                </button>
              </div>
              <div
                className="text-base text-cyan-200 py-1 text-center overflow-x-auto scrollbar-thin select-text"
                dangerouslySetInnerHTML={{ __html: mathHtml }}
              />
            </div>
          );
        }

        // --- REGULAR MARKDOWN PARAGRAPH / SECTIONS ---
        const lines = block.split('\n');

        return (
          <div key={bIdx} className="space-y-1.5">
            {lines.map((line, lIdx) => {
              const trimmed = line.trim();

              // Empty line
              if (!trimmed) {
                return <div key={lIdx} className="h-1.5" />;
              }

              // Heading 1
              if (line.startsWith('# ')) {
                return (
                  <h1 key={lIdx} className="text-xl font-extrabold text-white pt-3 pb-1 border-b border-slate-700">
                    <InlineRenderer text={line.slice(2)} />
                  </h1>
                );
              }

              // Heading 2
              if (line.startsWith('## ')) {
                return (
                  <h2 key={lIdx} className="text-lg font-bold text-white pt-2.5 pb-1 border-b border-slate-800">
                    <InlineRenderer text={line.slice(3)} />
                  </h2>
                );
              }

              // Heading 3
              if (line.startsWith('### ')) {
                return (
                  <h3 key={lIdx} className="text-base font-semibold text-cyan-300 pt-2 pb-0.5">
                    <InlineRenderer text={line.slice(4)} />
                  </h3>
                );
              }

              // Horizontal rule
              if (trimmed === '---' || trimmed === '***') {
                return <hr key={lIdx} className="border-slate-800 my-2" />;
              }

              // Bullet list (- or *)
              if (/^(\s*[-*]\s+)/.test(line)) {
                const content = line.replace(/^(\s*[-*]\s+)/, '');
                return (
                  <div key={lIdx} className="flex items-start gap-2 pl-2">
                    <span className="text-indigo-400 text-sm leading-tight mt-0.5 shrink-0">•</span>
                    <div className="flex-1">
                      <InlineRenderer text={content} />
                    </div>
                  </div>
                );
              }

              // Numbered list
              if (/^(\s*\d+\.\s+)/.test(line)) {
                const match = line.match(/^(\s*\d+\.\s+)/);
                const prefix = match ? match[0].trim() : '1.';
                const content = line.replace(/^(\s*\d+\.\s+)/, '');
                return (
                  <div key={lIdx} className="flex items-start gap-2 pl-2">
                    <span className="text-cyan-400 font-semibold text-xs leading-relaxed shrink-0 min-w-4">
                      {prefix}
                    </span>
                    <div className="flex-1">
                      <InlineRenderer text={content} />
                    </div>
                  </div>
                );
              }

              // Blockquote (> )
              if (line.startsWith('> ')) {
                return (
                  <blockquote
                    key={lIdx}
                    className="border-l-2 border-indigo-500 pl-3 py-1 my-1.5 italic text-slate-300 bg-indigo-950/20 rounded-r-lg"
                  >
                    <InlineRenderer text={line.slice(2)} />
                  </blockquote>
                );
              }

              // Regular paragraph
              return (
                <p key={lIdx} className="leading-relaxed">
                  <InlineRenderer text={line} />
                </p>
              );
            })}
          </div>
        );
      })}
    </div>
  );
};

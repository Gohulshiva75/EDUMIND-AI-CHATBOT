import express from 'express';
import type { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '10mb' }));

// CORS middleware for AI agents and external tools access
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, x-requested-with');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  next();
});

// AI Access Health & Discovery Endpoints
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status: 'healthy',
    service: 'Edumind AI Student Companion',
    version: '2.5.0',
    model: 'gemini-flash-lite-latest',
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
  });
});

app.get('/api/ai-access', (_req: Request, res: Response) => {
  res.json({
    name: 'Edumind AI API',
    description: 'Universal Intelligent Student Companion & Academic Support Platform with Java OOP Architecture and 5-Phase Design Thinking pipeline',
    version: '2.5.0',
    endpoints: [
      {
        path: '/api/chat',
        method: 'POST',
        description: 'Server-Sent Events (SSE) streaming chat tutor for any academic subject',
        payload: {
          messages: [{ role: 'user', content: 'string' }],
          mode: 'socratic | deepExplanation | designThinking | examPrep',
          subject: 'string (e.g., Mathematics, Physics, Chemistry, Biology, Economics, History)',
          studentContext: 'string (optional learner profile)'
        }
      },
      {
        path: '/api/generate-study-plan',
        method: 'POST',
        description: 'Generates structured 5-phase Design Thinking study syllabus in JSON',
        payload: {
          subject: 'string',
          level: 'Beginner | Intermediate | Advanced',
          targetDays: 'number',
          dailyHours: 'number',
          goals: 'string'
        }
      },
      {
        path: '/api/analyze-academic-problem',
        method: 'POST',
        description: 'Evaluates derivations, calculations, and homework across STEM/humanities',
        payload: {
          problemText: 'string',
          studentWork: 'string',
          subject: 'string'
        }
      },
      {
        path: '/api/generate-quiz',
        method: 'POST',
        description: 'Generates adaptive multiple-choice diagnostic questions',
        payload: {
          topic: 'string',
          subject: 'string',
          difficulty: 'easy | medium | hard',
          count: 'number'
        }
      },
      {
        path: '/api/design-thinking-assist',
        method: 'POST',
        description: 'Provides guided Design Thinking facilitation for academic problem decomposition',
        payload: {
          phase: 'Empathize | Define | Ideate | Prototype | Test',
          projectIdea: 'string',
          subject: 'string',
          notes: 'string'
        }
      }
    ]
  });
});

app.get('/llms.txt', (_req: Request, res: Response) => {
  res.type('text/plain').send(`# Edumind AI - LLM & AI Agent Access Manifest
Title: Edumind AI Student Companion
Description: Intelligent student companion chatbot designed for personalized tutoring, study plan generation, and ongoing academic support across all academic subjects.
Architecture: Java OOP Design Patterns (Strategy, Builder, Factory, Observer, Chain of Responsibility, Java Streams) and Stanford 5-Phase Design Thinking Cognitive Engine.

## Available API Endpoints:
- POST /api/chat: Real-time Socratic and first-principles streaming tutoring
- POST /api/generate-study-plan: 5-Phase milestone study roadmap generator
- POST /api/analyze-academic-problem: Analytical homework, derivation, and proof evaluation
- POST /api/generate-quiz: Adaptive diagnostic micro-quizzes
- POST /api/design-thinking-assist: Empathize -> Define -> Ideate -> Prototype -> Test facilitator
- GET /api/health: System operational health and model verification
- GET /api/ai-access: Full JSON schema discovery for autonomous agents
`);
});

// Initialize Gemini client strictly on server-side
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Models ordered by speed and quota resilience
// 'gemini-flash-lite-latest' delivers ultra-fast streaming in ~1 second with separate quota
const FAST_MODELS = ['gemini-flash-lite-latest', 'gemini-3.1-flash-lite'];
const DETAILED_MODELS = ['gemini-flash-lite-latest', 'gemini-3.1-flash-lite'];

// Resilient streaming runner that tries candidate models in order of speed
async function streamWithModelFallback(
  models: string[],
  contents: any,
  config: any,
  onChunk: (text: string) => void
): Promise<void> {
  let lastError: any = null;
  for (const model of models) {
    try {
      const responseStream = await ai.models.generateContentStream({
        model,
        contents,
        config,
      });

      let receivedAnyChunk = false;
      for await (const chunk of responseStream) {
        const text = chunk.text || chunk.candidates?.[0]?.content?.parts?.[0]?.text;
        if (text) {
          receivedAnyChunk = true;
          onChunk(text);
        }
      }
      if (receivedAnyChunk) {
        return; // Successfully streamed content
      }
    } catch (err: any) {
      console.warn(`Model ${model} streaming error:`, err?.message || err);
      lastError = err;
      // Continue to next model fallback
    }
  }
  throw lastError || new Error('All model attempts failed');
}

// Resilient JSON generator with fallback
async function generateJsonWithModelFallback(
  models: string[],
  contents: any,
  config: any
): Promise<string> {
  let lastError: any = null;
  for (const model of models) {
    try {
      const response = await ai.models.generateContent({
        model,
        contents,
        config,
      });
      if (response.text) {
        return response.text;
      }
    } catch (err: any) {
      console.warn(`Model ${model} JSON generation error:`, err?.message || err);
      lastError = err;
    }
  }
  throw lastError || new Error('All model attempts failed');
}

// System prompts representing Design Thinking + Multi-Subject Academic Pedagogical Strategies (Optimized for speed & direct clarity)
const SYSTEM_PROMPTS = {
  socratic: `You are Edumind AI, a high-speed, intelligent student companion and academic tutor for ALL academic subjects.
Focus on immediate speed, clarity, and direct value:
- Begin answering immediately in the first sentence without conversational preamble, filler, or greeting repeats.
- Use crisp, structured explanations with bold highlights and concise bullet points.
- Provide intuitive first-principles analogies and step-by-step reasoning.
- Keep responses focused and punchy (120-250 words unless the user explicitly asks for an exhaustive essay).
- Conclude with one focused follow-up check to test comprehension.`,

  deepExplanation: `You are Edumind AI in "Conceptual Deep-Dive" mode across all academic disciplines.
- Deliver direct, high-signal, first-principles academic breakdowns without delay.
- Begin immediately with the core governing law, mechanism, or definition.
- Show clean step-by-step derivations or analytical frameworks without redundant filler.
- Highlight key boundary conditions and common exam traps.`,

  designThinking: `You are Edumind AI in "Design Thinking Problem Solver" mode.
- Apply the 5-Phase framework (Empathize, Define, Ideate, Prototype, Test) in concise, structured sections.
- Deliver clear "How Might We" statements and actionable prototype steps immediately.`,

  examPrep: `You are Edumind AI in "Exam Prep & High-Yield Drill" mode for all academic subjects.
- Maximum speed and high-yield density: deliver direct formulas, key traps, and mnemonics immediately.
- Zero fluff: give the student the exact answer, step-by-step key, and trick answers to avoid.`
};

// 1. Universal Chat endpoint with streaming SSE
app.post('/api/chat', async (req: Request, res: Response) => {
  try {
    const { messages, mode = 'socratic', subject = 'General Academia', speedMode = 'fast', studentContext } = req.body;

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: 'Messages array is required' });
    }

    const basePrompt = SYSTEM_PROMPTS[mode as keyof typeof SYSTEM_PROMPTS] || SYSTEM_PROMPTS.socratic;
    const speedInstruction = speedMode === 'fast' 
      ? 'Speed Optimization: Provide high-speed token delivery. Be direct, crisp, and high-impact (under 200 words). Answer right from word one.'
      : 'Comprehensive Depth: Provide an in-depth pedagogical breakdown with step-by-step reasoning, formulas, and derivations.';

    const enrichedSystemInstruction = `${basePrompt}
Current Academic Focus: Subject = "${subject}".
${speedInstruction}
${studentContext ? `Learner Profile: ${studentContext}` : ''}`;

    // Keep conversation history lean (last 6 messages) to minimize processing latency
    const recentMessages = messages.slice(-6);

    // Convert messages to Gemini format
    const contents = recentMessages.map((m: { role: string; content: string }) => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }],
    }));

    // Setup Server-Sent Events headers with zero-buffering for instant streaming
    res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no');
    res.flushHeaders();

    const candidateModels = speedMode === 'fast' ? FAST_MODELS : DETAILED_MODELS;

    await streamWithModelFallback(
      candidateModels,
      contents,
      {
        systemInstruction: enrichedSystemInstruction,
        temperature: speedMode === 'fast' ? 0.4 : 0.7,
      },
      (text: string) => {
        res.write(`data: ${JSON.stringify({ text })}\n\n`);
        if (typeof (res as any).flush === 'function') {
          (res as any).flush();
        }
      }
    );

    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    res.end();
  } catch (error: any) {
    console.error('Chat error:', error);
    const friendlyError = error?.message?.includes('429') || error?.message?.includes('quota')
      ? 'The AI engine is temporarily experiencing high demand or rate limits. Please try again in a few moments.'
      : (error?.message || 'Failed to process chat message');

    if (!res.headersSent) {
      res.status(500).json({ error: friendlyError });
    } else {
      res.write(`data: ${JSON.stringify({ error: friendlyError })}\n\n`);
      res.end();
    }
  }
});

// 2. Study Plan Generator endpoint (Structured JSON output for ANY subject)
app.post('/api/generate-study-plan', async (req: Request, res: Response) => {
  try {
    const { subject, level, targetDays, dailyHours, goals } = req.body;

    const prompt = `Create a comprehensive, personalized study plan for a student.
Academic Subject/Course: ${subject || 'Mathematics & Science'}
Current Level: ${level || 'Intermediate'}
Target Timeline: ${targetDays || 14} days
Daily Available Study Time: ${dailyHours || 2} hours
Specific Goals/Exam: ${goals || 'Master key principles, score top percentile on midterm/final exam'}

Incorporate the 5-Phase Design Thinking learning milestones:
- Phase 1 (Empathize & Foundations): Diagnose knowledge gaps, build core intuition, physical analogies.
- Phase 2 (Define & Rigor): Formal models, definitions, key formulas/theorems, mechanism breakdown.
- Phase 3 (Ideate & Connections): Interdisciplinary synthesis, advanced problem sets, trap avoidance.
- Phase 4 (Prototype & Active Recall): Timed drills, formula fluency, mock question sets.
- Phase 5 (Test & Mastery): Diagnostic mock exam, reflection, confidence calibration.

Return valid structured JSON matching the requested schema.`;

    const jsonText = await generateJsonWithModelFallback(FAST_MODELS, prompt, {
      systemInstruction: 'You are an elite university curriculum architect using Design Thinking and pedagogical science across all academic disciplines.',
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          subject: { type: Type.STRING },
          overview: { type: Type.STRING },
          totalEstimatedHours: { type: Type.NUMBER },
          methodology: { type: Type.STRING },
          phases: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                phaseNumber: { type: Type.NUMBER },
                phaseName: { type: Type.STRING },
                focus: { type: Type.STRING },
                daysSpan: { type: Type.STRING },
                modules: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      day: { type: Type.NUMBER },
                      topic: { type: Type.STRING },
                      description: { type: Type.STRING },
                      estimatedMinutes: { type: Type.NUMBER },
                      learningObjectives: {
                        type: Type.ARRAY,
                        items: { type: Type.STRING },
                      },
                      practiceTask: { type: Type.STRING },
                      keyQuestions: {
                        type: Type.ARRAY,
                        items: { type: Type.STRING },
                      },
                    },
                    required: ['day', 'topic', 'description', 'estimatedMinutes', 'learningObjectives', 'practiceTask'],
                  },
                },
              },
              required: ['phaseNumber', 'phaseName', 'focus', 'daysSpan', 'modules'],
            },
          },
          tipsForSuccess: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
          },
        },
        required: ['title', 'subject', 'overview', 'totalEstimatedHours', 'phases', 'tipsForSuccess'],
      },
    });

    const parsedPlan = JSON.parse(jsonText || '{}');
    res.json(parsedPlan);
  } catch (error: any) {
    console.error('Study plan error:', error);
    res.status(500).json({ error: error?.message || 'Failed to generate study plan' });
  }
});

// 3. Academic Problem & Solution Analyzer endpoint (Any subject)
app.post('/api/analyze-academic-problem', async (req: Request, res: Response) => {
  try {
    const { problemText, studentWork, subject = 'General Academia' } = req.body;

    if (!problemText && !studentWork) {
      return res.status(400).json({ error: 'Problem statement or student work is required' });
    }

    const prompt = `Analyze this academic problem and/or student solution:
Subject: ${subject}
Problem Statement: ${problemText || 'General problem review'}
Student's Proposed Work or Solution:
${studentWork}

Provide structured feedback:
1. Conceptual accuracy & logical coherence
2. Step-by-step strengths
3. Key misconceptions or mathematical/logical errors found
4. Design Thinking recommendation: How to reframe the problem
5. Complete, elegant step-by-step solution model`;

    const jsonText = await generateJsonWithModelFallback(FAST_MODELS, prompt, {
      systemInstruction: 'You are an elite academic professor evaluating student problem-solving across STEM and humanities with constructive encouragement and rigorous precision.',
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          summary: { type: Type.STRING },
          status: { type: Type.STRING, description: 'mastered, needs_revision, or conceptual_gap' },
          comprehensionScore: { type: Type.NUMBER, description: 'Score out of 100 for conceptual understanding' },
          strengths: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
          },
          errorsAndMisconceptions: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
          },
          designThinkingInsight: { type: Type.STRING },
          stepByStepModelSolution: { type: Type.STRING },
          keyTakeaway: { type: Type.STRING },
        },
        required: ['summary', 'status', 'comprehensionScore', 'strengths', 'errorsAndMisconceptions', 'designThinkingInsight', 'stepByStepModelSolution', 'keyTakeaway'],
      },
    });

    const analysis = JSON.parse(jsonText || '{}');
    res.json(analysis);
  } catch (error: any) {
    console.error('Problem analysis error:', error);
    res.status(500).json({ error: error?.message || 'Failed to analyze academic problem' });
  }
});

// 4. Adaptive Practice Quiz Generator (Any subject)
app.post('/api/generate-quiz', async (req: Request, res: Response) => {
  try {
    const { topic, subject = 'General Academia', difficulty = 'medium', count = 3 } = req.body;

    const prompt = `Generate a high-quality practice quiz for a student.
Subject: ${subject}
Specific Topic: ${topic || 'Core Principles'}
Difficulty: ${difficulty}.
Number of questions: ${count}.
Include conceptual scenario questions, calculation/proof checks, and critical thinking questions.`;

    const jsonText = await generateJsonWithModelFallback(FAST_MODELS, prompt, {
      systemInstruction: 'You are an academic exam author specializing in rigorous higher education assessments.',
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          topic: { type: Type.STRING },
          subject: { type: Type.STRING },
          questions: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                questionText: { type: Type.STRING },
                snippetOrFormula: { type: Type.STRING },
                options: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                },
                correctIndex: { type: Type.NUMBER },
                explanation: { type: Type.STRING },
                conceptTag: { type: Type.STRING },
              },
              required: ['id', 'questionText', 'options', 'correctIndex', 'explanation', 'conceptTag'],
            },
          },
        },
        required: ['topic', 'subject', 'questions'],
      },
    });

    const quiz = JSON.parse(jsonText || '{}');
    res.json(quiz);
  } catch (error: any) {
    console.error('Quiz generator error:', error);
    res.status(500).json({ error: error?.message || 'Failed to generate quiz' });
  }
});

// 5. Design Thinking Academic Assistant endpoint (Any subject / topic)
app.post('/api/design-thinking-assist', async (req: Request, res: Response) => {
  try {
    const { phase, projectIdea, subject = 'General Academia', notes } = req.body;

    const prompt = `Guide a student on applying the Design Thinking phase to this academic problem/topic:
Subject: ${subject}
Target Phase: ${phase} (One of: Empathize, Define, Ideate, Prototype, Test)
Academic Topic / Problem: ${projectIdea || 'Understanding complex academic topic'}
Current Student Notes: ${notes || 'Initial problem breakdown'}

Provide structured actionable Design Thinking outputs:
- Phase Objectives
- Suggested "How Might We" statements
- Actionable Exercises (e.g. Concept mapping, alternative hypothesis testing, working draft)
- Probing questions to deepen academic reflection`;

    const jsonText = await generateJsonWithModelFallback(FAST_MODELS, prompt, {
      systemInstruction: 'You are a master Design Thinking facilitator from Stanford d.school guiding university students through complex problem decomposition.',
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          phase: { type: Type.STRING },
          objectives: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
          },
          hmwStatements: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
          },
          actionableArtifacts: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                instructions: { type: Type.STRING },
              },
              required: ['title', 'instructions'],
            },
          },
          reflectionPrompts: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
          },
        },
        required: ['phase', 'objectives', 'hmwStatements', 'actionableArtifacts', 'reflectionPrompts'],
      },
    });

    const dtResult = JSON.parse(jsonText || '{}');
    res.json(dtResult);
  } catch (error: any) {
    console.error('Design thinking assist error:', error);
    res.status(500).json({ error: error?.message || 'Failed to run design thinking assistance' });
  }
});

// Setup Vite middleware in dev or static serving in production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Edumind AI server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();

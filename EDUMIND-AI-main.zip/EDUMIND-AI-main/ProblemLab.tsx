import React, { useState, useEffect } from 'react';
import { 
  FlaskConical, 
  Sparkles, 
  CheckCircle2, 
  AlertTriangle, 
  BookOpen, 
  Copy, 
  Check, 
  MessageSquare,
  Lightbulb, 
  ArrowRight,
  GraduationCap,
  Terminal,
  Play,
  Loader2
} from 'lucide-react';
import { MULTI_SUBJECT_SAMPLES, SubjectProblemSample } from '../../architecture/academicCurriculum';
import { AcademicAnalysisResult, analyzeAcademicProblem } from '../../services/api';
import { AcademicSubject } from '../../types';
import { MathMarkdownRenderer } from '../Chat/MathMarkdownRenderer';
import { runPythonSandbox, PythonSandboxResult } from '../../utils/pythonVisualizer';

interface ProblemLabProps {
  activeSubject: AcademicSubject;
  onAskTutorAboutProblem: (problem: string) => void;
}

export const ProblemLab: React.FC<ProblemLabProps> = ({
  activeSubject,
  onAskTutorAboutProblem,
}) => {
  const initialSample = MULTI_SUBJECT_SAMPLES.find((s) => s.subject === activeSubject) || MULTI_SUBJECT_SAMPLES[0];
  const [selectedSample, setSelectedSample] = useState<SubjectProblemSample>(initialSample);
  const [problemInput, setProblemInput] = useState(initialSample.problemStatement);
  const [studentWorkInput, setStudentWorkInput] = useState(initialSample.stepByStepSolution);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<AcademicAnalysisResult | null>(null);
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'scratchpad' | 'pythonLab' | 'analysis' | 'designThinking'>('scratchpad');

  const getDefaultPythonForSubject = (subj: string) => {
    if (subj.includes('Physics')) {
      return `import numpy as np
import matplotlib.pyplot as plt

# Projectile & Kinematics Numerical Verification
v0, theta_deg, g = 25.0, 45.0, 9.81
theta = np.radians(theta_deg)
t_flight = 2 * v0 * np.sin(theta) / g
t = np.linspace(0, t_flight, 200)
x = v0 * np.cos(theta) * t
y = v0 * np.sin(theta) * t - 0.5 * g * t**2

print(f"Time of Flight: {t_flight:.2f} s | Max Range: {x[-1]:.2f} m | Max Height: {y.max():.2f} m")

plt.figure(figsize=(7, 3.6), facecolor="#090e1a")
ax = plt.gca()
ax.set_facecolor("#0f172a")
ax.plot(x, y, color="#38bdf8", linewidth=2.5, label="Trajectory y(x)")
ax.fill_between(x, y, 0, color="#38bdf8", alpha=0.12)
ax.set_title("Projectile Trajectory Simulation", color="#f8fafc", fontweight="bold")
ax.set_xlabel("Horizontal Distance x (m)", color="#cbd5e1")
ax.set_ylabel("Height y (m)", color="#cbd5e1")
ax.tick_params(colors="#94a3b8")
ax.grid(True, linestyle=":", color="#334155")
ax.legend(facecolor="#020617", labelcolor="#e2e8f0")`;
    }
    return `import numpy as np
import matplotlib.pyplot as plt

# Numerical Verification & Function Plotting in Python
x = np.linspace(-3, 5, 300)
f = x**3 - 6*x**2 + 9*x + 2
df = 3*x**2 - 12*x + 9

print("Local critical points where f'(x)=0:", np.roots([3, -12, 9]))
print(f"f(1) = {1 - 6 + 9 + 2}, f(3) = {27 - 54 + 27 + 2}")

plt.figure(figsize=(7, 3.6), facecolor="#090e1a")
ax = plt.gca()
ax.set_facecolor("#0f172a")
ax.plot(x, f, color="#38bdf8", linewidth=2.4, label="f(x) = x³ - 6x² + 9x + 2")
ax.plot(x, df, color="#f59e0b", linestyle="--", linewidth=1.8, label="f'(x) = 3x² - 12x + 9")
ax.axhline(0, color="#475569", linewidth=0.9)
ax.scatter([1, 3], [6, 2], color="#10b981", zorder=5, label="Extrema (x=1, x=3)")
ax.set_title("Function & Derivative Analysis", color="#f8fafc", fontweight="bold")
ax.tick_params(colors="#94a3b8")
ax.grid(True, linestyle=":", color="#334155")
ax.legend(facecolor="#020617", labelcolor="#e2e8f0")`;
  };

  const [pythonCode, setPythonCode] = useState<string>(() => getDefaultPythonForSubject(MULTI_SUBJECT_SAMPLES[0].subject));
  const [isRunningPython, setIsRunningPython] = useState(false);
  const [pythonOutput, setPythonOutput] = useState<PythonSandboxResult | null>(null);

  const handleRunPython = async () => {
    setIsRunningPython(true);
    try {
      const res = await runPythonSandbox(pythonCode);
      setPythonOutput(res);
    } catch (err: any) {
      setPythonOutput({
        stdout: '',
        stderr: err?.message || 'Python execution error',
        imageDataUrl: null,
        executionTimeMs: 0,
      });
    } finally {
      setIsRunningPython(false);
    }
  };

  const handleSelectSample = (sample: SubjectProblemSample) => {
    setSelectedSample(sample);
    setProblemInput(sample.problemStatement);
    setStudentWorkInput(sample.stepByStepSolution);
    setPythonCode(getDefaultPythonForSubject(sample.subject));
    setPythonOutput(null);
    setAnalysisResult(null);
    setActiveTab('scratchpad');
  };

  // Sync ProblemLab problem & Python script whenever the user switches subjects globally
  useEffect(() => {
    const matched = MULTI_SUBJECT_SAMPLES.find((s) => s.subject === activeSubject);
    if (matched) {
      handleSelectSample(matched);
    }
  }, [activeSubject]);

  const handleRunEvaluation = async () => {
    setIsAnalyzing(true);
    try {
      const result = await analyzeAcademicProblem({
        problemText: problemInput,
        studentWork: studentWorkInput,
        subject: selectedSample.subject,
      });
      setAnalysisResult(result);
      setActiveTab('analysis');
    } catch (err: any) {
      alert(`Error analyzing academic problem: ${err.message}`);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(`${problemInput}\n\nSolution / Derivation:\n${studentWorkInput}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="h-full flex flex-col bg-slate-950/60 overflow-hidden">
      {/* Top Bar */}
      <div className="p-4 border-b border-slate-800/80 bg-slate-900/60 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center">
            <FlaskConical className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              Multi-Subject Problem Lab & Solver
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/20">
                All Disciplines
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              Interactive problem decomposition, mathematical derivations, and Design Thinking solutions
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('designThinking')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors flex items-center gap-1.5 ${
              activeTab === 'designThinking'
                ? 'bg-emerald-600/20 border-emerald-500/40 text-emerald-300'
                : 'bg-slate-800/50 border-slate-700/60 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <Lightbulb className="w-3.5 h-3.5" />
            <span>Design Thinking Breakdown</span>
          </button>

          <button
            onClick={handleRunEvaluation}
            disabled={isAnalyzing}
            className="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-gradient-to-r from-amber-600 via-indigo-600 to-cyan-500 hover:from-amber-500 hover:to-cyan-400 text-white shadow-sm flex items-center gap-1.5 transition-all disabled:opacity-50"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{isAnalyzing ? 'Evaluating Derivation...' : 'AI Academic Evaluation'}</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Sample Navigator + Scratchpad Area */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        {/* Benchmark Problem Library Navigator */}
        <div className="w-full lg:w-80 border-r border-slate-800/80 bg-slate-900/30 overflow-y-auto p-3 space-y-2 shrink-0">
          <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider px-2 py-1 flex items-center justify-between">
            <span>Benchmark Problem Bank</span>
            <GraduationCap className="w-3.5 h-3.5 text-cyan-400" />
          </div>

          {MULTI_SUBJECT_SAMPLES.map((sample) => (
            <button
              key={sample.id}
              onClick={() => handleSelectSample(sample)}
              className={`w-full text-left p-3 rounded-xl border transition-all ${
                selectedSample.id === sample.id
                  ? 'bg-amber-500/10 border-amber-500/40 text-amber-200 shadow-sm'
                  : 'bg-slate-900/40 border-slate-800/60 text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
              }`}
            >
              <div className="flex items-center justify-between text-xs font-semibold mb-1">
                <span className="truncate">{sample.title}</span>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 font-normal">
                  {sample.subject.split(' ')[0]}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed font-normal">
                {sample.description}
              </p>
            </button>
          ))}

          {/* Quick Concept Tip */}
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 mt-4 text-[11px] text-slate-400">
            <span className="text-amber-400 font-semibold block mb-1">💡 Core Takeaway:</span>
            {selectedSample.keyTakeaway}
          </div>
        </div>

        {/* Scratchpad and Analysis View */}
        <div className="flex-1 flex flex-col overflow-hidden bg-slate-950">
          {/* Sub-tabs header */}
          <div className="px-4 py-2 border-b border-slate-800 flex items-center justify-between text-xs bg-slate-900/40">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveTab('scratchpad')}
                className={`px-3 py-1 rounded-md font-medium transition-colors ${
                  activeTab === 'scratchpad'
                    ? 'bg-slate-800 text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Problem Statement & Derivation Scratchpad
              </button>
              <button
                onClick={() => setActiveTab('pythonLab')}
                className={`px-3 py-1 rounded-md font-medium flex items-center gap-1.5 transition-colors ${
                  activeTab === 'pythonLab'
                    ? 'bg-emerald-600 text-white'
                    : 'text-emerald-400 hover:text-emerald-300'
                }`}
              >
                <Terminal className="w-3 h-3" />
                <span>Python Verifier & Plotter</span>
              </button>
              {analysisResult && (
                <button
                  onClick={() => setActiveTab('analysis')}
                  className={`px-3 py-1 rounded-md font-medium flex items-center gap-1.5 transition-colors ${
                    activeTab === 'analysis'
                      ? 'bg-indigo-600 text-white'
                      : 'text-indigo-400 hover:text-indigo-300'
                  }`}
                >
                  <Sparkles className="w-3 h-3" />
                  AI Evaluation ({analysisResult.comprehensionScore}/100)
                </button>
              )}
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleCopy}
                className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center gap-1 transition-colors"
              >
                {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>

              <button
                onClick={() => onAskTutorAboutProblem(`Explain how to solve this problem step-by-step: ${problemInput}`)}
                className="px-2.5 py-1 rounded bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 border border-indigo-500/30 text-xs flex items-center gap-1 transition-colors"
              >
                <MessageSquare className="w-3 h-3" />
                <span>Discuss with Tutor</span>
              </button>
            </div>
          </div>

          {activeTab === 'scratchpad' && (
            <div className="flex-1 grid grid-rows-2 lg:grid-rows-1 lg:grid-cols-2 overflow-hidden">
              {/* Problem Statement Input */}
              <div className="flex flex-col border-r border-slate-800/80 overflow-hidden">
                <div className="px-3 py-1.5 bg-slate-900/70 border-b border-slate-800 text-[11px] font-medium text-slate-400 flex items-center justify-between">
                  <span>Problem Statement / Prompt</span>
                  <span className="text-[10px] text-slate-500">{selectedSample.subject}</span>
                </div>
                <textarea
                  value={problemInput}
                  onChange={(e) => setProblemInput(e.target.value)}
                  placeholder="Paste or type any academic problem from Mathematics, Physics, Chemistry, Biology, Economics, History, Literature, etc..."
                  className="flex-1 w-full bg-slate-950 p-4 text-xs text-slate-200 leading-relaxed outline-none resize-none font-sans"
                />
              </div>

              {/* Student Proposed Work / Derivation */}
              <div className="flex flex-col bg-slate-950/95 overflow-hidden">
                <div className="px-3 py-1.5 bg-slate-900/70 border-b border-slate-800 text-[11px] font-medium text-slate-400 flex items-center justify-between">
                  <span>Step-by-Step Derivation / Solution Work</span>
                  <span className="text-[10px] text-slate-500">Editable Work</span>
                </div>
                <textarea
                  value={studentWorkInput}
                  onChange={(e) => setStudentWorkInput(e.target.value)}
                  placeholder="Type your derivation steps, calculations, essay thesis outline, or explanation here..."
                  className="flex-1 w-full bg-slate-950 p-4 font-mono text-xs text-emerald-300/90 leading-relaxed outline-none resize-none"
                />
              </div>
            </div>
          )}

          {activeTab === 'pythonLab' && (
            <div className="flex-1 grid grid-rows-2 lg:grid-rows-1 lg:grid-cols-2 overflow-hidden">
              <div className="flex flex-col border-r border-slate-800/80 overflow-hidden">
                <div className="px-3 py-2 bg-slate-900/70 border-b border-slate-800 flex items-center justify-between text-[11px]">
                  <span className="font-semibold text-emerald-300 flex items-center gap-1.5">
                    <Terminal className="w-3.5 h-3.5" />
                    Python 3 (NumPy + Matplotlib) Script
                  </span>
                  <button
                    onClick={handleRunPython}
                    disabled={isRunningPython}
                    className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center gap-1.5 disabled:opacity-50 transition-colors"
                  >
                    {isRunningPython ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        <span>Running...</span>
                      </>
                    ) : (
                      <>
                        <Play className="w-3 h-3 fill-white" />
                        <span>Run Python</span>
                      </>
                    )}
                  </button>
                </div>
                <textarea
                  value={pythonCode}
                  onChange={(e) => setPythonCode(e.target.value)}
                  spellCheck={false}
                  className="flex-1 w-full bg-slate-950 p-4 font-mono text-xs text-cyan-200 leading-relaxed outline-none resize-none"
                />
              </div>

              <div className="flex flex-col bg-slate-950 overflow-y-auto p-4 space-y-4">
                <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider flex items-center justify-between border-b border-slate-800 pb-2">
                  <span>Python Console & Matplotlib Output</span>
                  {pythonOutput && (
                    <span className="text-emerald-400 font-mono">{pythonOutput.executionTimeMs} ms</span>
                  )}
                </div>

                {!pythonOutput && !isRunningPython && (
                  <div className="text-xs text-slate-400 p-4 rounded-xl bg-slate-900/50 border border-slate-800">
                    Click <strong>Run Python</strong> to verify numerical answers and render Matplotlib plots right inside React.
                  </div>
                )}

                {pythonOutput?.stdout && (
                  <pre className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono text-emerald-300 whitespace-pre-wrap">
                    {pythonOutput.stdout}
                  </pre>
                )}

                {pythonOutput?.stderr && (
                  <pre className="p-3 rounded-xl bg-rose-950/40 border border-rose-500/40 text-xs font-mono text-rose-300 whitespace-pre-wrap">
                    {pythonOutput.stderr}
                  </pre>
                )}

                {pythonOutput?.imageDataUrl && (
                  <div className="rounded-xl overflow-hidden border border-slate-800 bg-[#090e1a] p-2">
                    <img
                      src={pythonOutput.imageDataUrl}
                      alt="Python Matplotlib Output"
                      className="w-full h-auto rounded-lg block"
                    />
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'analysis' && analysisResult && (
            <div className="flex-1 overflow-y-auto p-6 space-y-6 max-w-4xl mx-auto w-full">
              {/* Score card */}
              <div className="p-5 rounded-2xl bg-gradient-to-br from-indigo-950/50 to-slate-900 border border-indigo-500/30 flex items-center justify-between">
                <div>
                  <span className="text-xs font-semibold text-indigo-400 uppercase tracking-wider">
                    Academic Professor Evaluation
                  </span>
                  <h3 className="text-lg font-bold text-white mt-1">{analysisResult.summary}</h3>
                </div>
                <div className="text-right">
                  <div className="text-3xl font-extrabold text-transparent bg-gradient-to-r from-amber-400 via-indigo-300 to-cyan-300 bg-clip-text">
                    {analysisResult.comprehensionScore} / 100
                  </div>
                  <span className="text-xs text-slate-400">Comprehension Score</span>
                </div>
              </div>

              {/* Strengths & Misconceptions */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-slate-900/70 border border-slate-800">
                  <div className="flex items-center gap-2 font-semibold text-emerald-400 text-xs mb-3">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Conceptual Strengths</span>
                  </div>
                  <ul className="space-y-2 text-xs text-slate-300">
                    {analysisResult.strengths.map((str, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="text-emerald-400">•</span>
                        <span>{str}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="p-4 rounded-xl bg-slate-900/70 border border-slate-800">
                  <div className="flex items-center gap-2 font-semibold text-rose-400 text-xs mb-3">
                    <AlertTriangle className="w-4 h-4" />
                    <span>Errors & Common Misconceptions</span>
                  </div>
                  <ul className="space-y-2 text-xs text-slate-300">
                    {analysisResult.errorsAndMisconceptions.map((bug, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="text-rose-400">•</span>
                        <span>{bug}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Design Thinking Reframe Insight */}
              <div className="p-4 rounded-xl bg-slate-900/70 border border-emerald-500/30">
                <h4 className="text-xs font-semibold text-emerald-400 uppercase tracking-wide mb-2 flex items-center gap-1.5">
                  <Lightbulb className="w-4 h-4" /> Design Thinking Problem Reframing
                </h4>
                <p className="text-xs text-slate-200 leading-relaxed">
                  {analysisResult.designThinkingInsight}
                </p>
              </div>

              {/* Complete Step-by-Step Model Solution */}
              <div className="p-4 rounded-xl bg-slate-900/70 border border-slate-800">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-xs font-semibold text-indigo-300">Gold Standard Model Solution</h4>
                  <button
                    onClick={() => {
                      setStudentWorkInput(analysisResult.stepByStepModelSolution);
                      setActiveTab('scratchpad');
                    }}
                    className="text-xs text-indigo-400 hover:text-indigo-300 font-medium flex items-center gap-1"
                  >
                    <span>Load into Scratchpad</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
                <div className="p-3 bg-slate-950 rounded-lg text-xs leading-relaxed">
                  <MathMarkdownRenderer content={analysisResult.stepByStepModelSolution} msgId="model-sol" />
                </div>
              </div>
            </div>
          )}

          {activeTab === 'designThinking' && (
            <div className="flex-1 overflow-y-auto p-6 space-y-6 max-w-4xl mx-auto w-full text-slate-200">
              <div>
                <h3 className="text-lg font-bold text-white mb-1">
                  Design Thinking 5-Phase Solution Breakdown
                </h3>
                <p className="text-xs text-slate-400">
                  How human-centered innovation decomposes complex academic challenges in {selectedSample.subject}
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
                  <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider block mb-1">
                    1. EMPATHIZE
                  </span>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {selectedSample.designThinkingDecomposition.empathize}
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
                  <span className="text-[10px] font-bold text-cyan-400 uppercase tracking-wider block mb-1">
                    2. DEFINE
                  </span>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {selectedSample.designThinkingDecomposition.define}
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
                  <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider block mb-1">
                    3. IDEATE
                  </span>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {selectedSample.designThinkingDecomposition.ideate}
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
                  <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wider block mb-1">
                    4. PROTOTYPE
                  </span>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {selectedSample.designThinkingDecomposition.prototype}
                  </p>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-emerald-950/20 border border-emerald-500/20">
                <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider block mb-1">
                  5. TEST & VALIDATE
                </span>
                <p className="text-xs text-slate-200 leading-relaxed">
                  {selectedSample.designThinkingDecomposition.test}
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

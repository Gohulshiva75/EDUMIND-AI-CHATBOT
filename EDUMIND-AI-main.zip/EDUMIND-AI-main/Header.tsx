import React, { useState } from 'react';
import { 
  Sparkles, 
  Flame, 
  Clock, 
  Volume2, 
  VolumeX, 
  BookOpen, 
  Microscope, 
  Lightbulb, 
  Zap,
  Headphones,
  GraduationCap,
  Layers,
  Bot
} from 'lucide-react';
import { StudentProfile, TutorMode, AcademicSubject } from '../types';
import { soundscape } from '../utils/audio';

interface HeaderProps {
  studentProfile: StudentProfile;
  currentMode: TutorMode;
  onSelectMode: (mode: TutorMode) => void;
  onSelectSubject: (subject: AcademicSubject) => void;
  onOpenArchitectureModal: () => void;
  onOpenAiAccessModal: () => void;
}

const ACADEMIC_SUBJECTS: AcademicSubject[] = [
  'Mathematics',
  'Physics & Astronomy',
  'Chemistry & BioChem',
  'Biology & Medicine',
  'Computer Science & AI',
  'History & Social Studies',
  'Literature & Philosophy',
  'Economics & Business',
  'Engineering',
  'General Academia'
];

export const Header: React.FC<HeaderProps> = ({
  studentProfile,
  currentMode,
  onSelectMode,
  onSelectSubject,
  onOpenArchitectureModal,
  onOpenAiAccessModal,
}) => {
  const [ambientAudio, setAmbientAudio] = useState<'rain' | 'alpha' | 'library' | 'none'>('none');

  const toggleSound = (type: 'rain' | 'alpha' | 'library') => {
    if (ambientAudio === type) {
      soundscape.stopAmbient();
      setAmbientAudio('none');
    } else {
      soundscape.playAmbient(type);
      setAmbientAudio(type);
    }
  };

  return (
    <header className="h-16 border-b border-slate-800 bg-slate-900/90 backdrop-blur-md px-4 lg:px-6 flex items-center justify-between z-20 sticky top-0">
      {/* Brand & Companion Identity */}
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-cyan-400 flex items-center justify-center shadow-lg shadow-indigo-500/20 ring-1 ring-white/20">
          <Sparkles className="w-5 h-5 text-white animate-pulse" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <h1 className="font-bold text-lg tracking-tight bg-gradient-to-r from-white via-slate-100 to-indigo-200 bg-clip-text text-transparent">
              Edumind AI
            </h1>
            <span className="text-[10px] font-semibold uppercase tracking-wider px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              Universal Tutor
            </span>
          </div>
          <p className="text-xs text-slate-400 hidden sm:block">
            Intelligent Student Companion for All Academic Subjects
          </p>
        </div>
      </div>

      {/* Center: Subject Dropdown + Tutor Mode Selector */}
      <div className="hidden lg:flex items-center gap-2 bg-slate-950/70 p-1 rounded-xl border border-slate-800/80">
        {/* Subject Selector */}
        <div className="flex items-center gap-1 pl-2 pr-1 border-r border-slate-800 text-xs">
          <GraduationCap className="w-3.5 h-3.5 text-cyan-400" />
          <select
            value={studentProfile.activeSubject}
            onChange={(e) => onSelectSubject(e.target.value as AcademicSubject)}
            className="bg-transparent text-slate-200 font-semibold text-xs outline-none cursor-pointer py-1 pr-1"
          >
            {ACADEMIC_SUBJECTS.map((subj) => (
              <option key={subj} value={subj} className="bg-slate-900 text-slate-200">
                {subj}
              </option>
            ))}
          </select>
        </div>

        {/* Mode Buttons */}
        <div className="flex items-center gap-1">
          <button
            onClick={() => onSelectMode('socratic')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              currentMode === 'socratic'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
            title="Socratic guided questioning & analogies"
          >
            <BookOpen className="w-3.5 h-3.5" />
            Socratic Tutor
          </button>

          <button
            onClick={() => onSelectMode('deepExplanation')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              currentMode === 'deepExplanation'
                ? 'bg-cyan-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
            title="First-principles derivations & deep conceptual models"
          >
            <Microscope className="w-3.5 h-3.5" />
            Deep Concept
          </button>

          <button
            onClick={() => onSelectMode('designThinking')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              currentMode === 'designThinking'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
            title="5-Phase Problem Solving (Empathize, Define, Ideate, Prototype, Test)"
          >
            <Lightbulb className="w-3.5 h-3.5" />
            Design Thinking
          </button>

          <button
            onClick={() => onSelectMode('examPrep')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              currentMode === 'examPrep'
                ? 'bg-rose-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
            title="High-yield summaries, formula sheets & trap detection"
          >
            <Zap className="w-3.5 h-3.5" />
            Exam Drill
          </button>
        </div>
      </div>

      {/* Right Stats & Ambient Sound Quick Controls */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* AI Agent Access Button */}
        <button
          onClick={onOpenAiAccessModal}
          className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium bg-cyan-500/10 text-cyan-300 border border-cyan-500/20 hover:bg-cyan-500/20 transition-colors"
          title="Direct API access, cURL requests, and schema for external AI agents"
        >
          <Bot className="w-3.5 h-3.5" />
          <span>AI Access</span>
        </button>

        {/* Architecture Inspector Button */}
        <button
          onClick={onOpenArchitectureModal}
          className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 hover:bg-indigo-500/20 transition-colors"
          title="Inspect the Java OOP Patterns & Design Thinking engine powering this app"
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Architecture Engine</span>
        </button>

        {/* Soundscape Ambient Sound Picker */}
        <div className="relative group hidden sm:block">
          <button
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
              ambientAudio !== 'none'
                ? 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30'
                : 'bg-slate-800/50 text-slate-400 border-slate-700/50 hover:text-slate-200'
            }`}
          >
            <Headphones className="w-3.5 h-3.5" />
            <span>{ambientAudio === 'none' ? 'Focus Audio' : ambientAudio.toUpperCase()}</span>
          </button>
          
          <div className="absolute right-0 mt-1 w-44 bg-slate-900 border border-slate-700/80 rounded-xl shadow-xl p-1.5 hidden group-hover:block z-30">
            <div className="text-[10px] font-semibold uppercase px-2 py-1 text-slate-400">
              Study Soundscapes
            </div>
            <button
              onClick={() => toggleSound('rain')}
              className={`w-full text-left px-2 py-1.5 text-xs rounded-lg flex items-center justify-between ${
                ambientAudio === 'rain' ? 'bg-cyan-500/20 text-cyan-300' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <span>🌧️ Gentle Rain</span>
              {ambientAudio === 'rain' && <Volume2 className="w-3.5 h-3.5" />}
            </button>
            <button
              onClick={() => toggleSound('alpha')}
              className={`w-full text-left px-2 py-1.5 text-xs rounded-lg flex items-center justify-between ${
                ambientAudio === 'alpha' ? 'bg-cyan-500/20 text-cyan-300' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <span>🧠 Alpha Waves</span>
              {ambientAudio === 'alpha' && <Volume2 className="w-3.5 h-3.5" />}
            </button>
            <button
              onClick={() => toggleSound('library')}
              className={`w-full text-left px-2 py-1.5 text-xs rounded-lg flex items-center justify-between ${
                ambientAudio === 'library' ? 'bg-cyan-500/20 text-cyan-300' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <span>📚 Deep Library</span>
              {ambientAudio === 'library' && <Volume2 className="w-3.5 h-3.5" />}
            </button>
            {ambientAudio !== 'none' && (
              <button
                onClick={() => {
                  soundscape.stopAmbient();
                  setAmbientAudio('none');
                }}
                className="w-full text-left px-2 py-1.5 text-xs rounded-lg text-rose-400 hover:bg-slate-800 flex items-center gap-1.5 mt-1 border-t border-slate-800"
              >
                <VolumeX className="w-3 h-3" /> Stop Sound
              </button>
            )}
          </div>
        </div>

        {/* Streak counter */}
        <div 
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-orange-500/10 text-orange-400 border border-orange-500/20 text-xs font-semibold"
          title="Daily Study Streak"
        >
          <Flame className="w-4 h-4 fill-orange-500/30 text-orange-400 animate-bounce" />
          <span>{studentProfile.streakDays}d</span>
        </div>

        {/* Focus time */}
        <div 
          className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 text-xs font-semibold"
          title="Total Study Minutes Logged"
        >
          <Clock className="w-3.5 h-3.5 text-indigo-400" />
          <span>{studentProfile.totalStudyMinutes}m</span>
        </div>

        {/* Student Avatar */}
        <div className="flex items-center gap-2 pl-1 border-l border-slate-800">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 text-white flex items-center justify-center font-bold text-xs ring-2 ring-slate-800 shadow">
            {studentProfile.name.charAt(0)}
          </div>
        </div>
      </div>
    </header>
  );
};

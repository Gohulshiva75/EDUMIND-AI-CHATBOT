import React, { useState, useEffect } from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  Target, 
  Layers, 
  CheckCircle2, 
  AlertCircle,
  ArrowUpRight,
  Sparkles,
  Download,
  Code2,
  Loader2,
  RefreshCw
} from 'lucide-react';
import { TestAttemptResult, AcademicSubject } from '../../types';
import { renderPythonPerformanceChart, PythonChartOutput } from '../../utils/pythonVisualizer';

interface TestPerformanceGraphProps {
  currentResult: TestAttemptResult;
  history: TestAttemptResult[];
  activeSubject: AcademicSubject;
}

export const TestPerformanceGraph: React.FC<TestPerformanceGraphProps> = ({
  currentResult,
  history,
  activeSubject,
}) => {
  const [activeGraphTab, setActiveGraphTab] = useState<'python' | 'topics' | 'trend' | 'difficulty'>('python');
  const [hoveredPoint, setHoveredPoint] = useState<number | null>(null);

  // Filter history for current subject vs all
  const [historyScope, setHistoryScope] = useState<'subject' | 'all'>('subject');

  // Python Matplotlib rendering state
  const [pythonChart, setPythonChart] = useState<PythonChartOutput | null>(null);
  const [isPythonLoading, setIsPythonLoading] = useState(false);
  const [pythonError, setPythonError] = useState<string | null>(null);
  const [showPythonCode, setShowPythonCode] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);

  const relevantHistory = historyScope === 'subject'
    ? history.filter((h) => h.subject === activeSubject)
    : history;

  // Sort history chronologically
  const sortedHistory = [...relevantHistory].sort((a, b) => a.timestamp - b.timestamp);

  // Render Python Matplotlib chart when python tab is selected or data/scope changes
  const generatePythonPlot = async () => {
    setIsPythonLoading(true);
    setPythonError(null);
    try {
      const output = await renderPythonPerformanceChart(
        currentResult,
        history,
        activeSubject,
        historyScope
      );
      setPythonChart(output);
    } catch (err: any) {
      setPythonError(err?.message || 'Failed to execute Python Matplotlib runtime.');
    } finally {
      setIsPythonLoading(false);
    }
  };

  useEffect(() => {
    if (activeGraphTab === 'python') {
      generatePythonPlot();
    }
  }, [activeGraphTab, currentResult.id, history.length, activeSubject, historyScope]);

  const handleDownloadPng = () => {
    if (!pythonChart?.imageDataUrl) return;
    const link = document.createElement('a');
    link.href = pythonChart.imageDataUrl;
    link.download = `${currentResult.subject.toLowerCase().replace(/[^a-z0-9]+/g, '-')}-performance-matplotlib.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleCopyCode = async () => {
    if (!pythonChart?.pythonCode) return;
    try {
      await navigator.clipboard.writeText(pythonChart.pythonCode);
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2000);
    } catch {
      // ignore clipboard errors
    }
  };

  // Difficulty performance calculation
  const difficultyStats = React.useMemo(() => {
    const stats: Record<'Easy' | 'Medium' | 'Hard', { total: number; scored: number; count: number }> = {
      Easy: { total: 0, scored: 0, count: 0 },
      Medium: { total: 0, scored: 0, count: 0 },
      Hard: { total: 0, scored: 0, count: 0 },
    };

    currentResult.questions.forEach((q) => {
      const diff = q.difficulty || 'Medium';
      const isCorrect = currentResult.answers[q.id] === q.correctIndex;
      stats[diff].total += q.marks;
      stats[diff].count += 1;
      if (isCorrect) {
        stats[diff].scored += q.marks;
      }
    });

    return stats;
  }, [currentResult]);

  // Overall historical stats
  const avgScore = sortedHistory.length > 0
    ? Math.round(sortedHistory.reduce((sum, h) => sum + h.percentage, 0) / sortedHistory.length)
    : currentResult.percentage;

  const firstScore = sortedHistory.length > 1 ? sortedHistory[0].percentage : currentResult.percentage;
  const growth = currentResult.percentage - firstScore;

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-5">
      {/* Header and graph switcher */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 pb-4">
        <div>
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-cyan-400" />
            Performance Graphical Diagnostics & Analytics
            <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">
              Python Matplotlib + Interactive SVG
            </span>
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            In-browser Python (Matplotlib & NumPy) multi-panel plots alongside interactive topic & trend views
          </p>
        </div>

        {/* Tab pills */}
        <div className="flex flex-wrap items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
          <button
            onClick={() => setActiveGraphTab('python')}
            className={`px-3 py-1 rounded-lg font-medium transition-all flex items-center gap-1.5 ${
              activeGraphTab === 'python'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>Python Matplotlib</span>
          </button>
          <button
            onClick={() => setActiveGraphTab('topics')}
            className={`px-3 py-1 rounded-lg font-medium transition-all ${
              activeGraphTab === 'topics'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Topic Mastery
          </button>
          <button
            onClick={() => setActiveGraphTab('trend')}
            className={`px-3 py-1 rounded-lg font-medium transition-all ${
              activeGraphTab === 'trend'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Score Progression ({sortedHistory.length})
          </button>
          <button
            onClick={() => setActiveGraphTab('difficulty')}
            className={`px-3 py-1 rounded-lg font-medium transition-all ${
              activeGraphTab === 'difficulty'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Cognitive Depth
          </button>
        </div>
      </div>

      {/* 0. PYTHON MATPLOTLIB + NUMPY VISUALIZATION */}
      {activeGraphTab === 'python' && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-emerald-300 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                4-Panel Matplotlib & NumPy Analytics Figure
              </span>
              <div className="flex items-center bg-slate-950 rounded-lg p-0.5 border border-slate-800 text-[10px]">
                <button
                  onClick={() => setHistoryScope('subject')}
                  className={`px-2 py-0.5 rounded ${
                    historyScope === 'subject' ? 'bg-indigo-600 text-white font-semibold' : 'text-slate-400'
                  }`}
                >
                  This Subject ({activeSubject.split(' ')[0]})
                </button>
                <button
                  onClick={() => setHistoryScope('all')}
                  className={`px-2 py-0.5 rounded ${
                    historyScope === 'all' ? 'bg-indigo-600 text-white font-semibold' : 'text-slate-400'
                  }`}
                >
                  All Subjects
                </button>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {pythonChart && (
                <>
                  <button
                    onClick={() => setShowPythonCode((prev) => !prev)}
                    className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 flex items-center gap-1 text-[11px] font-medium transition-colors"
                  >
                    <Code2 className="w-3.5 h-3.5 text-cyan-400" />
                    <span>{showPythonCode ? 'Hide Python Code' : 'View Python Code'}</span>
                  </button>
                  <button
                    onClick={handleDownloadPng}
                    className="px-2.5 py-1 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 flex items-center gap-1 text-[11px] font-semibold transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download PNG</span>
                  </button>
                </>
              )}
              <button
                onClick={generatePythonPlot}
                disabled={isPythonLoading}
                className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 flex items-center gap-1 text-[11px] disabled:opacity-50 transition-colors"
                title="Re-run Python Matplotlib script"
              >
                <RefreshCw className={`w-3 h-3 ${isPythonLoading ? 'animate-spin' : ''}`} />
                <span>Re-plot</span>
              </button>
            </div>
          </div>

          {isPythonLoading && !pythonChart && (
            <div className="p-10 rounded-xl bg-slate-950/90 border border-slate-800 flex flex-col items-center justify-center text-center space-y-3">
              <Loader2 className="w-7 h-7 text-emerald-400 animate-spin" />
              <div className="space-y-1">
                <p className="text-xs font-semibold text-white">
                  Executing Python 3 + Matplotlib & NumPy in Browser...
                </p>
                <p className="text-[11px] text-slate-400">
                  First-time initialization downloads Matplotlib WebAssembly packages (~few seconds), then plots instantaneously.
                </p>
              </div>
              <button
                onClick={() => setActiveGraphTab('topics')}
                className="text-[11px] text-cyan-400 hover:text-cyan-300 underline"
              >
                Switch to instant interactive SVG charts while loading
              </button>
            </div>
          )}

          {pythonError && (
            <div className="p-4 rounded-xl bg-rose-950/30 border border-rose-500/40 text-xs text-rose-200 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold">Python Matplotlib visualization could not be rendered right now.</p>
                  <p className="text-rose-300/80 text-[11px] mt-0.5">{pythonError}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={generatePythonPlot}
                  className="px-3 py-1 rounded-lg bg-rose-600/30 hover:bg-rose-600/40 border border-rose-500/40 text-white font-medium"
                >
                  Retry Python Plot
                </button>
                <button
                  onClick={() => setActiveGraphTab('topics')}
                  className="px-3 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-medium"
                >
                  View Interactive SVG Charts
                </button>
              </div>
            </div>
          )}

          {pythonChart && (
            <div className="space-y-3">
              <div className="relative rounded-xl overflow-hidden border border-slate-800 bg-[#090e1a] p-2">
                {isPythonLoading && (
                  <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-[1px] flex items-center justify-center z-10">
                    <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-emerald-300">
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Updating Matplotlib figure...</span>
                    </div>
                  </div>
                )}
                <img
                  src={pythonChart.imageDataUrl}
                  alt={`Python Matplotlib performance chart for ${currentResult.subject}`}
                  className="w-full h-auto rounded-lg block"
                />
              </div>

              {showPythonCode && (
                <div className="rounded-xl bg-slate-950 border border-slate-800 overflow-hidden">
                  <div className="px-3 py-2 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between text-[11px]">
                    <span className="font-mono text-cyan-300 font-semibold">
                      matplotlib_performance_plot.py (Python 3 + Matplotlib + NumPy)
                    </span>
                    <button
                      onClick={handleCopyCode}
                      className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700"
                    >
                      {copiedCode ? 'Copied!' : 'Copy Python Code'}
                    </button>
                  </div>
                  <pre className="p-3 text-[11px] font-mono text-slate-300 overflow-x-auto max-h-72 leading-relaxed">
                    <code>{pythonChart.pythonCode}</code>
                  </pre>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* 1. TOPIC MASTERY BAR CHART */}
      {activeGraphTab === 'topics' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-semibold text-slate-300 flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-indigo-400" />
              Topic Competency Breakdown (% Marks Scored)
            </span>
            <div className="flex items-center gap-4 text-[11px]">
              <span className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 rounded-sm bg-emerald-500 inline-block" /> ≥80% Mastered
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 rounded-sm bg-amber-500 inline-block" /> 50-79% Review
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 rounded-sm bg-rose-500 inline-block" /> &lt;50% Gap
              </span>
            </div>
          </div>

          <div className="space-y-3.5 pt-1">
            {currentResult.topicBreakdown.map((t, idx) => {
              const isMastered = t.percentage >= 80;
              const isAverage = t.percentage >= 50 && t.percentage < 80;
              const barColor = isMastered
                ? 'from-emerald-500 to-teal-400'
                : isAverage
                ? 'from-amber-500 to-orange-400'
                : 'from-rose-500 to-red-400';

              const badgeColor = isMastered
                ? 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30'
                : isAverage
                ? 'text-amber-400 bg-amber-500/10 border-amber-500/30'
                : 'text-rose-400 bg-rose-500/10 border-rose-500/30';

              return (
                <div key={idx} className="space-y-1.5 group">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-medium text-slate-200 group-hover:text-white transition-colors flex items-center gap-1.5">
                      {isMastered ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      ) : (
                        <AlertCircle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                      )}
                      {t.topic}
                    </span>
                    <div className="flex items-center gap-2">
                      <span className="text-slate-400 font-mono text-[11px]">
                        {t.marksObtained}/{t.totalMarks} marks
                      </span>
                      <span className={`text-[11px] font-bold px-2 py-0.5 rounded border ${badgeColor} font-mono`}>
                        {t.percentage}%
                      </span>
                    </div>
                  </div>

                  {/* Horizontal Bar with 80% Benchmark Line */}
                  <div className="relative h-3 w-full bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                    {/* Benchmark mark at 80% */}
                    <div 
                      className="absolute top-0 bottom-0 w-0.5 bg-indigo-400/80 z-10" 
                      style={{ left: '80%' }}
                      title="Target Benchmark (80%)"
                    />
                    {/* Animated Fill Bar */}
                    <div
                      className={`h-full rounded-full bg-gradient-to-r ${barColor} transition-all duration-700 ease-out shadow-sm`}
                      style={{ width: `${Math.max(4, t.percentage)}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          <div className="pt-2 flex items-center justify-between text-[11px] text-slate-400 border-t border-slate-800/60">
            <span className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 inline-block" />
              Vertical line represents the 80% academic mastery benchmark threshold.
            </span>
            <span className="font-semibold text-slate-300">
              Exam Target: ≥60% to Pass
            </span>
          </div>
        </div>
      )}

      {/* 2. HISTORICAL PROGRESSION SVG LINE GRAPH */}
      {activeGraphTab === 'trend' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-slate-300 flex items-center gap-1.5">
                <TrendingUp className="w-3.5 h-3.5 text-cyan-400" />
                Score Progression Over Time
              </span>
              <div className="flex items-center bg-slate-950 rounded-lg p-0.5 border border-slate-800 text-[10px]">
                <button
                  onClick={() => setHistoryScope('subject')}
                  className={`px-2 py-0.5 rounded ${
                    historyScope === 'subject' ? 'bg-indigo-600 text-white font-semibold' : 'text-slate-400'
                  }`}
                >
                  This Subject ({activeSubject.split(' ')[0]})
                </button>
                <button
                  onClick={() => setHistoryScope('all')}
                  className={`px-2 py-0.5 rounded ${
                    historyScope === 'all' ? 'bg-indigo-600 text-white font-semibold' : 'text-slate-400'
                  }`}
                >
                  All Subjects
                </button>
              </div>
            </div>

            {/* Quick Metrics */}
            <div className="flex items-center gap-3 text-[11px]">
              <span className="text-slate-400">
                Avg: <strong className="text-white font-mono">{avgScore}%</strong>
              </span>
              {growth !== 0 && (
                <span className={`flex items-center font-bold font-mono ${growth >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  <ArrowUpRight className={`w-3 h-3 ${growth < 0 ? 'rotate-90' : ''}`} />
                  {growth > 0 ? `+${growth}%` : `${growth}%`} Growth
                </span>
              )}
            </div>
          </div>

          {/* SVG Line / Area Graph */}
          {sortedHistory.length > 0 ? (
            <div className="relative bg-slate-950/90 rounded-xl p-4 border border-slate-800/80">
              {/* SVG Canvas */}
              <div className="w-full h-48 relative">
                <svg className="w-full h-full overflow-visible" viewBox="0 0 500 150" preserveAspectRatio="none">
                  <defs>
                    <linearGradient id="areaGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.4" />
                      <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.0" />
                    </linearGradient>
                    <linearGradient id="strokeGradient" x1="0" y1="0" x2="1" y2="0">
                      <stop offset="0%" stopColor="#6366f1" />
                      <stop offset="50%" stopColor="#06b6d4" />
                      <stop offset="100%" stopColor="#10b981" />
                    </linearGradient>
                  </defs>

                  {/* Horizontal Guide Grid Lines (100%, 75%, 50%, 25%) */}
                  {[100, 75, 50, 25].map((level) => {
                    const y = 140 - (level / 100) * 125;
                    return (
                      <g key={level}>
                        <line
                          x1="0"
                          y1={y}
                          x2="500"
                          y2={y}
                          stroke="#334155"
                          strokeDasharray={level === 75 ? '3 3' : '1 4'}
                          strokeWidth="0.8"
                        />
                        <text
                          x="5"
                          y={y - 3}
                          fill={level === 75 ? '#818cf8' : '#64748b'}
                          fontSize="9"
                          fontFamily="monospace"
                        >
                          {level}% {level === 75 && '(Mastery Target)'}
                        </text>
                      </g>
                    );
                  })}

                  {/* Plot Points & Lines */}
                  {(() => {
                    // Compute coordinate points
                    const points = sortedHistory.map((h, i) => {
                      const count = sortedHistory.length;
                      const x = count === 1 ? 250 : 20 + (i / (count - 1)) * 460;
                      const y = 140 - (h.percentage / 100) * 125;
                      return { x, y, data: h };
                    });

                    // Build path data
                    const linePath = points.reduce((acc, pt, i) => {
                      return i === 0 ? `M ${pt.x} ${pt.y}` : `${acc} L ${pt.x} ${pt.y}`;
                    }, '');

                    const areaPath = points.length > 1
                      ? `${linePath} L ${points[points.length - 1].x} 140 L ${points[0].x} 140 Z`
                      : '';

                    return (
                      <>
                        {/* Shaded Area */}
                        {areaPath && (
                          <path d={areaPath} fill="url(#areaGradient)" />
                        )}

                        {/* Trend Stroke Line */}
                        {points.length > 1 && (
                          <path
                            d={linePath}
                            fill="none"
                            stroke="url(#strokeGradient)"
                            strokeWidth="3"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        )}

                        {/* Interactive Data Dots */}
                        {points.map((pt, i) => {
                          const isCurrent = pt.data.id === currentResult.id;
                          const isHovered = hoveredPoint === i;

                          return (
                            <g
                              key={i}
                              onMouseEnter={() => setHoveredPoint(i)}
                              onMouseLeave={() => setHoveredPoint(null)}
                              className="cursor-pointer"
                            >
                              <circle
                                cx={pt.x}
                                cy={pt.y}
                                r={isCurrent || isHovered ? 6 : 4}
                                fill={isCurrent ? '#f59e0b' : '#06b6d4'}
                                stroke="#0f172a"
                                strokeWidth="2"
                                className="transition-all"
                              />

                              {/* Persistent Score Label above point */}
                              <text
                                x={pt.x}
                                y={pt.y - 10}
                                textAnchor="middle"
                                fill={isCurrent ? '#fbbf24' : '#e2e8f0'}
                                fontSize="10"
                                fontWeight="bold"
                                fontFamily="monospace"
                              >
                                {pt.data.percentage}%
                              </text>
                            </g>
                          );
                        })}
                      </>
                    );
                  })()}
                </svg>
              </div>

              {/* Hover Tooltip Card */}
              {hoveredPoint !== null && sortedHistory[hoveredPoint] && (
                <div className="mt-3 p-2.5 rounded-lg bg-slate-900 border border-indigo-500/40 text-xs flex items-center justify-between">
                  <div>
                    <span className="font-semibold text-white">
                      {sortedHistory[hoveredPoint].testTitle}
                    </span>
                    <div className="text-[11px] text-slate-400">
                      {sortedHistory[hoveredPoint].subject} • {sortedHistory[hoveredPoint].date}
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-base font-extrabold text-cyan-300 font-mono">
                      {sortedHistory[hoveredPoint].percentage}%
                    </span>
                    <span className="block text-[10px] text-slate-400">
                      {sortedHistory[hoveredPoint].marksObtained}/{sortedHistory[hoveredPoint].totalMarks} Marks
                    </span>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="p-6 text-center text-xs text-slate-400 bg-slate-950 rounded-xl border border-slate-800">
              Complete more subject tests to view your multi-test performance curve and growth velocity!
            </div>
          )}

          <div className="flex items-center justify-between text-[11px] text-slate-400">
            <span>Points plotted across chronological test submissions.</span>
            <span className="text-amber-400 flex items-center gap-1 font-medium">
              <span className="w-2 h-2 rounded-full bg-amber-400 inline-block" /> Current Attempt Highlighted
            </span>
          </div>
        </div>
      )}

      {/* 3. COGNITIVE DEPTH / DIFFICULTY BREAKDOWN */}
      {activeGraphTab === 'difficulty' && (
        <div className="space-y-4">
          <div className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
            <Target className="w-3.5 h-3.5 text-rose-400" />
            Performance by Question Difficulty & Cognitive Bloom Level
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {(['Easy', 'Medium', 'Hard'] as const).map((diff) => {
              const stat = difficultyStats[diff];
              const pct = stat.total > 0 ? Math.round((stat.scored / stat.total) * 100) : 0;
              const color = diff === 'Easy'
                ? 'border-emerald-500/30 bg-emerald-500/5 text-emerald-400'
                : diff === 'Medium'
                ? 'border-amber-500/30 bg-amber-500/5 text-amber-400'
                : 'border-rose-500/30 bg-rose-500/5 text-rose-400';

              const barFill = diff === 'Easy'
                ? 'bg-emerald-500'
                : diff === 'Medium'
                ? 'bg-amber-500'
                : 'bg-rose-500';

              return (
                <div key={diff} className={`p-4 rounded-xl border ${color} space-y-2`}>
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-wider">{diff} Level</span>
                    <span className="text-[10px] text-slate-400 font-mono">{stat.count} questions</span>
                  </div>

                  <div className="text-2xl font-extrabold font-mono text-white">
                    {pct}%
                  </div>

                  <div className="text-xs text-slate-300 flex items-center justify-between font-mono text-[11px]">
                    <span>Score:</span>
                    <span>{stat.scored} / {stat.total} marks</span>
                  </div>

                  {/* Mini Progress Bar */}
                  <div className="h-2 w-full bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                    <div
                      className={`h-full rounded-full ${barFill} transition-all duration-500`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs text-slate-300 leading-relaxed flex items-start gap-2">
            <Sparkles className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
            <span>
              <strong>Pedagogical Insight:</strong> Success on Medium and Hard questions indicates deep analytical synthesis rather than simple rote memorization.
            </span>
          </div>
        </div>
      )}
    </div>
  );
};

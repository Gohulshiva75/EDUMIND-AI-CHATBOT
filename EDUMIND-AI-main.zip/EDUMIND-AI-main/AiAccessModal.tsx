import React, { useState } from 'react';
import { 
  X, 
  Bot, 
  Terminal, 
  Check, 
  Copy, 
  Play, 
  Sparkles, 
  Globe, 
  CheckCircle2, 
  Code2
} from 'lucide-react';

interface AiAccessModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AiAccessModal: React.FC<AiAccessModalProps> = ({ isOpen, onClose }) => {
  const [selectedEndpoint, setSelectedEndpoint] = useState<'chat' | 'studyPlan' | 'analyze' | 'quiz' | 'health'>('chat');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [testResult, setTestResult] = useState<string | null>(null);
  const [isTesting, setIsTesting] = useState(false);

  if (!isOpen) return null;

  const currentHost = typeof window !== 'undefined' ? window.location.origin : 'https://ais-dev-zqaeto52a6pbfqvm4nkgn6-110518554789.asia-southeast1.run.app';

  const copyCode = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const endpoints = {
    chat: {
      name: 'Universal Academic Tutor (Streaming SSE)',
      method: 'POST',
      path: '/api/chat',
      description: 'Streamed conversational tutor supporting any academic subject with Socratic or first-principles reasoning.',
      curl: `curl -N -X POST "${currentHost}/api/chat" \\
  -H "Content-Type: application/json" \\
  -d '{
    "messages": [{"role": "user", "content": "Explain the Second Law of Thermodynamics with an intuitive analogy"}],
    "mode": "socratic",
    "subject": "Physics & Astronomy"
  }'`,
      sampleBody: {
        messages: [{ role: 'user', content: 'Explain the Fundamental Theorem of Calculus with an everyday analogy' }],
        mode: 'socratic',
        subject: 'Mathematics'
      }
    },
    studyPlan: {
      name: '5-Phase Study Plan Generator (JSON)',
      method: 'POST',
      path: '/api/generate-study-plan',
      description: 'Generates structured milestone syllabus applying the Stanford 5-Phase Design Thinking framework.',
      curl: `curl -X POST "${currentHost}/api/generate-study-plan" \\
  -H "Content-Type: application/json" \\
  -d '{
    "subject": "Organic Chemistry",
    "level": "Intermediate",
    "targetDays": 14,
    "dailyHours": 2,
    "goals": "Master reaction mechanisms (SN1, SN2, E1, E2) for midterm exam"
  }'`,
      sampleBody: {
        subject: 'Quantum Mechanics',
        level: 'Intermediate',
        targetDays: 7,
        dailyHours: 2,
        goals: 'Master wavefunctions and Schrodinger equation'
      }
    },
    analyze: {
      name: 'Academic Problem & Derivation Evaluator',
      method: 'POST',
      path: '/api/analyze-academic-problem',
      description: 'Evaluates multi-step homework derivations, identifies subtle misconceptions, and provides gold-standard model solutions.',
      curl: `curl -X POST "${currentHost}/api/analyze-academic-problem" \\
  -H "Content-Type: application/json" \\
  -d '{
    "problemText": "Optimize the radius of a cylinder of volume 1000 cm3 to minimize surface area",
    "studentWork": "V = pi*r^2*h = 1000 => h = 1000/(pi*r^2). Area = 2*pi*r^2 + 2000/r. A prime = 4*pi*r - 2000/r^2 = 0 => r = (500/pi)^(1/3)",
    "subject": "Mathematics"
  }'`,
      sampleBody: {
        problemText: 'Explain the difference between SN1 and SN2 reactions',
        studentWork: 'SN1 is two steps with carbocation intermediate. SN2 is concerted one step with backside attack inversion.',
        subject: 'Chemistry & BioChem'
      }
    },
    quiz: {
      name: 'Adaptive Practice Quiz Generator',
      method: 'POST',
      path: '/api/generate-quiz',
      description: 'Author adaptive multiple-choice diagnostic questions with step-by-step explanations.',
      curl: `curl -X POST "${currentHost}/api/generate-quiz" \\
  -H "Content-Type: application/json" \\
  -d '{
    "topic": "Nash Equilibrium & Game Theory",
    "subject": "Economics & Business",
    "difficulty": "medium",
    "count": 3
  }'`,
      sampleBody: {
        topic: 'Cellular Respiration & Chemiosmosis',
        subject: 'Biology & Medicine',
        difficulty: 'medium',
        count: 2
      }
    },
    health: {
      name: 'Service Health & LLM Manifest',
      method: 'GET',
      path: '/api/health',
      description: 'Verifies server uptime, active model (gemini-flash-lite-latest), and AI agent discovery metadata.',
      curl: `curl -X GET "${currentHost}/api/health"`,
      sampleBody: null
    }
  };

  const handleTestEndpoint = async () => {
    setIsTesting(true);
    setTestResult('Connecting to endpoint...');
    try {
      const ep = endpoints[selectedEndpoint];
      if (ep.method === 'GET') {
        const res = await fetch(ep.path);
        const data = await res.json();
        setTestResult(JSON.stringify(data, null, 2));
      } else if (selectedEndpoint === 'chat') {
        // Test chat via POST
        const res = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(ep.sampleBody)
        });
        const reader = res.body?.getReader();
        const decoder = new TextDecoder();
        let chunks = '';
        if (reader) {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            chunks += decoder.decode(value);
            if (chunks.length > 500) break; // Sample first 500 chars
          }
        }
        setTestResult(`HTTP ${res.status} OK (SSE Stream Sample):\n\n${chunks.slice(0, 400)}...`);
      } else {
        const res = await fetch(ep.path, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(ep.sampleBody)
        });
        const data = await res.json();
        setTestResult(JSON.stringify(data, null, 2));
      }
    } catch (err: any) {
      setTestResult(`Error calling endpoint: ${err.message}`);
    } finally {
      setIsTesting(false);
    }
  };

  const currentConfig = endpoints[selectedEndpoint];

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700/80 rounded-3xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 bg-slate-950/70 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 via-indigo-600 to-purple-500 flex items-center justify-center text-white shadow-md">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                AI Agent & API Access Portal
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  Public REST & SSE Endpoints
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Programmatic AI access for external autonomous agents, LLMs, and client integrations
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Endpoint Selector Tabs */}
        <div className="px-6 py-2.5 bg-slate-950 border-b border-slate-800 flex items-center gap-2 text-xs overflow-x-auto no-scrollbar">
          {(Object.keys(endpoints) as (keyof typeof endpoints)[]).map((key) => {
            const ep = endpoints[key];
            const isActive = selectedEndpoint === key;
            return (
              <button
                key={key}
                onClick={() => {
                  setSelectedEndpoint(key);
                  setTestResult(null);
                }}
                className={`px-3 py-1.5 rounded-xl font-semibold flex items-center gap-1.5 shrink-0 transition-all ${
                  isActive
                    ? 'bg-cyan-600 text-white shadow'
                    : 'text-slate-400 hover:text-white hover:bg-slate-900'
                }`}
              >
                <span className="font-mono text-[10px] px-1 py-0.5 rounded bg-black/40">{ep.method}</span>
                <span>{key === 'chat' ? 'Chat Stream' : key === 'studyPlan' ? 'Study Plan' : key === 'analyze' ? 'Problem Evaluator' : key === 'quiz' ? 'Quiz Generator' : 'Health Check'}</span>
              </button>
            );
          })}
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5 text-xs text-slate-300">
          <div className="p-4 rounded-2xl bg-cyan-950/20 border border-cyan-500/20 flex flex-wrap items-center justify-between gap-2">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <span className="font-mono text-cyan-400">{currentConfig.method} {currentConfig.path}</span>
              </h3>
              <p className="text-xs text-slate-300 mt-0.5 leading-relaxed">
                {currentConfig.description}
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleTestEndpoint}
                disabled={isTesting}
                className="px-3.5 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-semibold flex items-center gap-1.5 transition-colors disabled:opacity-50"
              >
                <Play className="w-3.5 h-3.5 fill-white" />
                <span>{isTesting ? 'Running Request...' : 'Send Live Test Request'}</span>
              </button>
            </div>
          </div>

          {/* cURL Command Box */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-400 flex items-center gap-1.5">
                <Terminal className="w-4 h-4 text-amber-400" />
                Direct cURL Command for AI Agents:
              </span>
              <button
                onClick={() => copyCode(currentConfig.curl, 'curl')}
                className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center gap-1 transition-colors"
              >
                {copiedId === 'curl' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedId === 'curl' ? 'Copied' : 'Copy cURL'}</span>
              </button>
            </div>

            <pre className="p-4 bg-slate-950 rounded-xl font-mono text-[11px] text-emerald-300/90 leading-relaxed border border-slate-800 overflow-x-auto whitespace-pre-wrap">
              <code>{currentConfig.curl}</code>
            </pre>
          </div>

          {/* Live Test Response Output */}
          {testResult && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-indigo-300 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-cyan-400" />
                  Live Server Response:
                </span>
                <button
                  onClick={() => copyCode(testResult, 'response')}
                  className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] flex items-center gap-1"
                >
                  {copiedId === 'response' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedId === 'response' ? 'Copied' : 'Copy Response'}</span>
                </button>
              </div>

              <pre className="p-4 bg-slate-950 rounded-xl font-mono text-[11px] text-slate-200 leading-relaxed border border-indigo-500/30 overflow-x-auto max-h-56">
                <code>{testResult}</code>
              </pre>
            </div>
          )}

          {/* LLMs.txt & Web Discovery Info */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <span className="font-bold text-white text-xs flex items-center gap-1.5 text-indigo-400">
              <Globe className="w-4 h-4" /> AI Discovery & Agent Schema Files
            </span>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Autonomous agents can automatically fetch the machine-readable schema at:
            </p>
            <div className="flex flex-wrap gap-2 text-[11px]">
              <a
                href="/llms.txt"
                target="_blank"
                rel="noreferrer"
                className="px-3 py-1 rounded-lg bg-slate-900 border border-slate-700 text-cyan-300 hover:border-cyan-500 font-mono"
              >
                GET /llms.txt
              </a>
              <a
                href="/api/ai-access"
                target="_blank"
                rel="noreferrer"
                className="px-3 py-1 rounded-lg bg-slate-900 border border-slate-700 text-cyan-300 hover:border-cyan-500 font-mono"
              >
                GET /api/ai-access (JSON Schema)
              </a>
              <a
                href="/api/health"
                target="_blank"
                rel="noreferrer"
                className="px-3 py-1 rounded-lg bg-slate-900 border border-slate-700 text-cyan-300 hover:border-cyan-500 font-mono"
              >
                GET /api/health
              </a>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-semibold rounded-xl text-xs transition-colors"
          >
            Close Portal
          </button>
        </div>
      </div>
    </div>
  );
};

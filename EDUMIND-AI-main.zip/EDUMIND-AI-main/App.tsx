/**
 * Edumind AI - Universal Intelligent Student Companion & Academic Tutor
 * 
 * Features:
 * 1. Conversational AI Tutor for ALL subjects (Socratic, Deep Concept, Design Thinking, Exam Prep)
 * 2. Multi-Subject Problem Lab & Solver (Step-by-step derivations & AI evaluation)
 * 3. 5-Phase Design Thinking Problem Studio (Empathize, Define, Ideate, Prototype, Test)
 * 4. Adaptive Study Plan Generator & Milestones Tracker (Any subject)
 * 5. Active Recall Center (Multi-subject flashcards & adaptive quizzing)
 * 6. Deep Work Pomodoro Timer with Synthesizer Ambient Soundscapes
 * 7. Holistic Academic Mastery & Growth Analytics
 * 8. Under-The-Hood Architecture Engine Inspector (Java OOP Patterns & Design Thinking via Code)
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Sidebar, NavTab } from './components/Sidebar';
import { ChatInterface } from './components/Chat/ChatInterface';
import { ProblemLab } from './components/SubjectLab/ProblemLab';
import { DesignThinkingStudio } from './components/DesignThinking/DesignThinkingStudio';
import { StudyPlanView } from './components/StudyPlanner/StudyPlanView';
import { QuizAndFlashcards } from './components/Quiz/QuizAndFlashcards';
import { SubjectTestCenter } from './components/TestCenter/SubjectTestCenter';
import { PomodoroTimer } from './components/FocusTimer/PomodoroTimer';
import { StudentDashboard } from './components/Analytics/StudentDashboard';
import { ArchitectureModal } from './components/ArchitectureModal';
import { AiAccessModal } from './components/AiAccessModal';
import { StudentProfile, TutorMode, AcademicSubject } from './types';
import { bootPythonFrontendEngine } from './utils/pythonEngine';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('chat');
  const [currentMode, setCurrentMode] = useState<TutorMode>('socratic');
  const [isArchitectureModalOpen, setIsArchitectureModalOpen] = useState(false);
  const [isAiAccessModalOpen, setIsAiAccessModalOpen] = useState(false);

  // Boot the Python 3 frontend engine (/python/edumind_engine.py) alongside React
  useEffect(() => {
    bootPythonFrontendEngine().catch(() => {
      // Safe fallback handled seamlessly inside pythonEngine helpers
    });
  }, []);

  // Student profile state with multi-subject academic defaults
  const [studentProfile, setStudentProfile] = useState<StudentProfile>({
    name: 'Alex Rivera',
    major: 'Integrated Sciences & Interdisciplinary Studies',
    activeSubject: 'Mathematics',
    targetExamOrGoal: 'Master Calculus, Physics & Core Humanities with Top Honors',
    experienceLevel: 'Intermediate',
    preferredLearningStyle: 'Step-by-Step Problem Solving',
    streakDays: 6,
    totalStudyMinutes: 215,
    completedTasksCount: 18,
    masteryScores: {
      conceptualUnderstanding: 84,
      analyticalProblemSolving: 80,
      criticalThinking: 86,
      retentionAndRecall: 76,
      designThinkingMethod: 92,
      examReadiness: 79,
    },
  });

  // Update student profile
  const handleUpdateProfile = (updated: Partial<StudentProfile>) => {
    setStudentProfile((prev) => ({ ...prev, ...updated }));
  };

  // Switch active subject
  const handleSelectSubject = (subject: AcademicSubject) => {
    setStudentProfile((prev) => ({ ...prev, activeSubject: subject }));
  };

  // Switch to Chat with a pre-filled or initiated question
  const handleAskTutor = (query: string) => {
    setActiveTab('chat');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Application Header */}
      <Header
        studentProfile={studentProfile}
        currentMode={currentMode}
        onSelectMode={(mode) => setCurrentMode(mode)}
        onSelectSubject={handleSelectSubject}
        onOpenArchitectureModal={() => setIsArchitectureModalOpen(true)}
        onOpenAiAccessModal={() => setIsAiAccessModalOpen(true)}
      />

      {/* Main Workspace: Sidebar + Content Panel */}
      <div className="flex-1 flex overflow-hidden">
        {/* Navigation Sidebar */}
        <Sidebar 
          activeTab={activeTab} 
          onTabChange={(tab) => setActiveTab(tab)} 
          activeSubject={studentProfile.activeSubject}
        />

        {/* Dynamic Content Panel */}
        <main className="flex-1 flex flex-col overflow-hidden bg-slate-950 relative">
          {activeTab === 'chat' && (
            <ChatInterface
              studentProfile={studentProfile}
              currentMode={currentMode}
              onSelectMode={(mode) => setCurrentMode(mode)}
              onSelectSubject={handleSelectSubject}
              onOpenStudyPlanTab={() => setActiveTab('studyPlan')}
              onOpenProblemLab={() => setActiveTab('problemLab')}
            />
          )}

          {activeTab === 'testModule' && (
            <SubjectTestCenter
              studentProfile={studentProfile}
              onUpdateProfile={handleUpdateProfile}
              onSelectSubject={handleSelectSubject}
              onAskTutor={handleAskTutor}
            />
          )}

          {activeTab === 'problemLab' && (
            <ProblemLab
              activeSubject={studentProfile.activeSubject}
              onAskTutorAboutProblem={handleAskTutor}
            />
          )}

          {activeTab === 'designThinking' && (
            <DesignThinkingStudio initialSubject={studentProfile.activeSubject} />
          )}

          {activeTab === 'studyPlan' && (
            <StudyPlanView
              studentProfile={studentProfile}
              onUpdateProfile={handleUpdateProfile}
              onStartTopicInChat={(topic) => {
                setActiveTab('chat');
              }}
            />
          )}

          {activeTab === 'quiz' && (
            <QuizAndFlashcards
              studentProfile={studentProfile}
              onUpdateProfile={handleUpdateProfile}
              onAskTutor={handleAskTutor}
            />
          )}

          {activeTab === 'pomodoro' && (
            <PomodoroTimer
              studentProfile={studentProfile}
              onUpdateProfile={handleUpdateProfile}
            />
          )}

          {activeTab === 'analytics' && (
            <StudentDashboard
              studentProfile={studentProfile}
              onUpdateProfile={handleUpdateProfile}
              onNavigateToTab={(tab) => setActiveTab(tab)}
            />
          )}
        </main>
      </div>

      {/* Architecture Inspector Modal */}
      <ArchitectureModal
        isOpen={isArchitectureModalOpen}
        onClose={() => setIsArchitectureModalOpen(false)}
      />

      {/* AI Access & API Portal Modal */}
      <AiAccessModal
        isOpen={isAiAccessModalOpen}
        onClose={() => setIsAiAccessModalOpen(false)}
      />
    </div>
  );
}

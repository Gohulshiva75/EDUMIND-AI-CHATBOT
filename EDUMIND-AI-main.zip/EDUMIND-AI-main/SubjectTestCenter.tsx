import React, { useState, useEffect, useRef } from 'react';
import { 
  FileCheck, 
  Sparkles, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  ArrowRight, 
  RotateCcw, 
  BookOpen, 
  Flag, 
  ChevronRight, 
  ChevronLeft, 
  Award, 
  Layers, 
  TrendingUp, 
  HelpCircle, 
  GraduationCap, 
  Play, 
  Pause,
  History,
  Send,
  Zap,
  ListFilter
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { 
  AcademicSubject, 
  StudentProfile, 
  TestAttemptResult, 
  TopicPerformance 
} from '../../types';
import { 
  CURATED_SUBJECT_TESTS, 
  SubjectTest, 
  SubjectTestQuestion 
} from '../../architecture/subjectTestsData';
import { TestPerformanceGraph } from './TestPerformanceGraph';
import { MathMarkdownRenderer } from '../Chat/MathMarkdownRenderer';
import { generateQuiz } from '../../services/api';
import { getPyodideMatplotlib } from '../../utils/pythonVisualizer';
import { evaluateTestWithPython, calibrateMasteryWithPython } from '../../utils/pythonEngine';

interface SubjectTestCenterProps {
  studentProfile: StudentProfile;
  onUpdateProfile: (updated: Partial<StudentProfile>) => void;
  onSelectSubject: (subject: AcademicSubject) => void;
  onAskTutor: (query: string) => void;
}

const ALL_SUBJECTS: AcademicSubject[] = [
  'Mathematics',
  'Physics & Astronomy',
  'Chemistry & BioChem',
  'Biology & Medicine',
  'Computer Science & AI',
  'Economics & Business',
  'History & Social Studies',
  'Literature & Philosophy',
  'Engineering',
  'General Academia'
];

export const SubjectTestCenter: React.FC<SubjectTestCenterProps> = ({
  studentProfile,
  onUpdateProfile,
  onSelectSubject,
  onAskTutor,
}) => {
  const [selectedSubject, setSelectedSubject] = useState<AcademicSubject>(studentProfile.activeSubject);
  const [activeView, setActiveView] = useState<'overview' | 'taking' | 'result' | 'history'>('overview');

  // Active test state
  const [activeTest, setActiveTest] = useState<SubjectTest>(CURATED_SUBJECT_TESTS[selectedSubject]);
  const [currentQuestionIdx, setCurrentQuestionIdx] = useState(0);
  const [userAnswers, setUserAnswers] = useState<Record<string, number>>({});
  const [flaggedQuestions, setFlaggedQuestions] = useState<Record<string, boolean>>({});

  // Timer state
  const [secondsRemaining, setSecondsRemaining] = useState(activeTest.durationMinutes * 60);
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const timerRef = useRef<any>(null);

  // Result state
  const [latestResult, setLatestResult] = useState<TestAttemptResult | null>(null);
  const [isSubmitModalOpen, setIsSubmitModalOpen] = useState(false);

  // Local storage history
  const [testHistory, setTestHistory] = useState<TestAttemptResult[]>(() => {
    try {
      const saved = localStorage.getItem('edumind_test_history');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      // fallback
    }
    return studentProfile.testHistory || [];
  });

  // AI custom test modal state
  const [isAiModalOpen, setIsAiModalOpen] = useState(false);
  const [customTopic, setCustomTopic] = useState('');
  const [customDifficulty, setCustomDifficulty] = useState<'easy' | 'medium' | 'hard'>('medium');
  const [isGeneratingAiTest, setIsGeneratingAiTest] = useState(false);

  // Sync selectedSubject when global studentProfile.activeSubject changes from Header or Chat
  useEffect(() => {
    setSelectedSubject(studentProfile.activeSubject);
    if (activeView !== 'taking') {
      setActiveTest(CURATED_SUBJECT_TESTS[studentProfile.activeSubject]);
      setSecondsRemaining(CURATED_SUBJECT_TESTS[studentProfile.activeSubject].durationMinutes * 60);
      setActiveView('overview');
    }
  }, [studentProfile.activeSubject]);

  // Sync test when selectedSubject changes locally
  useEffect(() => {
    if (activeView === 'overview') {
      setActiveTest(CURATED_SUBJECT_TESTS[selectedSubject]);
      setSecondsRemaining(CURATED_SUBJECT_TESTS[selectedSubject].durationMinutes * 60);
    }
  }, [selectedSubject, activeView]);

  // Timer tick
  useEffect(() => {
    if (activeView === 'taking' && isTimerRunning) {
      timerRef.current = setInterval(() => {
        setSecondsRemaining((prev) => {
          if (prev <= 1) {
            clearInterval(timerRef.current);
            handleAutoSubmit();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [activeView, isTimerRunning]);

  // Start test
  const handleStartTest = (testToStart?: SubjectTest) => {
    const test = testToStart || activeTest;
    setActiveTest(test);
    setUserAnswers({});
    setFlaggedQuestions({});
    setCurrentQuestionIdx(0);
    setSecondsRemaining(test.durationMinutes * 60);
    setIsTimerRunning(true);
    setActiveView('taking');

    // Warm up in-browser Python (Pyodide + Matplotlib/NumPy) in background while student takes exam
    getPyodideMatplotlib().catch(() => {
      // Errors will be surfaced gracefully if/when Python chart tab is rendered
    });
  };

  // Toggle answer
  const handleSelectOption = (questionId: string, optionIdx: number) => {
    setUserAnswers((prev) => ({
      ...prev,
      [questionId]: optionIdx,
    }));
  };

  // Toggle flag
  const handleToggleFlag = (questionId: string) => {
    setFlaggedQuestions((prev) => ({
      ...prev,
      [questionId]: !prev[questionId],
    }));
  };

  // Calculate marks and generate result
  const evaluateTest = (): TestAttemptResult => {
    let marksObtained = 0;
    let correctCount = 0;
    const totalMarks = activeTest.totalMarks;

    // Track topic breakdown
    const topicMap: Record<string, { total: number; scored: number }> = {};

    activeTest.questions.forEach((q) => {
      const topic = q.conceptTag;
      if (!topicMap[topic]) {
        topicMap[topic] = { total: 0, scored: 0 };
      }
      topicMap[topic].total += q.marks;

      const studentAns = userAnswers[q.id];
      if (studentAns === q.correctIndex) {
        marksObtained += q.marks;
        correctCount += 1;
        topicMap[topic].scored += q.marks;
      }
    });

    const percentage = Math.round((marksObtained / totalMarks) * 100);
    const accuracy = Math.round((correctCount / activeTest.questions.length) * 100);
    const isPassed = marksObtained >= activeTest.passingMarks;

    // Grade assignment
    let grade = 'C';
    if (percentage >= 90) grade = 'A+ (Mastery)';
    else if (percentage >= 80) grade = 'A (Distinction)';
    else if (percentage >= 70) grade = 'B (Proficient)';
    else if (percentage >= 60) grade = 'C (Satisfactory)';
    else grade = 'Needs Revision';

    // Topic breakdown array
    const topicBreakdown: TopicPerformance[] = Object.keys(topicMap).map((topic) => {
      const { total, scored } = topicMap[topic];
      return {
        topic,
        marksObtained: scored,
        totalMarks: total,
        percentage: total > 0 ? Math.round((scored / total) * 100) : 0,
      };
    });

    // Strengths & Weaknesses
    const strengths = topicBreakdown
      .filter((t) => t.percentage >= 80)
      .map((t) => `${t.topic} (${t.percentage}% marks scored)`);

    const weaknesses = topicBreakdown
      .filter((t) => t.percentage < 80)
      .map((t) => `${t.topic} (Scored ${t.marksObtained}/${t.totalMarks} marks)`);

    const timeSpentSeconds = (activeTest.durationMinutes * 60) - secondsRemaining;

    const result: TestAttemptResult = {
      id: `attempt-${Date.now()}`,
      testId: activeTest.id,
      testTitle: activeTest.title,
      subject: activeTest.subject,
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      timestamp: Date.now(),
      timeSpentSeconds,
      marksObtained,
      totalMarks,
      percentage,
      grade,
      isPassed,
      accuracy,
      answers: userAnswers,
      topicBreakdown,
      strengths: strengths.length > 0 ? strengths : ['Foundation concepts reviewed'],
      weaknesses: weaknesses.length > 0 ? weaknesses : ['None! Perfect performance across all tested topics.'],
      questions: activeTest.questions,
    };

    return result;
  };

  const handleConfirmSubmit = async () => {
    setIsSubmitModalOpen(false);
    setIsTimerRunning(false);

    const timeSpentSeconds = Math.max(0, (activeTest.durationMinutes * 60) - secondsRemaining);
    const result = await evaluateTestWithPython(activeTest, userAnswers, timeSpentSeconds);
    setLatestResult(result);

    // Update history
    const updatedHistory = [result, ...testHistory];
    setTestHistory(updatedHistory);
    try {
      localStorage.setItem('edumind_test_history', JSON.stringify(updatedHistory));
    } catch (e) {
      // ignore
    }

    // Update student profile mastery via Python calibration engine
    const newMastery = await calibrateMasteryWithPython(
      studentProfile.masteryScores,
      'TEST_COMPLETED',
      result.percentage
    );
    onUpdateProfile({
      completedTasksCount: (studentProfile.completedTasksCount || 0) + 1,
      masteryScores: newMastery,
      testHistory: updatedHistory,
    });

    if (result.isPassed) {
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 },
      });
    }

    setActiveView('result');
  };

  const handleAutoSubmit = () => {
    setIsTimerRunning(false);
    handleConfirmSubmit();
  };

  // Generate Custom AI Test for any subject topic
  const handleGenerateAiTest = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsGeneratingAiTest(true);
    try {
      const generated = await generateQuiz(
        customTopic,
        selectedSubject,
        customDifficulty,
        5
      );

      if (generated && generated.questions && generated.questions.length > 0) {
        const customTest: SubjectTest = {
          id: `ai-test-${Date.now()}`,
          title: `${selectedSubject}: ${generated.topic || customTopic} AI Diagnostic Test`,
          subject: selectedSubject,
          durationMinutes: 15,
          totalMarks: generated.questions.length * 6,
          passingMarks: Math.round(generated.questions.length * 6 * 0.6),
          description: `Custom AI-synthesized examination on "${customTopic}" targeting ${customDifficulty} mastery.`,
          instructions: [
            'Each question carries 6 marks.',
            'Read each mathematical derivation or scenario carefully before selecting.'
          ],
          questions: generated.questions.map((q, idx) => ({
            id: q.id || `q-ai-${idx}`,
            questionText: q.questionText,
            snippetOrFormula: q.snippetOrFormula,
            options: q.options,
            correctIndex: q.correctIndex,
            explanation: q.explanation,
            conceptTag: q.conceptTag || customTopic,
            marks: 6,
            difficulty: customDifficulty === 'easy' ? 'Easy' : customDifficulty === 'medium' ? 'Medium' : 'Hard',
          })),
        };

        setIsAiModalOpen(false);
        setCustomTopic('');
        handleStartTest(customTest);
      }
    } catch (err: any) {
      alert(`Could not generate custom test: ${err.message}`);
    } finally {
      setIsGeneratingAiTest(false);
    }
  };

  // Format seconds to mm:ss
  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const answeredCount = Object.keys(userAnswers).length;
  const totalQuestions = activeTest.questions.length;
  const currentQuestion = activeTest.questions[currentQuestionIdx];

  return (
    <div className="h-full flex flex-col bg-slate-950/60 overflow-hidden relative">
      {/* Top Banner */}
      <div className="p-4 border-b border-slate-800/80 bg-slate-900/60 flex flex-wrap items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30 flex items-center justify-center">
            <FileCheck className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              Subject Examination & Diagnostic Test Center
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-purple-500/15 text-purple-300 border border-purple-500/30">
                Marks & Graphical Analytics
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              Rigorous timed assessments, automated mark analysis, and mastery progression plotting
            </p>
          </div>
        </div>

        {/* View Switchers */}
        <div className="flex items-center gap-2">
          {activeView !== 'taking' && (
            <>
              <button
                onClick={() => setActiveView('overview')}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                  activeView === 'overview'
                    ? 'bg-indigo-600 text-white font-semibold shadow-sm'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                }`}
              >
                Subject Tests
              </button>
              <button
                onClick={() => setActiveView('history')}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors ${
                  activeView === 'history'
                    ? 'bg-indigo-600 text-white font-semibold shadow-sm'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                }`}
              >
                <History className="w-3.5 h-3.5" />
                History ({testHistory.length})
              </button>
              <button
                onClick={() => setIsAiModalOpen(true)}
                className="px-3 py-1.5 rounded-lg text-xs font-medium bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-sm flex items-center gap-1.5 transition-all"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                <span>AI Custom Test</span>
              </button>
            </>
          )}

          {activeView === 'taking' && (
            <div className="flex items-center gap-3">
              {/* Timer Badge */}
              <div
                className={`flex items-center gap-1.5 px-3 py-1 rounded-xl font-mono text-xs font-bold border transition-colors ${
                  secondsRemaining < 120
                    ? 'bg-rose-500/20 text-rose-300 border-rose-500/40 animate-pulse'
                    : 'bg-slate-900 text-amber-300 border-amber-500/30'
                }`}
              >
                <Clock className="w-3.5 h-3.5 text-amber-400" />
                <span>{formatTime(secondsRemaining)}</span>
              </div>

              <button
                onClick={() => setIsSubmitModalOpen(true)}
                className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-md flex items-center gap-1.5 transition-all"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Submit Test</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Main Container View Router */}
      <div className="flex-1 overflow-y-auto">
        {/* VIEW 1: SUBJECT TEST OVERVIEW & SELECTION */}
        {activeView === 'overview' && (
          <div className="p-5 lg:p-7 max-w-6xl mx-auto space-y-6">
            {/* Subject Selector Chips */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                  <GraduationCap className="w-4 h-4 text-cyan-400" />
                  Select Academic Subject for Examination:
                </span>
                <span className="text-xs text-slate-400">
                  Currently Viewing: <strong className="text-cyan-300">{selectedSubject}</strong>
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2">
                {ALL_SUBJECTS.map((subj) => {
                  const isSelected = selectedSubject === subj;
                  return (
                    <button
                      key={subj}
                      onClick={() => {
                        setSelectedSubject(subj);
                        onSelectSubject(subj);
                      }}
                      className={`p-2.5 rounded-xl text-left border text-xs font-medium transition-all ${
                        isSelected
                          ? 'bg-indigo-600/20 border-indigo-500 text-white shadow-md shadow-indigo-600/20 ring-1 ring-indigo-500/50'
                          : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:bg-slate-800/80 hover:text-slate-200'
                      }`}
                    >
                      <span className="block truncate">{subj}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Test Preview Card for Selected Subject */}
            <div className="bg-gradient-to-br from-slate-900 via-slate-900/90 to-indigo-950/40 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-5">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div className="space-y-1.5 max-w-2xl">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                      Standard Diagnostic Exam
                    </span>
                    <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                      {activeTest.subject}
                    </span>
                  </div>
                  <h3 className="text-xl font-extrabold text-white">
                    {activeTest.title}
                  </h3>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {activeTest.description}
                  </p>
                </div>

                {/* Key Metrics */}
                <div className="flex items-center gap-3 bg-slate-950/80 p-3 rounded-xl border border-slate-800 shrink-0">
                  <div className="text-center px-2">
                    <span className="block text-lg font-bold text-white font-mono">{activeTest.questions.length}</span>
                    <span className="text-[10px] text-slate-400 uppercase">Questions</span>
                  </div>
                  <div className="w-px h-8 bg-slate-800" />
                  <div className="text-center px-2">
                    <span className="block text-lg font-bold text-amber-300 font-mono">{activeTest.durationMinutes}m</span>
                    <span className="text-[10px] text-slate-400 uppercase">Duration</span>
                  </div>
                  <div className="w-px h-8 bg-slate-800" />
                  <div className="text-center px-2">
                    <span className="block text-lg font-bold text-emerald-400 font-mono">{activeTest.totalMarks}</span>
                    <span className="text-[10px] text-slate-400 uppercase">Total Marks</span>
                  </div>
                </div>
              </div>

              {/* Instructions */}
              <div className="p-4 bg-slate-950/60 rounded-xl border border-slate-800/80 space-y-2">
                <span className="text-xs font-bold text-slate-300 uppercase tracking-wide flex items-center gap-1.5">
                  <BookOpen className="w-3.5 h-3.5 text-indigo-400" /> Exam Rules & Marking Scheme:
                </span>
                <ul className="space-y-1.5 text-xs text-slate-400">
                  {activeTest.instructions.map((inst, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="text-indigo-400">•</span>
                      <span>{inst}</span>
                    </li>
                  ))}
                  <li className="flex items-start gap-2 text-emerald-400">
                    <span>•</span>
                    <span>Passing threshold: <strong>{activeTest.passingMarks} / {activeTest.totalMarks} Marks (60%)</strong>. Full step-by-step model solutions and plotted graphs generated upon submission.</span>
                  </li>
                </ul>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  onClick={() => handleStartTest()}
                  className="px-6 py-3 rounded-xl bg-gradient-to-r from-indigo-600 via-indigo-500 to-cyan-500 hover:from-indigo-500 hover:to-cyan-400 text-white font-bold text-sm shadow-lg shadow-indigo-600/30 flex items-center gap-2 transition-all"
                >
                  <Play className="w-4 h-4 fill-white" />
                  <span>Begin {selectedSubject} Test</span>
                </button>

                <button
                  onClick={() => setIsAiModalOpen(true)}
                  className="px-4 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs border border-slate-700/60 flex items-center gap-2 transition-colors"
                >
                  <Sparkles className="w-4 h-4 text-purple-400" />
                  <span>Generate Custom AI Test on Any Chapter</span>
                </button>
              </div>
            </div>

            {/* Past Test History Summary if exists */}
            {testHistory.length > 0 && (
              <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                    <TrendingUp className="w-3.5 h-3.5 text-cyan-400" />
                    Recent Subject Test Attempts ({testHistory.length})
                  </h4>
                  <button
                    onClick={() => setActiveView('history')}
                    className="text-xs text-indigo-400 hover:text-indigo-300 font-medium flex items-center gap-1"
                  >
                    <span>View Full Historical Reports</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {testHistory.slice(0, 3).map((item, idx) => (
                    <div
                      key={idx}
                      onClick={() => {
                        setLatestResult(item);
                        setActiveView('result');
                      }}
                      className="p-3 bg-slate-950 rounded-xl border border-slate-800/80 hover:border-indigo-500/50 cursor-pointer transition-all space-y-1.5"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-semibold text-cyan-300">{item.subject}</span>
                        <span className="text-[10px] text-slate-400">{item.date}</span>
                      </div>
                      <div className="text-xs font-bold text-white truncate">{item.testTitle}</div>
                      <div className="flex items-center justify-between text-xs pt-1">
                        <span className="font-mono text-slate-300">
                          {item.marksObtained}/{item.totalMarks} Marks
                        </span>
                        <span className={`font-bold font-mono px-2 py-0.5 rounded text-[10px] ${
                          item.percentage >= 80 ? 'text-emerald-400 bg-emerald-500/10' : 'text-amber-400 bg-amber-500/10'
                        }`}>
                          {item.percentage}% ({item.grade.split(' ')[0]})
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* VIEW 2: TEST TAKING INTERFACE */}
        {activeView === 'taking' && (
          <div className="p-4 lg:p-6 max-w-5xl mx-auto space-y-6">
            {/* Question Progress and Jump Bar */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 shadow-md space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-300">
                  Question {currentQuestionIdx + 1} of {totalQuestions}
                </span>
                <span className="text-slate-400">
                  Answered: <strong className="text-emerald-400 font-mono">{answeredCount}</strong> / {totalQuestions}
                </span>
              </div>

              {/* Visual Question Navigator Buttons */}
              <div className="flex flex-wrap items-center gap-2">
                {activeTest.questions.map((q, idx) => {
                  const isCurrent = currentQuestionIdx === idx;
                  const isAnswered = userAnswers[q.id] !== undefined;
                  const isFlagged = flaggedQuestions[q.id];

                  let btnStyle = 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white';
                  if (isCurrent) {
                    btnStyle = 'bg-indigo-600 text-white border-indigo-400 ring-2 ring-indigo-500/40 font-bold';
                  } else if (isFlagged) {
                    btnStyle = 'bg-amber-500/20 text-amber-300 border-amber-500/50 font-bold';
                  } else if (isAnswered) {
                    btnStyle = 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 font-medium';
                  }

                  return (
                    <button
                      key={q.id}
                      onClick={() => setCurrentQuestionIdx(idx)}
                      className={`w-9 h-9 rounded-xl border text-xs flex items-center justify-center transition-all ${btnStyle}`}
                      title={`Question ${idx + 1}: ${isAnswered ? 'Answered' : 'Unanswered'}${isFlagged ? ' (Flagged)' : ''}`}
                    >
                      {idx + 1}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Current Question Card */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-5">
              {/* Question Header */}
              <div className="flex items-center justify-between pb-3 border-b border-slate-800 text-xs">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-indigo-400 uppercase tracking-wider text-[11px]">
                    Q{currentQuestionIdx + 1}
                  </span>
                  <span className="px-2 py-0.5 rounded bg-slate-800 text-cyan-300 font-mono text-[11px]">
                    {currentQuestion.conceptTag}
                  </span>
                  <span className="px-2 py-0.5 rounded bg-slate-800 text-amber-300 font-mono text-[11px]">
                    {currentQuestion.marks} Marks
                  </span>
                  <span className="px-2 py-0.5 rounded bg-slate-800 text-purple-300 font-mono text-[11px]">
                    {currentQuestion.difficulty}
                  </span>
                </div>

                <button
                  onClick={() => handleToggleFlag(currentQuestion.id)}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs transition-colors ${
                    flaggedQuestions[currentQuestion.id]
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                  }`}
                >
                  <Flag className="w-3.5 h-3.5" />
                  <span>{flaggedQuestions[currentQuestion.id] ? 'Flagged' : 'Flag for Review'}</span>
                </button>
              </div>

              {/* Question Text with KaTeX Rendering */}
              <div className="text-sm font-medium text-white leading-relaxed">
                <MathMarkdownRenderer content={currentQuestion.questionText} msgId={`q-text-${currentQuestion.id}`} />
              </div>

              {/* Formula or Code Snippet if present */}
              {currentQuestion.snippetOrFormula && (
                <div className="p-3 bg-slate-950 rounded-xl border border-indigo-500/20 text-xs text-cyan-200 font-mono overflow-x-auto">
                  <MathMarkdownRenderer content={currentQuestion.snippetOrFormula} msgId={`q-snip-${currentQuestion.id}`} />
                </div>
              )}

              {/* Multiple Choice Options */}
              <div className="space-y-2.5 pt-2">
                {currentQuestion.options.map((opt, optIdx) => {
                  const isSelected = userAnswers[currentQuestion.id] === optIdx;

                  return (
                    <button
                      key={optIdx}
                      onClick={() => handleSelectOption(currentQuestion.id, optIdx)}
                      className={`w-full text-left p-3.5 rounded-xl border transition-all flex items-start gap-3 ${
                        isSelected
                          ? 'bg-indigo-600/20 border-indigo-500 text-white shadow-md ring-1 ring-indigo-500/50'
                          : 'bg-slate-950/70 border-slate-800 text-slate-300 hover:bg-slate-800/80 hover:text-white'
                      }`}
                    >
                      <div
                        className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 mt-0.5 text-xs font-bold ${
                          isSelected
                            ? 'border-indigo-400 bg-indigo-500 text-white'
                            : 'border-slate-700 text-slate-400'
                        }`}
                      >
                        {String.fromCharCode(65 + optIdx)}
                      </div>
                      <div className="flex-1 text-xs sm:text-sm">
                        <MathMarkdownRenderer content={opt} msgId={`opt-${currentQuestion.id}-${optIdx}`} />
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Navigation Footer */}
              <div className="flex items-center justify-between pt-4 border-t border-slate-800">
                <button
                  disabled={currentQuestionIdx === 0}
                  onClick={() => setCurrentQuestionIdx((prev) => prev - 1)}
                  className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 disabled:opacity-40 disabled:cursor-not-allowed text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <ChevronLeft className="w-4 h-4" />
                  <span>Previous</span>
                </button>

                <div className="text-xs text-slate-400 font-mono">
                  {userAnswers[currentQuestion.id] !== undefined ? (
                    <span className="text-emerald-400 flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Option {String.fromCharCode(65 + userAnswers[currentQuestion.id])} selected
                    </span>
                  ) : (
                    <span>No option selected</span>
                  )}
                </div>

                {currentQuestionIdx < totalQuestions - 1 ? (
                  <button
                    onClick={() => setCurrentQuestionIdx((prev) => prev + 1)}
                    className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm"
                  >
                    <span>Next</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                ) : (
                  <button
                    onClick={() => setIsSubmitModalOpen(true)}
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 transition-colors shadow-md"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Review & Submit</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        )}

        {/* VIEW 3: SCORECARD, MARKS ANALYSIS & PERFORMANCE GRAPH */}
        {activeView === 'result' && latestResult && (
          <div className="p-5 lg:p-7 max-w-6xl mx-auto space-y-7">
            {/* Executive Score Summary Banner */}
            <div className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-indigo-950/60 border border-slate-800 rounded-3xl p-6 shadow-2xl relative overflow-hidden">
              <div className="flex flex-wrap items-center justify-between gap-6">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                      {latestResult.subject}
                    </span>
                    <span className="text-xs text-slate-400 font-mono">
                      Completed on {latestResult.date}
                    </span>
                  </div>
                  <h2 className="text-xl sm:text-2xl font-black text-white">
                    {latestResult.testTitle}
                  </h2>
                  <p className="text-xs text-slate-300">
                    Comprehensive pedagogical evaluation and competency analysis report.
                  </p>
                </div>

                {/* Score & Grade Display */}
                <div className="flex items-center gap-4 bg-slate-950/90 border border-slate-800 p-4 rounded-2xl shadow-inner">
                  {/* Circular Score Badge */}
                  <div className="text-center">
                    <div className="text-3xl sm:text-4xl font-black font-mono text-transparent bg-gradient-to-r from-emerald-400 via-cyan-300 to-indigo-300 bg-clip-text">
                      {latestResult.marksObtained} <span className="text-lg text-slate-500">/ {latestResult.totalMarks}</span>
                    </div>
                    <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                      Marks Scored
                    </span>
                  </div>

                  <div className="w-px h-12 bg-slate-800" />

                  {/* Percentage & Grade */}
                  <div className="text-center">
                    <div className={`text-2xl sm:text-3xl font-extrabold font-mono ${
                      latestResult.percentage >= 80 ? 'text-emerald-400' : latestResult.percentage >= 60 ? 'text-amber-400' : 'text-rose-400'
                    }`}>
                      {latestResult.percentage}%
                    </div>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full inline-block ${
                      latestResult.isPassed ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300'
                    }`}>
                      {latestResult.grade}
                    </span>
                  </div>
                </div>
              </div>

              {/* Sub-metrics bar */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-5 pt-4 border-t border-slate-800/80 text-xs">
                <div className="p-2.5 bg-slate-950/60 rounded-xl border border-slate-800/60">
                  <span className="text-slate-400 text-[10px] uppercase">Accuracy Rate</span>
                  <div className="text-sm font-bold text-white font-mono">{latestResult.accuracy}%</div>
                </div>
                <div className="p-2.5 bg-slate-950/60 rounded-xl border border-slate-800/60">
                  <span className="text-slate-400 text-[10px] uppercase">Time Spent</span>
                  <div className="text-sm font-bold text-white font-mono">{formatTime(latestResult.timeSpentSeconds)}</div>
                </div>
                <div className="p-2.5 bg-slate-950/60 rounded-xl border border-slate-800/60">
                  <span className="text-slate-400 text-[10px] uppercase">Exam Status</span>
                  <div className={`text-sm font-bold font-mono ${latestResult.isPassed ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {latestResult.isPassed ? 'Passed (Mastered)' : 'Needs Revision'}
                  </div>
                </div>
                <div className="p-2.5 bg-slate-950/60 rounded-xl border border-slate-800/60">
                  <span className="text-slate-400 text-[10px] uppercase">Total Questions</span>
                  <div className="text-sm font-bold text-white font-mono">{latestResult.questions.length} Questions</div>
                </div>
              </div>
            </div>

            {/* PLOTTED PERFORMANCE GRAPH (CRUCIAL REQUIREMENT) */}
            <TestPerformanceGraph
              currentResult={latestResult}
              history={testHistory}
              activeSubject={latestResult.subject}
            />

            {/* Pedagogical Strengths & Actionable Remediation */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-5 rounded-2xl bg-slate-900/80 border border-emerald-500/30 space-y-3">
                <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" /> Demonstrated Concept Strengths (≥80% Marks)
                </h4>
                <ul className="space-y-2 text-xs text-slate-300">
                  {latestResult.strengths.map((str, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="text-emerald-400 font-bold">•</span>
                      <span>{str}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="p-5 rounded-2xl bg-slate-900/80 border border-amber-500/30 space-y-3">
                <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4" /> Targeted Conceptual Interventions (&lt;80% Marks)
                </h4>
                <ul className="space-y-2 text-xs text-slate-300">
                  {latestResult.weaknesses.map((weak, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="text-amber-400 font-bold">•</span>
                      <span>{weak}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Next Steps Buttons */}
            <div className="flex flex-wrap items-center justify-between gap-3 p-4 bg-slate-900 rounded-2xl border border-slate-800">
              <div className="text-xs text-slate-300">
                Want to clear doubts on the questions you missed?
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => onAskTutor(`I just completed the ${latestResult.subject} test and scored ${latestResult.marksObtained}/${latestResult.totalMarks}. Can you tutor me through the concepts I need to review: ${latestResult.weaknesses.join(', ')}?`)}
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm transition-colors"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Discuss Weaknesses with AI Tutor</span>
                </button>
                <button
                  onClick={() => handleStartTest()}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1.5 transition-colors border border-slate-700"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Retake Test</span>
                </button>
                <button
                  onClick={() => setActiveView('overview')}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1.5 transition-colors border border-slate-700"
                >
                  <span>Select Another Subject</span>
                </button>
              </div>
            </div>

            {/* Detailed Question-by-Question Solution Breakdown */}
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-cyan-400" />
                Detailed Question-by-Question Model Solutions
              </h3>

              <div className="space-y-4">
                {latestResult.questions.map((q, idx) => {
                  const studentAns = latestResult.answers[q.id];
                  const isCorrect = studentAns === q.correctIndex;
                  const isSkipped = studentAns === undefined;

                  return (
                    <div
                      key={q.id}
                      className={`p-5 rounded-2xl border transition-all space-y-3 ${
                        isCorrect
                          ? 'bg-slate-900/90 border-emerald-500/30'
                          : 'bg-slate-900/90 border-rose-500/30'
                      }`}
                    >
                      {/* Question meta */}
                      <div className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-300">Question {idx + 1}</span>
                          <span className="px-2 py-0.5 rounded bg-slate-800 text-cyan-300 font-mono text-[10px]">
                            {q.conceptTag}
                          </span>
                          <span className="text-slate-400 font-mono text-[10px]">
                            {q.marks} Marks
                          </span>
                        </div>

                        {/* Status badge */}
                        <div className="flex items-center gap-1.5 font-bold font-mono">
                          {isCorrect ? (
                            <span className="text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30 flex items-center gap-1">
                              <CheckCircle2 className="w-3.5 h-3.5" /> Correct (+{q.marks} Marks)
                            </span>
                          ) : isSkipped ? (
                            <span className="text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30 flex items-center gap-1">
                              <HelpCircle className="w-3.5 h-3.5" /> Unanswered (0 Marks)
                            </span>
                          ) : (
                            <span className="text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/30 flex items-center gap-1">
                              <XCircle className="w-3.5 h-3.5" /> Incorrect (0 Marks)
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Question Statement */}
                      <div className="text-sm text-white font-medium">
                        <MathMarkdownRenderer content={q.questionText} msgId={`sol-q-${q.id}`} />
                      </div>

                      {/* Snippet if exists */}
                      {q.snippetOrFormula && (
                        <div className="p-2.5 bg-slate-950 rounded-lg text-xs font-mono text-cyan-200">
                          <MathMarkdownRenderer content={q.snippetOrFormula} msgId={`sol-snip-${q.id}`} />
                        </div>
                      )}

                      {/* Options Review */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                        {q.options.map((opt, optIdx) => {
                          const isStudentPick = studentAns === optIdx;
                          const isCorrectPick = q.correctIndex === optIdx;

                          let cardBorder = 'border-slate-800 bg-slate-950/60 text-slate-400';
                          if (isCorrectPick) {
                            cardBorder = 'border-emerald-500/60 bg-emerald-950/30 text-emerald-200 font-semibold ring-1 ring-emerald-500/40';
                          } else if (isStudentPick && !isCorrectPick) {
                            cardBorder = 'border-rose-500/60 bg-rose-950/30 text-rose-200 font-semibold ring-1 ring-rose-500/40';
                          }

                          return (
                            <div
                              key={optIdx}
                              className={`p-2.5 rounded-xl border text-xs flex items-start gap-2 ${cardBorder}`}
                            >
                              <span className="font-mono font-bold shrink-0">
                                {String.fromCharCode(65 + optIdx)}.
                              </span>
                              <div className="flex-1">
                                <MathMarkdownRenderer content={opt} msgId={`sol-opt-${q.id}-${optIdx}`} />
                              </div>
                              {isCorrectPick && (
                                <span className="text-[10px] text-emerald-400 font-bold shrink-0">
                                  ✓ Correct Key
                                </span>
                              )}
                              {isStudentPick && !isCorrectPick && (
                                <span className="text-[10px] text-rose-400 font-bold shrink-0">
                                  ✗ Your Pick
                                </span>
                              )}
                            </div>
                          );
                        })}
                      </div>

                      {/* Step-by-Step Model Explanation */}
                      <div className="p-3.5 bg-slate-950 rounded-xl border border-indigo-500/20 space-y-1.5 mt-2">
                        <span className="text-[11px] font-bold text-indigo-300 uppercase tracking-wider flex items-center gap-1.5">
                          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                          Step-by-Step Model Derivation & Rationale:
                        </span>
                        <div className="text-xs text-slate-200 leading-relaxed">
                          <MathMarkdownRenderer content={q.explanation} msgId={`exp-${q.id}`} />
                        </div>
                      </div>

                      {/* Ask tutor about this question button */}
                      <div className="flex justify-end pt-1">
                        <button
                          onClick={() => onAskTutor(`I need help understanding this ${latestResult.subject} question: "${q.questionText}". The correct answer is "${q.options[q.correctIndex]}". Can you explain the derivation in depth?`)}
                          className="text-[11px] text-indigo-400 hover:text-indigo-300 font-medium flex items-center gap-1"
                        >
                          <span>Ask AI Tutor to break down this question</span>
                          <ArrowRight className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* VIEW 4: TEST HISTORY REPORTS */}
        {activeView === 'history' && (
          <div className="p-5 lg:p-7 max-w-5xl mx-auto space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <History className="w-4 h-4 text-cyan-400" />
                  Student Examination Records & Scorecards
                </h3>
                <p className="text-xs text-slate-400">
                  Detailed logs of all completed subject tests with marks and competency radar
                </p>
              </div>

              <button
                onClick={() => setActiveView('overview')}
                className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition-colors"
              >
                Take a New Test
              </button>
            </div>

            {testHistory.length > 0 ? (
              <div className="space-y-3">
                {testHistory.map((item) => (
                  <div
                    key={item.id}
                    className="p-4 bg-slate-900 border border-slate-800 rounded-2xl flex flex-wrap items-center justify-between gap-4 hover:border-slate-700 transition-all"
                  >
                    <div className="space-y-1 max-w-md">
                      <div className="flex items-center gap-2">
                        <span className="text-[11px] font-semibold text-cyan-400 px-2 py-0.5 rounded bg-cyan-950/40 border border-cyan-800/40">
                          {item.subject}
                        </span>
                        <span className="text-xs text-slate-500 font-mono">{item.date}</span>
                      </div>
                      <h4 className="text-sm font-bold text-white">{item.testTitle}</h4>
                      <p className="text-xs text-slate-400">
                        Accuracy: {item.accuracy}% • Time Spent: {formatTime(item.timeSpentSeconds)}
                      </p>
                    </div>

                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <span className="text-xl font-black font-mono text-white">
                          {item.marksObtained}/{item.totalMarks}
                        </span>
                        <span className={`block text-xs font-bold font-mono ${
                          item.percentage >= 80 ? 'text-emerald-400' : 'text-amber-400'
                        }`}>
                          {item.percentage}% ({item.grade.split(' ')[0]})
                        </span>
                      </div>

                      <button
                        onClick={() => {
                          setLatestResult(item);
                          setActiveView('result');
                        }}
                        className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-indigo-300 hover:text-white border border-slate-700 text-xs font-semibold flex items-center gap-1 transition-colors"
                      >
                        <span>View Analytics & Graphs</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-8 text-center bg-slate-900 rounded-2xl border border-slate-800 text-slate-400 space-y-3">
                <FileCheck className="w-8 h-8 text-slate-600 mx-auto" />
                <p className="text-sm">No test attempts recorded yet.</p>
                <button
                  onClick={() => setActiveView('overview')}
                  className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold"
                >
                  Start Your First Test
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* CONFIRM SUBMISSION MODAL */}
      {isSubmitModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              Submit {activeTest.subject} Examination?
            </h3>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2 text-xs">
              <div className="flex justify-between text-slate-300">
                <span>Total Questions:</span>
                <span className="font-mono font-bold text-white">{totalQuestions}</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Answered:</span>
                <span className="font-mono font-bold text-emerald-400">{answeredCount}</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Unanswered:</span>
                <span className="font-mono font-bold text-rose-400">{totalQuestions - answeredCount}</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Time Remaining:</span>
                <span className="font-mono font-bold text-amber-300">{formatTime(secondsRemaining)}</span>
              </div>
            </div>

            {totalQuestions - answeredCount > 0 && (
              <p className="text-xs text-amber-400 flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                You have {totalQuestions - answeredCount} unanswered question(s). Unanswered questions will receive 0 marks.
              </p>
            )}

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setIsSubmitModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition-colors"
              >
                Return to Exam
              </button>
              <button
                onClick={handleConfirmSubmit}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-md transition-colors"
              >
                Confirm & Plot Marks Graph
              </button>
            </div>
          </div>
        </div>
      )}

      {/* AI CUSTOM TEST MODAL */}
      {isAiModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleGenerateAiTest}
            className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-lg w-full shadow-2xl space-y-4"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-purple-400" />
                Generate Custom AI Test for {selectedSubject}
              </h3>
              <button
                type="button"
                onClick={() => setIsAiModalOpen(false)}
                className="text-slate-400 hover:text-white text-xs"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Specific Topic / Chapter to Test:
                </label>
                <input
                  type="text"
                  required
                  value={customTopic}
                  onChange={(e) => setCustomTopic(e.target.value)}
                  placeholder={`e.g. ${
                    selectedSubject === 'Mathematics'
                      ? 'Integration by Parts & Taylor Series'
                      : selectedSubject === 'Physics & Astronomy'
                      ? 'Special Relativity & Time Dilation'
                      : 'Core Concepts & Analytical Reasoning'
                  }`}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white placeholder-slate-500 outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Target Cognitive Difficulty:
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['easy', 'medium', 'hard'] as const).map((diff) => (
                    <button
                      type="button"
                      key={diff}
                      onClick={() => setCustomDifficulty(diff)}
                      className={`p-2 rounded-xl text-center capitalize border font-medium transition-all ${
                        customDifficulty === diff
                          ? 'bg-purple-600/30 border-purple-500 text-white font-bold'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {diff}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setIsAiModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-medium"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={!customTopic.trim() || isGeneratingAiTest}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-bold disabled:opacity-40 flex items-center gap-1.5 shadow-md"
              >
                {isGeneratingAiTest ? (
                  <>
                    <Sparkles className="w-3.5 h-3.5 animate-spin" />
                    <span>Synthesizing Exam...</span>
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5 fill-white" />
                    <span>Generate & Launch Test</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

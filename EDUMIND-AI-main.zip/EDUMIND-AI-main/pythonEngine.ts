import { AcademicSubject, QuizQuestion, StudentProfile, StudyPlanPhase, TestAttemptResult, TutorMode } from '../types';
import { SubjectTest } from '../architecture/subjectTestsData';
import { getPyodideCore, PyodideInstance } from './pythonVisualizer';
import { createAcademicInquiryPipeline } from '../architecture/patterns';

let engineLoadedPromise: Promise<PyodideInstance> | null = null;
let loadedPythonSource: string = '';

/**
 * Boot the in-browser Python 3 frontend engine (/python/edumind_engine.py) via Pyodide.
 * Runs alongside React while Node.js (server.ts) powers the chatbot & AI endpoints.
 */
export async function bootPythonFrontendEngine(): Promise<PyodideInstance> {
  if (!engineLoadedPromise) {
    engineLoadedPromise = (async () => {
      const [pyodide, res] = await Promise.all([
        getPyodideCore(),
        fetch('/python/edumind_engine.py'),
      ]);

      if (!res.ok) {
        throw new Error(`Failed to load Python frontend engine: HTTP ${res.status}`);
      }

      const source = await res.text();
      loadedPythonSource = source;
      await pyodide.runPythonAsync(source);
      return pyodide;
    })().catch((err) => {
      engineLoadedPromise = null;
      throw err;
    });
  }

  return await engineLoadedPromise;
}

export function getLoadedPythonEngineSource(): string {
  return loadedPythonSource;
}

export interface PythonSubjectDetection {
  detectedSubject: AcademicSubject | null;
  effectiveSubject: AcademicSubject;
  cognitiveLevel: string;
  recommendedMode: TutorMode | null;
  poweredBy: 'python' | 'fallback';
}

/**
 * Classify a chatbot question's academic subject & Bloom level using Python (edumind_engine.py).
 */
export async function detectSubjectWithPython(
  query: string,
  activeSubject: AcademicSubject
): Promise<PythonSubjectDetection> {
  try {
    const pyodide = await bootPythonFrontendEngine();
    pyodide.globals.set('_edumind_q', query);
    pyodide.globals.set('_edumind_subj', activeSubject);
    try {
      const raw: string = await pyodide.runPythonAsync(
        `detect_subject_and_mode(_edumind_q, _edumind_subj)`
      );
      const parsed = JSON.parse(raw);
      return {
        detectedSubject: parsed.detectedSubject || null,
        effectiveSubject: (parsed.effectiveSubject || activeSubject) as AcademicSubject,
        cognitiveLevel: parsed.cognitiveLevel || 'Understand',
        recommendedMode: (parsed.recommendedMode as TutorMode | null) || null,
        poweredBy: 'python',
      };
    } finally {
      pyodide.globals.delete('_edumind_q');
      pyodide.globals.delete('_edumind_subj');
    }
  } catch {
    // Immediate fallback if Pyodide is still initializing during the first second
    const pipeline = createAcademicInquiryPipeline();
    const ctx = pipeline.handle({ query });
    return {
      detectedSubject: ctx.detectedSubject || null,
      effectiveSubject: ctx.detectedSubject || activeSubject,
      cognitiveLevel: ctx.cognitiveLevel || 'Understand',
      recommendedMode: ctx.recommendedMode || null,
      poweredBy: 'fallback',
    };
  }
}

/**
 * Grade a Subject Test using Python (edumind_engine.evaluate_subject_test).
 */
export async function evaluateTestWithPython(
  test: SubjectTest,
  userAnswers: Record<string, number>,
  timeSpentSeconds: number
): Promise<TestAttemptResult> {
  try {
    const pyodide = await bootPythonFrontendEngine();
    pyodide.globals.set('_edumind_test_json', JSON.stringify(test));
    pyodide.globals.set('_edumind_answers_json', JSON.stringify(userAnswers));
    pyodide.globals.set('_edumind_time_secs', timeSpentSeconds);
    try {
      const raw: string = await pyodide.runPythonAsync(
        `evaluate_subject_test(_edumind_test_json, _edumind_answers_json, _edumind_time_secs)`
      );
      return JSON.parse(raw) as TestAttemptResult;
    } finally {
      pyodide.globals.delete('_edumind_test_json');
      pyodide.globals.delete('_edumind_answers_json');
      pyodide.globals.delete('_edumind_time_secs');
    }
  } catch {
    // Safe fallback if Python runtime was blocked
    let marksObtained = 0;
    let correctCount = 0;
    const topicMap: Record<string, { total: number; scored: number }> = {};
    test.questions.forEach((q) => {
      if (!topicMap[q.conceptTag]) topicMap[q.conceptTag] = { total: 0, scored: 0 };
      topicMap[q.conceptTag].total += q.marks;
      if (userAnswers[q.id] === q.correctIndex) {
        marksObtained += q.marks;
        correctCount += 1;
        topicMap[q.conceptTag].scored += q.marks;
      }
    });
    const percentage = Math.round((marksObtained / Math.max(1, test.totalMarks)) * 100);
    const accuracy = Math.round((correctCount / Math.max(1, test.questions.length)) * 100);
    const isPassed = marksObtained >= test.passingMarks;
    const grade =
      percentage >= 90 ? 'A+ (Mastery)' :
      percentage >= 80 ? 'A (Distinction)' :
      percentage >= 70 ? 'B (Proficient)' :
      percentage >= 60 ? 'C (Satisfactory)' : 'Needs Revision';

    const topicBreakdown = Object.entries(topicMap).map(([topic, stat]) => ({
      topic,
      marksObtained: stat.scored,
      totalMarks: stat.total,
      percentage: stat.total > 0 ? Math.round((stat.scored / stat.total) * 100) : 0,
    }));

    return {
      id: `attempt-${Date.now()}`,
      testId: test.id,
      testTitle: test.title,
      subject: test.subject,
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      timestamp: Date.now(),
      timeSpentSeconds,
      marksObtained,
      totalMarks: test.totalMarks,
      percentage,
      grade,
      isPassed,
      accuracy,
      answers: userAnswers,
      topicBreakdown,
      strengths: topicBreakdown.filter((t) => t.percentage >= 80).map((t) => `${t.topic} (${t.percentage}% marks scored)`),
      weaknesses: topicBreakdown.filter((t) => t.percentage < 80).map((t) => `${t.topic} (Scored ${t.marksObtained}/${t.totalMarks} marks)`),
      questions: test.questions,
    };
  }
}

/**
 * Evaluate Active Recall Quiz session via Python (edumind_engine.evaluate_quiz_session).
 */
export async function evaluateQuizWithPython(
  questions: QuizQuestion[],
  selectedAnswers: Record<string, number>
): Promise<{ correctCount: number; totalCount: number; percentage: number }> {
  try {
    const pyodide = await bootPythonFrontendEngine();
    pyodide.globals.set('_edumind_quiz_q', JSON.stringify(questions));
    pyodide.globals.set('_edumind_quiz_a', JSON.stringify(selectedAnswers));
    try {
      const raw: string = await pyodide.runPythonAsync(
        `evaluate_quiz_session(_edumind_quiz_q, _edumind_quiz_a)`
      );
      return JSON.parse(raw);
    } finally {
      pyodide.globals.delete('_edumind_quiz_q');
      pyodide.globals.delete('_edumind_quiz_a');
    }
  } catch {
    let correctCount = 0;
    questions.forEach((q) => {
      if (selectedAnswers[q.id] === q.correctIndex) correctCount++;
    });
    return {
      correctCount,
      totalCount: questions.length,
      percentage: Math.round((correctCount / Math.max(1, questions.length)) * 100),
    };
  }
}

/**
 * Calibrate student mastery scores via Python (edumind_engine.calibrate_mastery_scores).
 */
export async function calibrateMasteryWithPython(
  currentScores: StudentProfile['masteryScores'],
  eventType: 'TEST_COMPLETED' | 'QUIZ_SUBMITTED' | 'FOCUS_COMPLETED',
  scorePct: number
): Promise<StudentProfile['masteryScores']> {
  try {
    const pyodide = await bootPythonFrontendEngine();
    pyodide.globals.set('_edumind_mastery_json', JSON.stringify(currentScores));
    pyodide.globals.set('_edumind_event_type', event_type_safe(eventType));
    pyodide.globals.set('_edumind_score_pct', scorePct);
    try {
      const raw: string = await pyodide.runPythonAsync(
        `calibrate_mastery_scores(_edumind_mastery_json, _edumind_event_type, _edumind_score_pct)`
      );
      return JSON.parse(raw) as StudentProfile['masteryScores'];
    } finally {
      pyodide.globals.delete('_edumind_mastery_json');
      pyodide.globals.delete('_edumind_event_type');
      pyodide.globals.delete('_edumind_score_pct');
    }
  } catch {
    const updated = { ...currentScores };
    if (eventType === 'TEST_COMPLETED') {
      updated.examReadiness = Math.min(100, Math.round((updated.examReadiness + scorePct) / 2));
      updated.analyticalProblemSolving = Math.min(100, Math.round((updated.analyticalProblemSolving + scorePct * 0.9) / 2));
    } else if (eventType === 'QUIZ_SUBMITTED') {
      updated.retentionAndRecall = Math.min(100, updated.retentionAndRecall + (scorePct >= 70 ? 4 : 1));
      updated.examReadiness = Math.min(100, Math.round((updated.examReadiness + scorePct) / 2));
    } else if (eventType === 'FOCUS_COMPLETED') {
      updated.criticalThinking = Math.min(100, updated.criticalThinking + 1);
    }
    return updated;
  }
}

function event_type_safe(t: string): string {
  return t;
}

/**
 * Compute Study Plan progress using Python (edumind_engine.compute_study_progress).
 */
export async function computeStudyProgressWithPython(
  phases: StudyPlanPhase[]
): Promise<{
  totalModules: number;
  completedModules: number;
  progressPercent: number;
  completedMinutes: number;
  totalMinutes: number;
}> {
  try {
    const pyodide = await bootPythonFrontendEngine();
    pyodide.globals.set('_edumind_phases_json', JSON.stringify(phases));
    try {
      const raw: string = await pyodide.runPythonAsync(
        `compute_study_progress(_edumind_phases_json)`
      );
      return JSON.parse(raw);
    } finally {
      pyodide.globals.delete('_edumind_phases_json');
    }
  } catch {
    const mods = phases.flatMap((p) => p.modules);
    const completed = mods.filter((m) => m.completed);
    return {
      totalModules: mods.length,
      completedModules: completed.length,
      progressPercent: mods.length > 0 ? Math.round((completed.length / mods.length) * 100) : 0,
      completedMinutes: completed.reduce((s, m) => s + m.estimatedMinutes, 0),
      totalMinutes: mods.reduce((s, m) => s + m.estimatedMinutes, 0),
    };
  }
}

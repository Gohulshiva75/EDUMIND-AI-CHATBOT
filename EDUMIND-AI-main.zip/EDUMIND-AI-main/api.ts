import { StudyPlan, QuizQuestion } from '../types';

export interface AcademicAnalysisResult {
  summary: string;
  status: 'mastered' | 'needs_revision' | 'conceptual_gap';
  comprehensionScore: number;
  strengths: string[];
  errorsAndMisconceptions: string[];
  designThinkingInsight: string;
  stepByStepModelSolution: string;
  keyTakeaway: string;
}

/**
 * Stream a chat response from the server via SSE for ANY subject
 */
export async function streamChatResponse(
  messages: { role: string; content: string }[],
  mode: string,
  subject: string,
  speedMode: 'fast' | 'detailed' = 'fast',
  studentContext: string | undefined,
  onChunk: (chunkText: string) => void,
  onComplete: () => void,
  onError: (err: Error) => void
): Promise<() => void> {
  const controller = new AbortController();

  try {
    const response = await fetch('/api/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        messages,
        mode,
        subject,
        speedMode,
        studentContext,
      }),
      signal: controller.signal,
    });

    if (!response.ok) {
      const errData = await response.json().catch(() => ({}));
      throw new Error(errData.error || `HTTP error ${response.status}`);
    }

    const reader = response.body?.getReader();
    if (!reader) {
      throw new Error('ReadableStream not supported by browser.');
    }

    const decoder = new TextDecoder('utf-8');
    let buffer = '';

    const read = async () => {
      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split('\n');
          buffer = lines.pop() || '';

          for (const line of lines) {
            const trimmed = line.trim();
            if (trimmed.startsWith('data: ')) {
              const dataStr = trimmed.slice(6).trim();
              if (!dataStr) continue;
              try {
                const parsed = JSON.parse(dataStr);
                if (parsed.error) {
                  onError(new Error(parsed.error));
                  return;
                }
                if (parsed.text) {
                  onChunk(parsed.text);
                }
                if (parsed.done) {
                  onComplete();
                  return;
                }
              } catch (e) {
                // Ignore incomplete line parse errors
              }
            }
          }
        }
        onComplete();
      } catch (err: any) {
        if (err.name !== 'AbortError') {
          onError(err);
        }
      }
    };

    read();
  } catch (err: any) {
    onError(err);
  }

  return () => {
    controller.abort();
  };
}

/**
 * Generate an interactive study plan via server Gemini for ANY academic subject
 */
export async function generateStudyPlan(params: {
  subject: string;
  level: string;
  targetDays: number;
  dailyHours: number;
  goals: string;
}): Promise<StudyPlan> {
  const res = await fetch('/api/generate-study-plan', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to generate study plan');
  }

  const data = await res.json();
  return {
    ...data,
    id: `plan-${Date.now()}`,
    createdAt: new Date().toISOString(),
  };
}

/**
 * Analyze an academic problem or student work in any subject
 */
export async function analyzeAcademicProblem(params: {
  problemText: string;
  studentWork: string;
  subject: string;
}): Promise<AcademicAnalysisResult> {
  const res = await fetch('/api/analyze-academic-problem', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to analyze problem');
  }

  return await res.json();
}

/**
 * Generate practice quiz questions for any subject
 */
export async function generateQuiz(
  topic: string,
  subject = 'General Academia',
  difficulty = 'medium',
  count = 3
): Promise<{ topic: string; subject: string; questions: QuizQuestion[] }> {
  const res = await fetch('/api/generate-quiz', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ topic, subject, difficulty, count }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to generate quiz');
  }

  return await res.json();
}

/**
 * Design Thinking step-by-step assistance for any academic topic
 */
export async function fetchDesignThinkingAssist(params: {
  phase: string;
  projectIdea: string;
  subject?: string;
  notes: string;
}): Promise<any> {
  const res = await fetch('/api/design-thinking-assist', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to process design thinking request');
  }

  return await res.json();
}

import React, { useState, useRef, useEffect } from 'react';
import { 
  Send, 
  Sparkles, 
  Volume2, 
  VolumeX, 
  Mic, 
  MicOff, 
  RotateCcw, 
  Microscope, 
  Lightbulb, 
  Zap, 
  BookOpen, 
  ArrowRight,
  GraduationCap,
  ChevronDown,
  RefreshCw
} from 'lucide-react';
import { ChatMessage, StudentProfile, TutorMode, AcademicSubject } from '../../types';
import { streamChatResponse } from '../../services/api';
import { speakText, stopSpeaking } from '../../utils/audio';
import { MathMarkdownRenderer } from './MathMarkdownRenderer';
import { 
  SocraticStrategy, 
  ConceptualDeepDiveStrategy, 
  DesignThinkingProblemStrategy, 
  ExamDrillStrategy 
} from '../../architecture/patterns';
import { detectSubjectWithPython } from '../../utils/pythonEngine';

interface ChatInterfaceProps {
  studentProfile: StudentProfile;
  currentMode: TutorMode;
  onSelectMode: (mode: TutorMode) => void;
  onSelectSubject: (subject: AcademicSubject) => void;
  onOpenStudyPlanTab: () => void;
  onOpenProblemLab: () => void;
}

export const ChatInterface: React.FC<ChatInterfaceProps> = ({
  studentProfile,
  currentMode,
  onSelectMode,
  onSelectSubject,
  onOpenStudyPlanTab,
  onOpenProblemLab,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome-1',
      role: 'assistant',
      content: `Hello ${studentProfile.name}! 👋 I am **Edumind AI**, your intelligent student companion for **all academic subjects**.

I integrate **Design Thinking** cognitive problem solving with deep academic scaffolding across **STEM, Humanities, Social Sciences, and Languages**.

### How I can support your learning:
- 🎓 **Socratic Academic Tutor**: Guided questioning, first-principles intuition, and real-world physical analogies.
- 🔬 **Deep Concept & Derivation**: Rigorous mathematical derivations, scientific mechanisms, and theoretical analysis.
- 💡 **Design Thinking Problem Solver**: Empathize, Define, Ideate, Prototype, and Test solutions for complex assignments, essays, or research.
- ⚡ **High-Yield Exam Prep**: Mnemonics, 1-page formula summaries, trap avoidance, and diagnostic drills.

Currently focusing on **${studentProfile.activeSubject}**. What problem, theory, or equation would you like to explore today? *(Ask any question and the academic subject will automatically adapt!)*`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      mode: 'socratic',
      subject: studentProfile.activeSubject,
    },
  ]);

  const [input, setInput] = useState('');
  const [isStreaming, setIsStreaming] = useState(false);
  const [speedMode, setSpeedMode] = useState<'fast' | 'detailed'>('fast');
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const [isListening, setIsListening] = useState(false);
  const [currentStreamingText, setCurrentStreamingText] = useState('');
  const [subjectToast, setSubjectToast] = useState<string | null>(null);
  const [isSubjectDropdownOpen, setIsSubjectDropdownOpen] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const abortStreamRef = useRef<(() => void) | null>(null);
  const streamTimeoutRef = useRef<any>(null);
  const recognitionRef = useRef<any>(null);

  const availableSubjects: AcademicSubject[] = [
    'Mathematics',
    'Physics & Astronomy',
    'Chemistry & BioChem',
    'Biology & Medicine',
    'Computer Science & AI',
    'Economics & Business',
    'History & Social Studies',
    'Literature & Philosophy',
    'Engineering',
    'General Academia',
  ];

  // Auto-scroll
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, currentStreamingText]);

  // Keep welcome message synced with newly chosen subject before user sends messages
  useEffect(() => {
    setMessages((prev) => {
      if (prev.length === 1 && prev[0].id === 'welcome-1') {
        return [
          {
            ...prev[0],
            subject: studentProfile.activeSubject,
            content: prev[0].content.replace(
              /Currently focusing on \*\*[^*]+\*\*/,
              `Currently focusing on **${studentProfile.activeSubject}**`
            ),
          },
        ];
      }
      return prev;
    });
  }, [studentProfile.activeSubject]);

  // Speech recognition setup
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-US';

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInput((prev) => (prev ? `${prev} ${transcript}` : transcript));
        setIsListening(false);
      };

      recognition.onerror = () => {
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
    }
  }, []);

  const toggleMic = () => {
    if (!recognitionRef.current) {
      alert('Speech recognition is not supported in this browser.');
      return;
    }
    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      try {
        recognitionRef.current.start();
        setIsListening(true);
      } catch (e) {
        setIsListening(false);
      }
    }
  };

  // Dynamic Strategy Suggested Pills for active subject
  const getStrategyPills = () => {
    switch (currentMode) {
      case 'deepExplanation':
        return new ConceptualDeepDiveStrategy().getSuggestedPills(studentProfile.activeSubject);
      case 'designThinking':
        return new DesignThinkingProblemStrategy().getSuggestedPills(studentProfile.activeSubject);
      case 'examPrep':
        return new ExamDrillStrategy().getSuggestedPills(studentProfile.activeSubject);
      default:
        return new SocraticStrategy().getSuggestedPills(studentProfile.activeSubject);
    }
  };

  const handleSend = async (textToSend?: string) => {
    const query = (textToSend || input).trim();
    if (!query || isStreaming) return;

    setInput('');

    // Clear any pending stream timer
    if (streamTimeoutRef.current) {
      clearTimeout(streamTimeoutRef.current);
    }

    // Run inquiry classification through the Python frontend engine (edumind_engine.py)
    const processedContext = await detectSubjectWithPython(query, studentProfile.activeSubject);

    // Use Python-detected subject or student's active subject
    const detected = processedContext.detectedSubject;
    const effectiveSubject = detected || studentProfile.activeSubject;
    const effectiveMode = processedContext.recommendedMode || currentMode;

    // Dynamically update the application-wide subject if recognized from the question!
    if (detected && detected !== studentProfile.activeSubject) {
      onSelectSubject(detected);
      setSubjectToast(`🎯 Subject automatically switched to ${detected} based on your question!`);
      setTimeout(() => setSubjectToast(null), 4500);
    }

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: 'user',
      content: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      subject: effectiveSubject,
    };

    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setIsStreaming(true);
    setCurrentStreamingText('');

    let accumulatedText = '';

    // Safety timeout: if 14 seconds pass without any response chunk, abort and show helpful notice with retry
    streamTimeoutRef.current = setTimeout(() => {
      if (!accumulatedText.trim()) {
        if (abortStreamRef.current) abortStreamRef.current();
        setIsStreaming(false);
        setCurrentStreamingText('');
        const timeoutMsg: ChatMessage = {
          id: `msg-timeout-${Date.now()}`,
          role: 'assistant',
          content: `⚠️ **Response Notice**: The AI engine took longer than expected to stream the first chunk.\n\n*Click "Retry" below or switch between **⚡ Turbo Fast** (~1s) and **Deep In-Depth**.*`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          subject: effectiveSubject,
        };
        setMessages((prev) => [...prev, timeoutMsg]);
      }
    }, 14000);

    try {
      const cancelStream = await streamChatResponse(
        newMessages.map((m) => ({ role: m.role, content: m.content })),
        effectiveMode,
        effectiveSubject,
        speedMode,
        `Student Experience: ${studentProfile.experienceLevel}. Major: ${studentProfile.major}. Goal: ${studentProfile.targetExamOrGoal}`,
        (chunk) => {
          if (streamTimeoutRef.current) {
            clearTimeout(streamTimeoutRef.current);
          }
          accumulatedText += chunk;
          setCurrentStreamingText(accumulatedText);
        },
        () => {
          if (streamTimeoutRef.current) {
            clearTimeout(streamTimeoutRef.current);
          }
          setIsStreaming(false);
          if (!accumulatedText.trim()) {
            const fallbackMsg: ChatMessage = {
              id: `msg-${Date.now() + 1}`,
              role: 'assistant',
              content: `⚡ **Edumind AI Tutor Notice**: The AI engine finished without text. Please click the button below to retry or ask another question in **${effectiveSubject}**.`,
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              mode: effectiveMode,
              subject: effectiveSubject,
            };
            setMessages((prev) => [...prev, fallbackMsg]);
            setCurrentStreamingText('');
            return;
          }
          const assistantMsg: ChatMessage = {
            id: `msg-${Date.now() + 1}`,
            role: 'assistant',
            content: accumulatedText,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            mode: effectiveMode,
            subject: effectiveSubject,
          };
          setMessages((prev) => [...prev, assistantMsg]);
          setCurrentStreamingText('');
        },
        (error) => {
          if (streamTimeoutRef.current) {
            clearTimeout(streamTimeoutRef.current);
          }
          setIsStreaming(false);
          setCurrentStreamingText('');
          const errorMsg: ChatMessage = {
            id: `msg-err-${Date.now()}`,
            role: 'assistant',
            content: `⚠️ **Unable to complete answer**: ${error.message}\n\n*Tip*: Switch to **⚡ Turbo Fast** mode above the input box for ultra-low latency responses, or try rephrasing your question!`,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          };
          setMessages((prev) => [...prev, errorMsg]);
        }
      );

      abortStreamRef.current = cancelStream;
    } catch (err: any) {
      if (streamTimeoutRef.current) {
        clearTimeout(streamTimeoutRef.current);
      }
      setIsStreaming(false);
      setCurrentStreamingText('');
      const errorMsg: ChatMessage = {
        id: `msg-err-${Date.now()}`,
        role: 'assistant',
        content: `⚠️ **Connection Error**: ${err?.message || 'Failed to start stream'}`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorMsg]);
    }
  };

  const handleSpeak = (text: string, id: string) => {
    if (speakingId === id) {
      stopSpeaking();
      setSpeakingId(null);
    } else {
      setSpeakingId(id);
      speakText(text, () => setSpeakingId(null));
    }
  };

  const handleResetChat = () => {
    stopSpeaking();
    if (streamTimeoutRef.current) clearTimeout(streamTimeoutRef.current);
    if (abortStreamRef.current) abortStreamRef.current();
    setIsStreaming(false);
    setCurrentStreamingText('');
    setMessages([
      {
        id: `welcome-${Date.now()}`,
        role: 'assistant',
        content: `Chat session refreshed for **${studentProfile.activeSubject}**! What concept or problem should we tackle now?`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        mode: currentMode,
        subject: studentProfile.activeSubject,
      },
    ]);
  };

  return (
    <div className="flex flex-col h-full bg-slate-950/40 relative">
      {/* Header Mode & Subject Banner */}
      <div className="px-4 py-2.5 bg-slate-900/60 border-b border-slate-800/60 flex items-center justify-between text-xs relative">
        <div className="flex items-center gap-2">
          <span className="text-slate-400 font-medium">Subject:</span>
          <div className="relative">
            <button
              onClick={() => setIsSubjectDropdownOpen(!isSubjectDropdownOpen)}
              className="font-semibold text-cyan-300 hover:text-cyan-200 flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-cyan-950/40 border border-cyan-800/40 hover:bg-cyan-900/50 transition-colors shadow-sm"
              title="Click to manually switch subject or ask a question to auto-detect"
            >
              <GraduationCap className="w-3.5 h-3.5 text-cyan-400" />
              <span>{studentProfile.activeSubject}</span>
              <ChevronDown className="w-3 h-3 text-cyan-400 ml-0.5" />
            </button>

            {isSubjectDropdownOpen && (
              <div className="absolute left-0 top-full mt-1.5 z-40 w-56 rounded-xl bg-slate-900 border border-slate-700 shadow-2xl p-1.5 space-y-0.5 max-h-64 overflow-y-auto">
                <div className="px-2 py-1 text-[10px] uppercase font-bold text-slate-400 border-b border-slate-800">
                  Select Academic Subject
                </div>
                {availableSubjects.map((subj) => (
                  <button
                    key={subj}
                    onClick={() => {
                      onSelectSubject(subj);
                      setIsSubjectDropdownOpen(false);
                      setSubjectToast(`Switched active subject to ${subj}`);
                      setTimeout(() => setSubjectToast(null), 3500);
                    }}
                    className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                      studentProfile.activeSubject === subj
                        ? 'bg-indigo-600 text-white font-semibold'
                        : 'text-slate-300 hover:bg-slate-800 hover:text-cyan-300'
                    }`}
                  >
                    {subj}
                  </button>
                ))}
              </div>
            )}
          </div>

          <span className="text-slate-500">•</span>
          <span className="font-medium text-indigo-300 flex items-center gap-1">
            {currentMode === 'deepExplanation' && <Microscope className="w-3.5 h-3.5 text-cyan-400" />}
            {currentMode === 'designThinking' && <Lightbulb className="w-3.5 h-3.5 text-emerald-400" />}
            {currentMode === 'examPrep' && <Zap className="w-3.5 h-3.5 text-rose-400" />}
            {currentMode === 'socratic' && <BookOpen className="w-3.5 h-3.5 text-indigo-400" />}
            {currentMode === 'deepExplanation'
              ? 'Conceptual Deep-Dive'
              : currentMode === 'designThinking'
              ? 'Design Thinking Solver'
              : currentMode === 'examPrep'
              ? 'Exam High-Yield Drill'
              : 'Socratic Tutor'}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenProblemLab}
            className="px-2.5 py-1 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/20 text-[11px] font-medium flex items-center gap-1 transition-colors"
          >
            <span>Problem Lab</span>
            <ArrowRight className="w-3 h-3" />
          </button>
          <button
            onClick={onOpenStudyPlanTab}
            className="px-2.5 py-1 rounded-lg bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-300 border border-indigo-500/20 text-[11px] font-medium flex items-center gap-1 transition-colors"
          >
            <span>Study Plan</span>
            <ArrowRight className="w-3 h-3" />
          </button>
          <button
            onClick={handleResetChat}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
            title="Clear Chat Conversation"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Auto subject update notification toast */}
      {subjectToast && (
        <div className="bg-indigo-950/90 border-b border-indigo-500/40 px-4 py-1.5 text-xs text-indigo-200 flex items-center justify-between shadow-sm animate-fadeIn">
          <div className="flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            <span className="font-medium">{subjectToast}</span>
          </div>
          <button
            onClick={() => setSubjectToast(null)}
            className="text-slate-400 hover:text-white text-xs px-1"
          >
            ✕
          </button>
        </div>
      )}

      {/* Message Stream */}
      <div className="flex-1 overflow-y-auto p-4 lg:p-6 space-y-5">
        {messages.map((message) => {
          const isUser = message.role === 'user';
          return (
            <div
              key={message.id}
              className={`flex gap-3 max-w-4xl mx-auto ${isUser ? 'justify-end' : 'justify-start'}`}
            >
              {!isUser && (
                <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-600 to-cyan-500 flex items-center justify-center text-white shrink-0 shadow-md ring-1 ring-white/10 mt-0.5">
                  <Sparkles className="w-4 h-4" />
                </div>
              )}

              <div
                className={`rounded-2xl p-4 transition-all relative ${
                  isUser
                    ? 'bg-indigo-600 text-white max-w-xl shadow-md rounded-tr-none'
                    : 'bg-slate-900/80 border border-slate-800/80 text-slate-200 max-w-3xl shadow-sm rounded-tl-none w-full'
                }`}
              >
                {!isUser && (
                  <div className="flex items-center justify-between mb-2 pb-2 border-b border-slate-800/60 text-xs">
                    <span className="font-semibold text-indigo-300 flex items-center gap-1.5">
                      Edumind AI Academic Tutor
                      {message.subject && (
                        <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-cyan-300 font-normal">
                          {message.subject}
                        </span>
                      )}
                      <span className="text-[10px] text-slate-500 font-normal">({message.timestamp})</span>
                    </span>

                    <button
                      onClick={() => handleSpeak(message.content, message.id)}
                      className={`p-1 rounded text-[11px] flex items-center gap-1 transition-colors ${
                        speakingId === message.id
                          ? 'text-cyan-300 bg-cyan-500/20'
                          : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                      }`}
                      title={speakingId === message.id ? 'Stop reading' : 'Listen to explanation'}
                    >
                      {speakingId === message.id ? (
                        <>
                          <VolumeX className="w-3.5 h-3.5 text-cyan-400" />
                          <span className="text-[10px]">Stop Audio</span>
                        </>
                      ) : (
                        <>
                          <Volume2 className="w-3.5 h-3.5" />
                          <span className="text-[10px]">Read Aloud</span>
                        </>
                      )}
                    </button>
                  </div>
                )}

                {isUser ? (
                  <p className="text-sm leading-relaxed whitespace-pre-wrap">{message.content}</p>
                ) : (
                  <MathMarkdownRenderer content={message.content} msgId={message.id} />
                )}
              </div>

              {isUser && (
                <div className="w-8 h-8 rounded-xl bg-slate-800 flex items-center justify-center text-indigo-300 shrink-0 font-bold text-xs ring-1 ring-slate-700 mt-0.5">
                  {studentProfile.name.charAt(0)}
                </div>
              )}
            </div>
          );
        })}

        {/* Immediate loading state before first token */}
        {isStreaming && !currentStreamingText && (
          <div className="flex gap-3 max-w-4xl mx-auto justify-start animate-pulse">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 to-indigo-600 flex items-center justify-center text-white shrink-0 shadow-md ring-1 ring-white/10 mt-0.5">
              <Sparkles className="w-4 h-4 animate-spin" />
            </div>
            <div className="bg-slate-900/90 border border-amber-500/40 text-slate-200 max-w-md shadow-sm rounded-2xl rounded-tl-none p-4">
              <div className="flex items-center gap-2 text-xs font-semibold text-amber-300">
                <span className="inline-block w-2 h-2 rounded-full bg-amber-400 animate-ping" />
                {speedMode === 'fast' ? '⚡ Turbo Fast: Delivering instant answer (~1s)...' : '🔬 Formulating in-depth academic breakdown...'}
              </div>
              <div className="mt-2.5 flex items-center gap-2 text-slate-400 text-xs">
                <span className="w-2 h-2 rounded-full bg-indigo-400 animate-bounce" />
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-bounce" style={{ animationDelay: '300ms' }} />
                <span className="text-[11px] text-slate-400 font-mono ml-1">Streaming across {studentProfile.activeSubject}...</span>
              </div>
            </div>
          </div>
        )}

        {/* Live streaming chunk card with real-time math rendering */}
        {isStreaming && currentStreamingText && (
          <div className="flex gap-3 max-w-4xl mx-auto justify-start">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-600 to-cyan-500 flex items-center justify-center text-white shrink-0 shadow-md ring-1 ring-white/10 mt-0.5 animate-pulse">
              <Sparkles className="w-4 h-4" />
            </div>
            <div className="bg-slate-900/80 border border-indigo-500/30 text-slate-200 max-w-3xl shadow-sm rounded-2xl rounded-tl-none p-4 w-full">
              <div className="flex items-center gap-2 mb-2 pb-2 border-b border-slate-800/60 text-xs text-indigo-400 font-medium">
                <span className="inline-block w-2 h-2 rounded-full bg-indigo-400 animate-ping" />
                Edumind AI reasoning across {studentProfile.activeSubject}...
              </div>
              <MathMarkdownRenderer content={currentStreamingText} msgId="streaming" />
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Prompt Chips based on subject & strategy */}
      <div className="px-4 py-2 bg-slate-950/80 border-t border-slate-800/80 overflow-x-auto flex items-center gap-2 no-scrollbar">
        <span className="text-[11px] font-semibold text-slate-400 shrink-0 uppercase tracking-wide">
          {studentProfile.activeSubject.split(' ')[0]} Prompts:
        </span>
        {getStrategyPills().map((pill, idx) => (
          <button
            key={idx}
            onClick={() => handleSend(pill)}
            disabled={isStreaming}
            className="text-xs px-3 py-1.5 rounded-full bg-slate-900 hover:bg-indigo-600/20 hover:border-indigo-500/50 border border-slate-800 text-slate-300 hover:text-indigo-200 shrink-0 transition-all text-left truncate max-w-xs disabled:opacity-50"
          >
            {pill}
          </button>
        ))}
      </div>

      {/* Chat Input Bar with Turbo/Fast Mode Selector */}
      <div className="p-3 sm:p-4 bg-slate-900/80 border-t border-slate-800 backdrop-blur-md space-y-2">
        <div className="max-w-4xl mx-auto flex items-center justify-between text-[11px] text-slate-400">
          <div className="flex items-center gap-1.5">
            <span className="font-semibold text-slate-400">Answer Speed:</span>
            <button
              type="button"
              onClick={() => setSpeedMode('fast')}
              className={`flex items-center gap-1 px-2.5 py-0.5 rounded-full font-semibold transition-all ${
                speedMode === 'fast'
                  ? 'bg-amber-500/25 text-amber-300 border border-amber-500/50 shadow-sm shadow-amber-500/20'
                  : 'text-slate-400 hover:text-slate-200 border border-transparent'
              }`}
              title="Turbo Fast: Instant streaming in ~1s, concise and high-yield"
            >
              <Zap className="w-3 h-3 text-amber-400 fill-amber-400" />
              <span>Turbo Fast (~1s)</span>
            </button>
            <button
              type="button"
              onClick={() => setSpeedMode('detailed')}
              className={`flex items-center gap-1 px-2.5 py-0.5 rounded-full font-semibold transition-all ${
                speedMode === 'detailed'
                  ? 'bg-indigo-500/25 text-indigo-300 border border-indigo-500/50 shadow-sm shadow-indigo-500/20'
                  : 'text-slate-400 hover:text-slate-200 border border-transparent'
              }`}
              title="Deep In-Depth: Exhaustive derivations, edge cases, formulas, and proofs"
            >
              <BookOpen className="w-3 h-3 text-indigo-400" />
              <span>Deep In-Depth</span>
            </button>
          </div>
          <span className="text-[10px] text-slate-400 hidden sm:inline">
            ⚡ Ultra-Fast Gemini Engine with Math Typesetting & Auto Subject Adaptation
          </span>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="max-w-4xl mx-auto flex items-end gap-2"
        >
          <div className="flex-1 bg-slate-950 rounded-2xl border border-slate-800 focus-within:border-indigo-500/80 focus-within:ring-2 focus-within:ring-indigo-500/20 transition-all p-2 flex items-center gap-2">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              placeholder={`Ask anything in ${studentProfile.activeSubject} (e.g. "Explain Newton's second law", "Derive quadratic equation", "What is photosynthesis")...`}
              rows={1}
              className="w-full bg-transparent text-sm text-slate-100 placeholder-slate-500 resize-none outline-none px-2 py-1 max-h-32"
            />

            {/* Mic speech-to-text button */}
            <button
              type="button"
              onClick={toggleMic}
              className={`p-2 rounded-xl transition-colors ${
                isListening
                  ? 'bg-rose-500 text-white animate-pulse'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
              title={isListening ? 'Listening... click to stop' : 'Voice input'}
            >
              {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>
          </div>

          <button
            type="submit"
            disabled={!input.trim() || isStreaming}
            className="h-11 w-11 rounded-2xl bg-gradient-to-tr from-indigo-600 to-cyan-500 hover:from-indigo-500 hover:to-cyan-400 text-white flex items-center justify-center shadow-lg shadow-indigo-600/30 transition-all disabled:opacity-40 disabled:cursor-not-allowed shrink-0"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};

"""
Edumind AI — Frontend Python Engine (Pyodide Runtime)
Runs in-browser alongside React while Node.js (server.ts) powers the AI Chatbot & API backend.
"""

import json
from datetime import datetime


SUBJECT_KEYWORDS = {
    "Physics & Astronomy": [
        "quantum", "relativity", "thermodynamics", "entropy", "mechanics", "kinematics",
        "velocity", "acceleration", "gravity", "gravitation", "orbital", "electromagnetism",
        "faraday", "lenz", "photon", "wavelength", "de broglie", "carnot", "momentum",
        "force", "energy", "rocket", "astrophysics", "optics", "circuit", "magnetic flux",
    ],
    "Mathematics": [
        "calculus", "derivative", "integral", "matrix", "eigenvalue", "eigenvector",
        "linear algebra", "limit", "taylor series", "poisson", "probability", "variance",
        "bayes", "differential equation", "optimization", "extrema", "polynomial",
        "trigonometry", "logarithm", "theorem", "proof", "determinant", "vector",
    ],
    "Chemistry & BioChem": [
        "acid", "base", "ph", "molecule", "stoichiometry", "periodic table", "orbital",
        "organic chemistry", "equilibrium", "le chatelier", "compound", "chemical reaction",
        "ion", "covalent", "enthalpy", "gibbs", "redox", "titration", "catalyst",
        "molar", "mole", "chemical bond", "vsepr", "hybridization", "kinetics", "hcl",
    ],
    "Biology & Medicine": [
        "dna", "rna", "cell", "gene", "evolution", "organism", "mitochondria", "enzyme",
        "photosynthesis", "mitosis", "meiosis", "anatomy", "organ", "nephron", "renal",
        "disease", "virus", "bacteria", "ecology", "ecosystem", "protein synthesis",
        "vaccine", "mrna", "immune", "physiology", "respiration", "chromosome", "atp",
    ],
    "Computer Science & AI": [
        "code", "algorithm", "python", "java", "c++", "javascript", "data structure",
        "binary tree", "avl", "red-black", "recursion", "complexity", "big o", "database",
        "sql", "api", "machine learning", "neural network", "transformer", "attention",
        "heapsort", "dynamic programming", "3nf", "normal form", "compiler", "debugging",
    ],
    "Economics & Business": [
        "inflation", "gdp", "monetary policy", "market", "fiscal", "supply and demand",
        "elasticity", "interest rate", "stock market", "finance", "revenue", "profit",
        "monopoly", "macroeconomics", "microeconomics", "opportunity cost",
        "nash equilibrium", "game theory", "capm", "central bank", "bonds",
    ],
    "History & Social Studies": [
        "war", "treaty", "revolution", "century", "empire", "constitution", "civil rights",
        "westphalia", "industrial revolution", "cold war", "world war", "renaissance",
        "montesquieu", "separation of powers", "judicial review", "marbury", "marshall plan",
        "feudalism", "monarchy", "colonization", "democracy", "historical",
    ],
    "Literature & Philosophy": [
        "poem", "poetry", "metaphor", "novel", "philosophy", "existentialism", "thesis statement",
        "shakespeare", "hamlet", "ethics", "deontology", "utilitarianism", "socrates",
        "plato", "aristotle", "kant", "sartre", "nietzsche", "epistemology", "hamartia",
        "oxymoron", "allegory", "symbolism", "rhetoric",
    ],
    "Engineering": [
        "stress", "strain", "young's modulus", "truss", "beam", "structural", "rlc",
        "resonance", "fourier", "thermal conduction", "control system", "bibo", "laplace",
        "robotics", "fluid dynamics", "heat transfer", "cad", "mechanical engineering",
    ],
}


def detect_subject_and_mode(query: str, active_subject: str) -> str:
    """Classify user chatbot question into academic subject, Bloom cognitive level, and recommended mode."""
    q = (query or "").lower()

    best_subject = None
    best_score = 0

    for subject, terms in SUBJECT_KEYWORDS.items():
        score = 0
        for term in terms:
            if term in q:
                score += 2 if " " in term else 1
        if score > best_score:
            best_score = score
            best_subject = subject

    if any(w in q for w in ("why", "explain", "how does")):
        cognitive_level = "Understand"
    elif any(w in q for w in ("solve", "calculate", "find the", "derive")):
        cognitive_level = "Apply"
    elif any(w in q for w in ("compare", "contrast", "difference between", "analyze")):
        cognitive_level = "Analyze"
    elif any(w in q for w in ("evaluate", "critique", "is it true")):
        cognitive_level = "Evaluate"
    elif any(w in q for w in ("design", "create", "brainstorm", "write an outline")):
        cognitive_level = "Create"
    else:
        cognitive_level = "Remember"

    recommended_mode = "designThinking" if cognitive_level == "Create" else None

    return json.dumps({
        "detectedSubject": best_subject if best_score > 0 else None,
        "effectiveSubject": best_subject if best_score > 0 else active_subject,
        "cognitiveLevel": cognitive_level,
        "recommendedMode": recommended_mode,
    })


def evaluate_subject_test(test_json: str, answers_json: str, time_spent_seconds: int) -> str:
    """Grade a completed Subject Test in Python and produce full topic/mark diagnostics."""
    test = json.loads(test_json)
    answers = json.loads(answers_json)

    questions = test.get("questions", [])
    total_marks = max(1, int(test.get("totalMarks", 1)))
    passing_marks = int(test.get("passingMarks", round(total_marks * 0.6)))

    marks_obtained = 0
    correct_count = 0
    topic_map = {}

    for q in questions:
        qid = q.get("id", "")
        q_marks = int(q.get("marks", 6))
        topic = q.get("conceptTag", "Core Concept")
        if topic not in topic_map:
            topic_map[topic] = {"total": 0, "scored": 0}
        topic_map[topic]["total"] += q_marks

        student_ans = answers.get(qid)
        if student_ans is not None and int(student_ans) == int(q.get("correctIndex", -1)):
            marks_obtained += q_marks
            correct_count += 1
            topic_map[topic]["scored"] += q_marks

    percentage = round((marks_obtained / total_marks) * 100)
    accuracy = round((correct_count / max(1, len(questions))) * 100)
    is_passed = marks_obtained >= passing_marks

    if percentage >= 90:
        grade = "A+ (Mastery)"
    elif percentage >= 80:
        grade = "A (Distinction)"
    elif percentage >= 70:
        grade = "B (Proficient)"
    elif percentage >= 60:
        grade = "C (Satisfactory)"
    else:
        grade = "Needs Revision"

    topic_breakdown = []
    for topic, stats in topic_map.items():
        tot = stats["total"]
        sc = stats["scored"]
        pct = round((sc / tot) * 100) if tot > 0 else 0
        topic_breakdown.append({
            "topic": topic,
            "marksObtained": sc,
            "totalMarks": tot,
            "percentage": pct,
        })

    strengths = [
        f"{t['topic']} ({t['percentage']}% marks scored)"
        for t in topic_breakdown if t["percentage"] >= 80
    ]
    weaknesses = [
        f"{t['topic']} (Scored {t['marksObtained']}/{t['totalMarks']} marks)"
        for t in topic_breakdown if t["percentage"] < 80
    ]

    if not strengths:
        strengths = ["Foundation concepts reviewed"]
    if not weaknesses:
        weaknesses = ["None! Perfect performance across all tested topics."]

    now_ms = int(datetime.now().timestamp() * 1000)

    result = {
        "id": f"attempt-{now_ms}",
        "testId": test.get("id", ""),
        "testTitle": test.get("title", ""),
        "subject": test.get("subject", "General Academia"),
        "date": datetime.now().strftime("%b %d, %Y"),
        "timestamp": now_ms,
        "timeSpentSeconds": max(0, int(time_spent_seconds)),
        "marksObtained": marks_obtained,
        "totalMarks": total_marks,
        "percentage": percentage,
        "grade": grade,
        "isPassed": is_passed,
        "accuracy": accuracy,
        "answers": answers,
        "topicBreakdown": topic_breakdown,
        "strengths": strengths,
        "weaknesses": weaknesses,
        "questions": questions,
    }
    return json.dumps(result)


def evaluate_quiz_session(questions_json: str, answers_json: str) -> str:
    """Evaluate active-recall quiz session in Python."""
    questions = json.loads(questions_json)
    answers = json.loads(answers_json)

    correct = 0
    for q in questions:
        qid = q.get("id", "")
        if answers.get(qid) is not None and int(answers[qid]) == int(q.get("correctIndex", -1)):
            correct += 1

    total = max(1, len(questions))
    percent = round((correct / total) * 100)
    return json.dumps({
        "correctCount": correct,
        "totalCount": len(questions),
        "percentage": percent,
    })


def calibrate_mastery_scores(mastery_json: str, event_type: str, score_pct: float) -> str:
    """Dynamically calibrate the 6 academic mastery scores in Python."""
    scores = dict(json.loads(mastery_json))
    pct = float(score_pct)

    if event_type == "TEST_COMPLETED":
        scores["examReadiness"] = min(100, round((scores.get("examReadiness", 75) + pct) / 2))
        scores["analyticalProblemSolving"] = min(
            100, round((scores.get("analyticalProblemSolving", 75) + pct * 0.9) / 2)
        )
    elif event_type == "QUIZ_SUBMITTED":
        delta = 4 if pct >= 70 else 1
        scores["retentionAndRecall"] = min(100, round(scores.get("retentionAndRecall", 75) + delta))
        scores["examReadiness"] = min(100, round((scores.get("examReadiness", 75) + pct) / 2))
    elif event_type == "FOCUS_COMPLETED":
        scores["criticalThinking"] = min(100, round(scores.get("criticalThinking", 80) + 1))

    return json.dumps(scores)


def compute_study_progress(phases_json: str) -> str:
    """Compute overall study plan completion percentage and minutes logged in Python."""
    phases = json.loads(phases_json)
    total_modules = 0
    completed_modules = 0
    completed_minutes = 0
    total_minutes = 0

    for phase in phases:
        for mod in phase.get("modules", []):
            total_modules += 1
            mins = int(mod.get("estimatedMinutes", 30))
            total_minutes += mins
            if mod.get("completed"):
                completed_modules += 1
                completed_minutes += mins

    pct = round((completed_modules / total_modules) * 100) if total_modules > 0 else 0
    return json.dumps({
        "totalModules": total_modules,
        "completedModules": completed_modules,
        "progressPercent": pct,
        "completedMinutes": completed_minutes,
        "totalMinutes": total_minutes,
    })

/**
 * Design Thinking Pipeline Architecture
 * 
 * Implements the Stanford d.school 5-Phase Framework as a structured
 * cognitive engine for personalized academic tutoring across ALL subjects.
 */

import { StudentProfile, AcademicSubject } from '../types';

export interface EmpathyContext {
  studentMood: 'Confident' | 'Struggling' | 'Curious' | 'Overwhelmed' | 'Exam-Anxious';
  strugglingTopic?: string;
  preferredModality: 'Visual Analogy' | 'Step-by-Step Derivation' | 'Real-World Case Study' | 'Socratic Q&A';
  knownPainPoints: string[];
}

export interface ProblemDefinition {
  coreQuestion: string;
  identifiedKnowledgeGap: string;
  howMightWeStatement: string;
  learningTarget: string;
}

export interface IdeationOutcome {
  alternativeExplanations: {
    approachName: string;
    description: string;
    pros: string;
  }[];
  recommendedApproach: string;
}

export interface LearningPrototype {
  prototypeType: 'Step-by-Step Worked Example' | 'Diagnostic Micro-Quiz' | 'Conceptual Diagram / Mindmap' | 'Interactive Problem Sandbox';
  actionableStep: string;
  prototypeDraft?: string;
}

export interface TestEvaluation {
  verificationQuestion: string;
  rubric: string[];
  reflectionPrompt: string;
}

export class DesignThinkingPipeline {
  /**
   * Phase 1: EMPATHIZE
   * Diagnoses the student's cognitive state and emotional blockers across any subject.
   */
  public static empathize(profile: StudentProfile, query: string, subject: AcademicSubject): EmpathyContext {
    const qLower = query.toLowerCase();
    let studentMood: EmpathyContext['studentMood'] = 'Curious';

    if (qLower.includes('stuck') || qLower.includes('dont understand') || qLower.includes('confused') || qLower.includes('fail') || qLower.includes('hard')) {
      studentMood = 'Struggling';
    } else if (qLower.includes('exam tomorrow') || qLower.includes('urgent') || qLower.includes('stressed') || qLower.includes('test') || qLower.includes('cram')) {
      studentMood = 'Exam-Anxious';
    } else if (qLower.includes('too much') || qLower.includes('overwhelmed') || qLower.includes('tired')) {
      studentMood = 'Overwhelmed';
    } else if (qLower.includes('deep dive') || qLower.includes('master') || qLower.includes('first principles')) {
      studentMood = 'Confident';
    }

    const painPoints: string[] = [];
    if (qLower.includes('derivative') || qLower.includes('integral') || qLower.includes('equation')) painPoints.push('Mathematical mechanics & boundary notation');
    if (qLower.includes('why') || qLower.includes('intuition') || qLower.includes('analogy')) painPoints.push('Abstract conceptual intuition');
    if (qLower.includes('memorize') || qLower.includes('forget') || qLower.includes('formula')) painPoints.push('Long-term retention & active recall');
    if (qLower.includes('proof') || qLower.includes('derive') || qLower.includes('causality')) painPoints.push('Rigorous step-by-step argumentation');

    return {
      studentMood,
      strugglingTopic: painPoints[0] || `${subject} Core Fundamentals`,
      preferredModality: profile.preferredLearningStyle.includes('Visual') ? 'Visual Analogy' : 'Step-by-Step Derivation',
      knownPainPoints: painPoints.length > 0 ? painPoints : ['Conceptual clarity & foundational intuition']
    };
  }

  /**
   * Phase 2: DEFINE
   * Synthesizes student questions into a precise "How Might We" problem statement.
   */
  public static define(query: string, empathy: EmpathyContext, subject: AcademicSubject): ProblemDefinition {
    const topic = empathy.strugglingTopic || subject;
    return {
      coreQuestion: query,
      identifiedKnowledgeGap: `Difficulty bridging the gap between abstract theory and concrete application in ${topic}`,
      howMightWeStatement: `How might we demystify ${topic} using intuitive physical analogies and structured scaffolding so the student achieves lasting comprehension?`,
      learningTarget: `Student can explain the core principle in their own words and independently solve a representative problem.`
    };
  }

  /**
   * Phase 3: IDEATE
   * Brainstorms multiple instructional avenues before picking the optimal one.
   */
  public static ideate(definition: ProblemDefinition, empathy: EmpathyContext): IdeationOutcome {
    const approaches = [
      {
        approachName: 'Real-World Physical Analogy',
        description: 'Relate the abstract academic mechanism to tangible everyday phenomena (e.g., flow of water, financial ledgers, physical levers).',
        pros: 'Rapid intuitive understanding without cognitive overload.'
      },
      {
        approachName: 'First-Principles Step-by-Step Derivation',
        description: 'Provide an incremental, causal progression proving why the outcome must be true.',
        pros: 'Deep academic rigor and bulletproof retention.'
      },
      {
        approachName: 'Trap Analysis & Common Misconception Deconstruction',
        description: 'Examine common wrong answers and explain precisely why standard intuition fails.',
        pros: 'Shields students against trick exam questions.'
      }
    ];

    const recommended = empathy.studentMood === 'Exam-Anxious' 
      ? 'Trap Analysis & Common Misconception Deconstruction' 
      : (empathy.preferredModality === 'Visual Analogy' ? 'Real-World Physical Analogy' : 'First-Principles Step-by-Step Derivation');

    return {
      alternativeExplanations: approaches,
      recommendedApproach: recommended
    };
  }

  /**
   * Phase 4: PROTOTYPE
   * Forms the actionable micro-learning artifact.
   */
  public static createPrototype(ideation: IdeationOutcome, subject: string): LearningPrototype {
    return {
      prototypeType: 'Step-by-Step Worked Example',
      actionableStep: `Execute the curated prototype problem, verify each intermediary calculation or claim, and formulate your own test case.`,
      prototypeDraft: `// Representative Prototype Problem in ${subject} for rapid mental model validation`
    };
  }

  /**
   * Phase 5: TEST
   * Formulates the verification check to validate learning retention.
   */
  public static test(definition: ProblemDefinition): TestEvaluation {
    return {
      verificationQuestion: `Without looking at references, can you explain the primary causal mechanism behind "${definition.identifiedKnowledgeGap}"?`,
      rubric: [
        'States the foundational axiom or definition accurately',
        'Avoids common misconceptions and circular reasoning',
        'Applies the concept to an unfamiliar boundary case'
      ],
      reflectionPrompt: `What was the key breakthrough in this explanation that made it click for you?`
    };
  }
}

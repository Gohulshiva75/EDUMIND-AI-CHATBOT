import { Flashcard, AcademicSubject } from '../types';

export interface SubjectProblemSample {
  id: string;
  subject: AcademicSubject;
  title: string;
  topic: string;
  description: string;
  problemStatement: string;
  stepByStepSolution: string;
  designThinkingDecomposition: {
    empathize: string;
    define: string;
    ideate: string;
    prototype: string;
    test: string;
  };
  keyTakeaway: string;
}

export const MULTI_SUBJECT_SAMPLES: SubjectProblemSample[] = [
  {
    id: 'math-calc',
    subject: 'Mathematics',
    title: 'Optimization via Derivatives & First Principles',
    topic: 'Calculus & Optimization',
    description: 'Finding global extrema and inflection points using the First and Second Derivative Tests.',
    problemStatement: 'A cylindrical container must hold 1,000 cm³ of liquid. Find the dimensions (radius r and height h) that minimize the total surface area of metal needed.',
    stepByStepSolution: `1. Volume constraint: V = π·r²·h = 1000  =>  h = 1000 / (π·r²)
2. Surface Area objective: A(r) = 2·π·r² + 2·π·r·h
   Substitute h: A(r) = 2·π·r² + 2·π·r·(1000 / (π·r²)) = 2·π·r² + 2000/r
3. Take the first derivative and set to zero:
   A'(r) = 4·π·r - 2000/r² = 0
   4·π·r³ = 2000  =>  r³ = 500/π  =>  r = (500/π)^(1/3) ≈ 5.42 cm
4. Calculate height:
   h = 1000 / (π · 5.42²) ≈ 10.84 cm = 2r (Optimal cylinder height equals diameter!)
5. Verify minimum with Second Derivative:
   A''(r) = 4·π + 4000/r³ > 0 for all r > 0. Hence, it is a strict minimum.`,
    designThinkingDecomposition: {
      empathize: 'Students struggle with connecting physical packaging constraints to abstract derivatives.',
      define: 'HMW minimize surface material cost while satisfying a fixed volume boundary?',
      ideate: 'Option A: Trial-and-error table. Option B: Geometric Lagrange multipliers. Option C: Single-variable derivative substitution.',
      prototype: 'Formulate single-variable objective function A(r) = 2πr² + 2000/r.',
      test: 'Check second derivative test A\'\'(r) > 0 and verify dimensional units (cm²).'
    },
    keyTakeaway: 'In cylindrical optimization, minimizing surface area always results in height h = 2r (height equals diameter).'
  },
  {
    id: 'physics-thermo',
    subject: 'Physics & Astronomy',
    title: 'Carnot Engine Efficiency & Entropy',
    topic: 'Thermodynamics',
    description: 'Applying the Second Law of Thermodynamics and maximum theoretical efficiency limits.',
    problemStatement: 'A geothermal power plant operates between a deep underground reservoir at 180°C and cooling towers at 25°C. Calculate the theoretical maximum Carnot efficiency.',
    stepByStepSolution: `1. Convert temperatures to absolute Kelvin:
   T_hot = 180 + 273.15 = 453.15 K
   T_cold = 25 + 273.15 = 298.15 K
2. Apply Carnot Efficiency Formula:
   η_max = 1 - (T_cold / T_hot)
3. Compute ratio:
   η_max = 1 - (298.15 / 453.15) = 1 - 0.6579 = 0.3421 (34.2%)
4. Thermodynamic conclusion:
   Even with frictionless turbines and zero heat leaks, 65.8% of geothermal energy MUST be rejected to the sink as waste heat due to the Second Law (entropy generation).`,
    designThinkingDecomposition: {
      empathize: 'Students often forget to convert Celsius to Kelvin, resulting in absurd negative or >100% efficiencies.',
      define: 'HMW calculate absolute upper-bound mechanical energy extraction without violating entropy?',
      ideate: 'Contrast real Rankine cycles vs the reversible ideal Carnot cycle.',
      prototype: 'Formula wireframe: η = 1 - (T_sink / T_source) where T is strictly in Kelvin.',
      test: 'Verify that 0 < η < 1 and that η approaches 1 only when T_cold approaches absolute zero (0 K).'
    },
    keyTakeaway: 'Always convert temperature to Kelvin in thermodynamic calculations; no heat engine can exceed Carnot efficiency.'
  },
  {
    id: 'bio-cellular',
    subject: 'Biology & Medicine',
    title: 'Cellular Respiration & Chemiosmosis',
    topic: 'Biochemistry & Bioenergetics',
    description: 'How the mitochondrial proton gradient drives ATP synthase rotary motor mechanics.',
    problemStatement: 'Explain how the electron transport chain (ETC) couples exergonic redox reactions to endergonic ATP phosphorylation.',
    stepByStepSolution: `1. Electron donors NADH and FADH2 deliver high-energy electrons to Complex I and Complex II.
2. Progressive Redox Cascade: Electrons cascade through Coenzyme Q, Complex III, Cytochrome c, and Complex IV to terminal oxygen (forming H2O).
3. Proton Pumping: Free energy released at Complexes I, III, and IV pumps H+ ions from mitochondrial matrix into the intermembrane space.
4. Proton-Motive Force (PMF): Creates both a pH gradient (chemical) and voltage potential (electrical) across the inner membrane.
5. Rotary Chemiosmosis: H+ ions flow back through ATP Synthase (F0 subunit rotation), driving conformational changes in F1 catalytic head to phosphorylate ADP + Pi -> ATP (~30-32 ATP per glucose).`,
    designThinkingDecomposition: {
      empathize: 'Students find the sheer number of cytochromes and complexes overwhelming.',
      define: 'HMW conceptualize the mitochondrial membrane as a hydroelectric dam?',
      ideate: 'Analogy: Pump water up into a reservoir (H+ gradient), let water flow through a turbine (ATP Synthase) to generate electricity (ATP).',
      prototype: 'Visual flow: Redox Energy -> H+ Reservoir -> Mechanical Turbine Rotation -> Chemical Bond Energy.',
      test: 'What happens if an uncoupler like DNP punctures the membrane? (Protons leak, ATP drops, energy dissipates as heat).'
    },
    keyTakeaway: 'The ETC is not directly making ATP—it is pumping a proton battery; ATP Synthase is the rotary turbine powered by that battery.'
  },
  {
    id: 'econ-nash',
    subject: 'Economics & Business',
    title: 'Game Theory & Nash Equilibrium',
    topic: 'Microeconomics & Strategic Choice',
    description: 'Analyzing simultaneous non-cooperative games and prisoner dilemma outcomes.',
    problemStatement: 'Two competing smartphone manufacturers must decide whether to invest $50M in AI features. If both invest, profits increase by $30M each. If neither invests, profits stay at $0. If one invests and the other does not, the innovator gains $80M while the competitor loses $40M. Find the Nash Equilibrium.',
    stepByStepSolution: `1. Construct Payoff Matrix (Firm A \\ Firm B):
   - Both Invest: A earns ($30M - $50M) = -$20M, B earns -$20M.
   - Only A Invests: A earns ($80M - $50M) = +$30M, B earns -$40M.
   - Only B Invests: A earns -$40M, B earns +$30M.
   - Neither Invests: A earns $0, B earns $0.
2. Determine Firm A's best response:
   - If B Invests: A choosing Invest gives -$20M vs No Invest gives -$40M. (-$20M > -$40M => Invest!)
   - If B Does Not Invest: A choosing Invest gives +$30M vs No Invest gives $0. (+$30M > $0 => Invest!)
   - Thus, "Invest" is a strictly dominant strategy for Firm A.
3. By symmetry, "Invest" is also strictly dominant for Firm B.
4. Nash Equilibrium: Both firms choose to Invest (Payoff: -$20M each).
5. Economic Paradox: Mutual non-investment would yield $0 each (better than -$20M), but individual rationality drives both to an inferior outcome.`,
    designThinkingDecomposition: {
      empathize: 'Students often assume actors cooperate for the collective good rather than private incentives.',
      define: 'HMW model why rational competition can lead to suboptimal collective states?',
      ideate: 'Use dominant strategy elimination test across every rival choice.',
      prototype: '2x2 quadrant payoff grid with best-response underlines.',
      test: 'Is either player motivated to unilaterally deviate from (Invest, Invest)? No, confirming strict Nash Equilibrium.'
    },
    keyTakeaway: 'In a Prisoner\'s Dilemma, dominant strategies lead to a stable Nash Equilibrium that is Pareto-inefficient.'
  },
  {
    id: 'chem-equil',
    subject: 'Chemistry & BioChem',
    title: 'Gibbs Free Energy & Reaction Spontaneity',
    topic: 'Chemical Thermodynamics',
    description: 'Determining temperature thresholds where endothermic, entropy-driven reactions become spontaneous.',
    problemStatement: 'A decomposition reaction has ΔH° = +178 kJ/mol and ΔS° = +160 J/(mol·K). Above what temperature T (in Kelvin and °C) does the reaction become thermodynamically spontaneous?',
    stepByStepSolution: `1. Convert entropy units to kJ/(mol·K):
   ΔS° = 160 J/(mol·K) = 0.160 kJ/(mol·K)
2. Set Gibbs Free Energy condition for spontaneity (ΔG° < 0):
   ΔG° = ΔH° - T·ΔS° = 0  =>  T = ΔH° / ΔS°
3. Calculate crossover temperature:
   T = 178 / 0.160 = 1,112.5 K  (839.35 °C)
4. Conclusion:
   Because ΔH° > 0 and ΔS° > 0, the reaction is non-spontaneous at room temperature and becomes spontaneous above 1,112.5 K.`,
    designThinkingDecomposition: {
      empathize: 'Students frequently forget to match kJ and J units between ΔH and ΔS.',
      define: 'HMW pinpoint the exact thermal tipping point where entropy overcomes enthalpy?',
      ideate: 'Check sign table of ΔH and ΔS before solving ΔH - TΔS = 0.',
      prototype: 'T_eq = (ΔH in kJ) / (ΔS in kJ/K).',
      test: 'Substitute T = 1200 K: ΔG = 178 - 1200(0.160) = -14 kJ/mol < 0 (Spontaneous).'
    },
    keyTakeaway: 'Always align energy units (kJ vs J) before computing T = ΔH / ΔS.'
  },
  {
    id: 'cs-dp',
    subject: 'Computer Science & AI',
    title: 'Dynamic Programming & Attention Complexity',
    topic: 'Algorithms & Machine Learning',
    description: 'Analyzing O(N²) self-attention scaling and optimal substructure in dynamic programming.',
    problemStatement: 'Explain why Transformer self-attention scales as O(N²) in sequence length N, and compute the memory ratio when increasing context window from N = 1,024 to N = 8,192 tokens.',
    stepByStepSolution: `1. Attention formula: Attention(Q, K, V) = softmax(Q·K^T / √d_k) · V
2. Matrix dimensions: Q is (N × d_k) and K^T is (d_k × N).
3. Multiplying Q·K^T produces an N × N attention score matrix.
4. Scaling factor when N increases 8× (from 1,024 to 8,192):
   Ratio = (8192 / 1024)² = 8² = 64× more attention operations and memory!`,
    designThinkingDecomposition: {
      empathize: 'Students treat context length scaling as linear rather than quadratic.',
      define: 'HMW visualize how pairwise token interactions drive quadratic complexity?',
      ideate: 'Draw an N × N interaction grid where every token attends to every other token.',
      prototype: 'Ops ~ N² · d_k.',
      test: 'Doubling sequence length N quadruples (2² = 4×) the attention matrix size.'
    },
    keyTakeaway: 'Standard self-attention forms an N × N pairwise matrix, making compute and KV-attention scale quadratically with N.'
  },
  {
    id: 'hist-const',
    subject: 'History & Social Studies',
    title: 'Westphalian Sovereignty & Separation of Powers',
    topic: 'Constitutional History & Geopolitics',
    description: 'Tracing how the Peace of Westphalia (1648) and Enlightenment theory shaped modern nation-states.',
    problemStatement: 'Contrast the geopolitical impact of the Peace of Westphalia (1648) with Montesquieu\'s Separation of Powers (1748) in shaping modern constitutional states.',
    stepByStepSolution: `1. External Sovereignty (Westphalia, 1648):
   Ended the Thirty Years' War and established territorial integrity and non-interference between sovereign states.
2. Internal Checks & Balances (Montesquieu, 1748):
   Addressed tyranny within the state by dividing legislative, executive, and judicial powers.
3. Synthesis:
   Westphalia defined external autonomy among states; Enlightenment constitutionalism structured internal accountability inside them.`,
    designThinkingDecomposition: {
      empathize: 'Learners often memorize dates without seeing how external and internal governance rules fit together.',
      define: 'HMW separate state-to-state rules from citizen-to-state constitutional protections?',
      ideate: 'Compare a nation\'s borders (external sovereignty) vs its internal blueprint (checks and balances).',
      prototype: 'Two-axis matrix: External Sovereignty (1648) × Internal Division of Power (1748).',
      test: 'Apply both principles to explain modern constitutional treaties and judicial review.'
    },
    keyTakeaway: 'Modern governance combines Westphalian external sovereignty with Enlightenment internal checks and balances.'
  },
  {
    id: 'lit-ethics',
    subject: 'Literature & Philosophy',
    title: 'Deontology vs. Utilitarianism in Ethical Dilemmas',
    topic: 'Normative Ethics & Rhetoric',
    description: 'Evaluating moral choices under Kantian universal maxims versus consequentialist utility.',
    problemStatement: 'Compare how Immanuel Kant\'s Categorical Imperative and John Stuart Mill\'s Utilitarianism evaluate the morality of breaking a promise to prevent a minor inconvenience to five people.',
    stepByStepSolution: `1. Utilitarian Analysis (Consequentialist):
   Evaluates net well-being produced. If breaking the promise avoids greater aggregate pain than the harm caused by distrust, an act-utilitarian may permit it.
2. Kantian Deontology (Duty-Based):
   Applies the Universalizability formulation: if everyone broke promises whenever convenient, the institution of promising would collapse.
3. Conclusion:
   Kant strictly forbids breaking the promise as a violation of rational duty, whereas act-utilitarianism weighs total consequences.`,
    designThinkingDecomposition: {
      empathize: 'Students conflate "good intentions" with Kantian duty or "majority rule" with utilitarianism.',
      define: 'HMW test an ethical rule using both outcome math and universal logic?',
      ideate: 'Apply two distinct lenses: Outcome Ledger (Mill) vs Universal Law Test (Kant).',
      prototype: 'Decision matrix contrasting Action-Focus vs Outcome-Focus.',
      test: 'Check edge case: rule-utilitarianism vs strict deontology on long-term societal trust.'
    },
    keyTakeaway: 'Deontology judges the intrinsic rule/duty of an action; utilitarianism judges the net consequences.'
  },
  {
    id: 'eng-rlc',
    subject: 'Engineering',
    title: 'RLC Circuit Resonance & Structural Elasticity',
    topic: 'Signals, Circuits & Mechanics',
    description: 'Calculating resonant angular frequency and impedance cancellation in AC engineering systems.',
    problemStatement: 'A series RLC circuit has R = 50 Ω, L = 20 mH, and C = 5 µF. Determine the resonant angular frequency ω₀, resonant frequency f₀ (in Hz), and the total impedance Z at resonance.',
    stepByStepSolution: `1. Convert parameters to SI base units:
   L = 20 × 10⁻³ H = 0.02 H,   C = 5 × 10⁻⁶ F
2. Resonant angular frequency ω₀ = 1 / √(L·C):
   L·C = 0.02 × 5 × 10⁻⁶ = 1 × 10⁻⁷ s²
   ω₀ = 1 / √(10⁻⁷) ≈ 3,162.3 rad/s
3. Resonant frequency f₀ = ω₀ / (2π):
   f₀ = 3,162.3 / (2π) ≈ 503.3 Hz
4. Impedance at resonance:
   Since X_L = X_C, imaginary reactance cancels completely, leaving purely resistive Z = R = 50 Ω.`,
    designThinkingDecomposition: {
      empathize: 'Unit prefixes (mH, µF) cause factor-of-1000 errors in circuit calculations.',
      define: 'HMW verify reactance cancellation cleanly in SI units?',
      ideate: 'Convert to Henrys and Farads first, then check ω₀L = 1/(ω₀C).',
      prototype: 'Impedance phasor diagram showing +jX_L canceling -jX_C.',
      test: 'Verify X_L = 3162.3 × 0.02 ≈ 63.25 Ω and X_C = 1/(3162.3 × 5e-6) ≈ 63.25 Ω.'
    },
    keyTakeaway: 'At electrical resonance, inductive and capacitive reactances cancel, minimizing series impedance to Z = R.'
  },
  {
    id: 'gen-logic',
    subject: 'General Academia',
    title: 'Falsifiability, Type I Error & Causal Inference',
    topic: 'Scientific Method & Formal Logic',
    description: 'Distinguishing correlation from causation and controlling false-positive error rates.',
    problemStatement: 'An observational study finds a strong positive correlation (r = 0.85) between ice cream sales and drowning incidents. Explain why policy banning ice cream will fail and identify the logical/statistical principles involved.',
    stepByStepSolution: `1. Confounding Variable (Lurking Variable):
   Summer temperature/heat drives BOTH higher ice cream purchases and increased swimming activity.
2. Correlation vs. Causation:
   Strong correlation (r = 0.85) does not establish direct causal mechanism.
3. Hypothesis Testing & Falsifiability:
   A randomized intervention or controlled stratification by temperature immediately falsifies the "ice cream causes drowning" hypothesis.`,
    designThinkingDecomposition: {
      empathize: 'High r-values trick readers into assuming direct cause and effect.',
      define: 'HMW uncover hidden confounding variables in observational datasets?',
      ideate: 'Draw a causal DAG (Directed Acyclic Graph) linking Season -> Ice Cream and Season -> Swimming.',
      prototype: 'Control for temperature (partial correlation) to test if correlation vanishes.',
      test: 'Check if controlling for temperature drops the partial correlation near zero.'
    },
    keyTakeaway: 'Always test for confounding variables and falsifiable mechanisms before inferring causation from correlation.'
  }
];

export const ALL_SUBJECTS_FLASHCARDS: Flashcard[] = [
  {
    id: 'fc-m1',
    subject: 'Mathematics',
    category: 'Calculus',
    front: 'What does the derivative f\'(x) represent geometrically and physically?',
    back: 'Geometrically: The exact slope of the tangent line to the curve at point x.\nPhysically: The instantaneous rate of change of the dependent variable with respect to x (e.g. position -> velocity).',
    formulaOrExample: `f'(x) = lim(h->0) [f(x+h) - f(x)] / h`,
    mastered: true
  },
  {
    id: 'fc-p1',
    subject: 'Physics & Astronomy',
    category: 'Electromagnetism',
    front: 'What is Lenz\'s Law and how does it uphold the Conservation of Energy?',
    back: 'An induced electromotive force (EMF) always generates a current whose magnetic field OPPOSES the change in magnetic flux that produced it. If it aided the flux, it would create free energy from nowhere!',
    formulaOrExample: `EMF = - d(Φ_B) / dt  (The negative sign represents Lenz's Law)`,
    mastered: false
  },
  {
    id: 'fc-c1',
    subject: 'Chemistry & BioChem',
    category: 'Equilibrium',
    front: 'State Le Chatelier\'s Principle in simple terms.',
    back: 'When a dynamic chemical system at equilibrium is subjected to a disturbance (change in concentration, pressure, or temperature), the system shifts in whichever direction counteracts that disturbance.',
    formulaOrExample: `N2(g) + 3H2(g) ⇌ 2NH3(g) + Heat\nIncreasing pressure shifts right (fewer gas moles).`,
    mastered: false
  },
  {
    id: 'fc-b1',
    subject: 'Biology & Medicine',
    category: 'Genetics',
    front: 'What is the Central Dogma of Molecular Biology?',
    back: 'Genetic information flows unidirectionally from DNA (replication) -> RNA (transcription via RNA polymerase) -> Protein (translation via ribosomes).',
    formulaOrExample: `DNA -> (Transcription) -> mRNA -> (Translation) -> Polypeptide`,
    mastered: true
  },
  {
    id: 'fc-cs1',
    subject: 'Computer Science & AI',
    category: 'Algorithms',
    front: 'Explain the difference between O(log n) and O(n) time complexity.',
    back: 'O(log n) cuts the search space in half with every step (e.g. Binary Search in a sorted array). O(n) scales linearly where doubling input items doubles execution time.',
    formulaOrExample: `Binary Search on 1,000,000 items takes ~20 operations (log2(10^6) ≈ 20).`,
    mastered: false
  },
  {
    id: 'fc-h1',
    subject: 'History & Social Studies',
    category: 'Political Philosophy',
    front: 'What is John Locke\'s concept of the "Social Contract"?',
    back: 'Government derives legitimate authority solely from the consent of the governed. Citizens surrender certain liberties in exchange for state protection of their natural rights: life, liberty, and property.',
    formulaOrExample: `Foundational justification for the American and French Revolutions.`,
    mastered: false
  },
  {
    id: 'fc-l1',
    subject: 'Literature & Philosophy',
    category: 'Rhetoric',
    front: 'What are the 3 Classical Rhetorical Appeals defined by Aristotle?',
    back: '1. Ethos: Appeal to credibility, character, and ethics.\n2. Pathos: Appeal to emotion, empathy, and audience feeling.\n3. Logos: Appeal to logic, evidence, data, and structured reasoning.',
    formulaOrExample: `An effective essay or speech synthesizes all 3 appeals.`,
    mastered: true
  },
  {
    id: 'fc-e1',
    subject: 'Economics & Business',
    category: 'Macroeconomics',
    front: 'What is Opportunity Cost?',
    back: 'The loss of potential gain from other alternatives when one alternative is chosen. It represents the value of the next best foregone option.',
    formulaOrExample: `Opportunity Cost = Return on Best Forgone Option - Return on Chosen Option`,
    mastered: false
  },
  {
    id: 'fc-eng1',
    subject: 'Engineering',
    category: 'Mechanics & Circuits',
    front: 'What is Young\'s Modulus (E) and what does it tell an engineer?',
    back: 'Young\'s Modulus E = σ / ε (stress divided by strain) quantifies a material\'s tensile stiffness in the linear elastic region.',
    formulaOrExample: `σ = E · ε  (Hooke's Law in elasticity; higher E means stiffer material)`,
    mastered: false
  },
  {
    id: 'fc-gen1',
    subject: 'General Academia',
    category: 'Research Methodology',
    front: 'What is the difference between a Type I Error (α) and a Type II Error (β)?',
    back: 'Type I Error (False Positive): Rejecting a true null hypothesis H0.\nType II Error (False Negative): Failing to reject a false null hypothesis H0.',
    formulaOrExample: `α = P(Reject H0 | H0 is True),   Power = 1 - β`,
    mastered: false
  }
];

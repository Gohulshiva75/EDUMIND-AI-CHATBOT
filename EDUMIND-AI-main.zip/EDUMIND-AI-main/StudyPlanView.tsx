import React, { useState, useEffect } from 'react';
import { 
  CalendarDays, 
  Sparkles, 
  CheckCircle2, 
  Circle, 
  Clock, 
  BookOpen, 
  Download, 
  Flame, 
  Layers, 
  ArrowRight,
  Plus
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { StudyPlan, StudyPlanModule, StudentProfile } from '../../types';
import { StudyPlanFactory } from '../../architecture/patterns';
import { generateStudyPlan } from '../../services/api';

interface StudyPlanViewProps {
  studentProfile: StudentProfile;
  onUpdateProfile: (updated: Partial<StudentProfile>) => void;
  onStartTopicInChat: (topic: string) => void;
}

export const StudyPlanView: React.FC<StudyPlanViewProps> = ({
  studentProfile,
  onUpdateProfile,
  onStartTopicInChat,
}) => {
  const [currentPlan, setCurrentPlan] = useState<StudyPlan>(
    StudyPlanFactory.createDefaultPlanForSubject(studentProfile.activeSubject)
  );
  const [isGenerating, setIsGenerating] = useState(false);
  const [showCreatorModal, setShowCreatorModal] = useState(false);

  // Form states for creating custom study plan
  const [customSubject, setCustomSubject] = useState<string>(studentProfile.activeSubject);
  const [customLevel, setCustomLevel] = useState<'Beginner' | 'Intermediate' | 'Advanced'>('Intermediate');
  const [customDays, setCustomDays] = useState(14);
  const [customDailyHours, setCustomDailyHours] = useState(2);
  const [customGoal, setCustomGoal] = useState('Ace college midterm/final exam with deep first-principles intuition');

  useEffect(() => {
    setCurrentPlan(StudyPlanFactory.createDefaultPlanForSubject(studentProfile.activeSubject));
    setCustomSubject(studentProfile.activeSubject);
  }, [studentProfile.activeSubject]);

  // Calculate overall progress
  const allModules = currentPlan.phases.flatMap(p => p.modules);
  const completedCount = allModules.filter(m => m.completed).length;
  const progressPercent = allModules.length > 0 ? Math.round((completedCount / allModules.length) * 100) : 0;

  const handleToggleModule = (phaseNumber: number, day: number) => {
    setCurrentPlan(prev => {
      const updatedPhases = prev.phases.map(phase => {
        if (phase.phaseNumber !== phaseNumber) return phase;
        return {
          ...phase,
          modules: phase.modules.map(mod => {
            if (mod.day !== day) return mod;
            const newStatus = !mod.completed;
            if (newStatus) {
              // Trigger celebratory confetti
              confetti({
                particleCount: 60,
                spread: 70,
                origin: { y: 0.7 },
                colors: ['#6366f1', '#a855f7', '#06b6d4', '#10b981'],
              });
              // Update student profile stats
              onUpdateProfile({
                completedTasksCount: (studentProfile.completedTasksCount || 0) + 1,
                totalStudyMinutes: (studentProfile.totalStudyMinutes || 0) + mod.estimatedMinutes,
              });
            }
            return { ...mod, completed: newStatus };
          }),
        };
      });

      return { ...prev, phases: updatedPhases };
    });
  };

  const handleCreatePlan = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsGenerating(true);
    try {
      const generated = await generateStudyPlan({
        subject: customSubject,
        level: customLevel,
        targetDays: customDays,
        dailyHours: customDailyHours,
        goals: customGoal,
      });
      setCurrentPlan(generated);
      setShowCreatorModal(false);
      confetti({
        particleCount: 100,
        spread: 90,
        origin: { y: 0.6 },
      });
    } catch (err: any) {
      alert(`Error generating study plan: ${err.message}`);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleExportPlan = () => {
    const markdown = `# ${currentPlan.title}
Estimated Total Study Time: ${currentPlan.totalEstimatedHours} hours
Methodology: ${currentPlan.methodology}

## Overview
${currentPlan.overview}

${currentPlan.phases.map(phase => `
### ${phase.phaseName} (${phase.daysSpan})
*Focus: ${phase.focus}*

${phase.modules.map(m => `
- [${m.completed ? 'x' : ' '}] Day ${m.day}: ${m.topic} (${m.estimatedMinutes} min)
  - Description: ${m.description}
  - Objectives: ${m.learningObjectives.join(', ')}
  - Practice Task: ${m.practiceTask}
`).join('\n')}
`).join('\n')}

## Tips for Success
${currentPlan.tipsForSuccess.map(t => `- ${t}`).join('\n')}
`;

    const blob = new Blob([markdown], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `edumind-study-plan-${Date.now()}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="h-full flex flex-col bg-slate-950/60 overflow-hidden">
      {/* Top Banner */}
      <div className="p-4 border-b border-slate-800/80 bg-slate-900/60 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 flex items-center justify-center">
            <CalendarDays className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              Adaptive Study Planner
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">
                Design Thinking Milestones
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              Structured sprint roadmaps with active verification and daily checkboxes
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowCreatorModal(true)}
            className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white shadow-sm flex items-center gap-1.5 transition-all"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Generate New Sprint Plan</span>
          </button>

          <button
            onClick={handleExportPlan}
            className="px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700/60 flex items-center gap-1.5 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Plan</span>
          </button>
        </div>
      </div>

      {/* Progress & Summary Bar */}
      <div className="px-6 py-4 bg-slate-900/40 border-b border-slate-800/60">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-3">
          <div>
            <h3 className="text-base font-extrabold text-white tracking-tight">{currentPlan.title}</h3>
            <p className="text-xs text-slate-400 mt-0.5 max-w-3xl leading-relaxed">
              {currentPlan.overview}
            </p>
          </div>

          <div className="flex items-center gap-4 shrink-0 bg-slate-950/80 px-4 py-2 rounded-xl border border-slate-800">
            <div className="text-right">
              <span className="text-xs text-slate-400 block">Overall Mastery</span>
              <span className="text-lg font-black text-cyan-400">{progressPercent}%</span>
            </div>
            <div className="w-12 h-12 rounded-full border-4 border-slate-800 flex items-center justify-center relative">
              <span className="text-[11px] font-bold text-slate-200">
                {completedCount}/{allModules.length}
              </span>
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-slate-800/80 rounded-full h-2.5 overflow-hidden">
          <div
            className="bg-gradient-to-r from-cyan-500 via-indigo-500 to-emerald-400 h-2.5 rounded-full transition-all duration-500"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      {/* Roadmap List by Phase */}
      <div className="flex-1 overflow-y-auto p-6 space-y-8 max-w-5xl mx-auto w-full">
        {currentPlan.phases.map((phase) => (
          <div key={phase.phaseNumber} className="space-y-3">
            {/* Phase header */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-lg bg-indigo-500/20 text-indigo-300 font-bold text-xs flex items-center justify-center">
                  P{phase.phaseNumber}
                </span>
                <h4 className="text-sm font-bold text-white">{phase.phaseName}</h4>
                <span className="text-[11px] text-slate-400 font-normal">({phase.daysSpan})</span>
              </div>
              <span className="text-xs text-indigo-400 font-medium italic hidden sm:block">
                Focus: {phase.focus}
              </span>
            </div>

            {/* Modules Grid */}
            <div className="space-y-3">
              {phase.modules.map((mod) => (
                <div
                  key={mod.day}
                  className={`p-4 rounded-2xl border transition-all ${
                    mod.completed
                      ? 'bg-emerald-950/15 border-emerald-500/30 text-slate-300 shadow-sm'
                      : 'bg-slate-900/60 border-slate-800/80 text-slate-200 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3">
                      <button
                        onClick={() => handleToggleModule(phase.phaseNumber, mod.day)}
                        className="mt-0.5 shrink-0 text-slate-400 hover:text-emerald-400 transition-colors"
                        title={mod.completed ? 'Mark incomplete' : 'Mark completed (+XP)'}
                      >
                        {mod.completed ? (
                          <CheckCircle2 className="w-5 h-5 text-emerald-400 fill-emerald-500/20" />
                        ) : (
                          <Circle className="w-5 h-5 text-slate-500 hover:text-slate-300" />
                        )}
                      </button>

                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-indigo-300">Day {mod.day}:</span>
                          <h5 className={`text-sm font-bold ${mod.completed ? 'line-through text-slate-400' : 'text-white'}`}>
                            {mod.topic}
                          </h5>
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-mono">
                            ~{mod.estimatedMinutes}m
                          </span>
                        </div>
                        <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                          {mod.description}
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() => onStartTopicInChat(`Explain and quiz me on Day ${mod.day}: ${mod.topic}`)}
                      className="px-2.5 py-1 rounded-lg bg-indigo-500/15 hover:bg-indigo-500/25 text-indigo-300 border border-indigo-500/20 text-xs font-medium flex items-center gap-1 shrink-0 transition-colors"
                      title="Launch discussion with Edumind AI Tutor"
                    >
                      <Sparkles className="w-3 h-3 text-cyan-300" />
                      <span className="hidden sm:inline">Learn with Tutor</span>
                    </button>
                  </div>

                  {/* Learning Objectives & Practice Task */}
                  <div className="mt-3 pt-3 border-t border-slate-800/60 pl-8 grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                    <div>
                      <span className="text-[11px] font-semibold text-slate-400 block mb-1">
                        🎯 Key Objectives:
                      </span>
                      <ul className="space-y-1 text-slate-300">
                        {mod.learningObjectives.map((obj, i) => (
                          <li key={i} className="flex items-start gap-1.5">
                            <span className="text-indigo-400 text-xs">•</span>
                            <span>{obj}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <span className="text-[11px] font-semibold text-amber-400 block mb-1">
                        ⚡ Hands-on Practice Task:
                      </span>
                      <p className="text-slate-300 bg-slate-950 p-2 rounded-lg border border-slate-800/80 leading-relaxed font-mono text-[11px]">
                        {mod.practiceTask}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}

        {/* Tips for Success Card */}
        {currentPlan.tipsForSuccess?.length > 0 && (
          <div className="p-5 rounded-2xl bg-indigo-950/20 border border-indigo-500/20">
            <h4 className="text-xs font-bold text-indigo-300 uppercase tracking-wider mb-2 flex items-center gap-2">
              <Flame className="w-4 h-4 text-orange-400" /> Tips for Study Success
            </h4>
            <ul className="space-y-1.5 text-xs text-slate-300">
              {currentPlan.tipsForSuccess.map((tip, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="text-indigo-400">•</span>
                  <span>{tip}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {/* Custom Study Plan Modal */}
      {showCreatorModal && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-cyan-400" />
                Generate Tailored AI Study Sprint
              </h3>
              <button
                onClick={() => setShowCreatorModal(false)}
                className="text-slate-400 hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreatePlan} className="space-y-4 text-xs">
              <div>
                <label className="font-semibold text-slate-300 block mb-1">Subject / Curriculum Target</label>
                <input
                  type="text"
                  value={customSubject}
                  onChange={(e) => setCustomSubject(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white outline-none focus:border-cyan-500"
                  required
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="font-semibold text-slate-300 block mb-1">Current Level</label>
                  <select
                    value={customLevel}
                    onChange={(e: any) => setCustomLevel(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white outline-none"
                  >
                    <option value="Beginner">Beginner</option>
                    <option value="Intermediate">Intermediate</option>
                    <option value="Advanced">Advanced</option>
                  </select>
                </div>

                <div>
                  <label className="font-semibold text-slate-300 block mb-1">Sprint Days</label>
                  <input
                    type="number"
                    min="3"
                    max="60"
                    value={customDays}
                    onChange={(e) => setCustomDays(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white outline-none"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-300 block mb-1">Hours / Day</label>
                  <input
                    type="number"
                    min="0.5"
                    max="10"
                    step="0.5"
                    value={customDailyHours}
                    onChange={(e) => setCustomDailyHours(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-300 block mb-1">Specific Goals or Upcoming Exam</label>
                <textarea
                  value={customGoal}
                  onChange={(e) => setCustomGoal(e.target.value)}
                  rows={2}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white outline-none focus:border-cyan-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowCreatorModal(false)}
                  className="px-4 py-2 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isGenerating}
                  className="px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-semibold flex items-center gap-1.5 disabled:opacity-50"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>{isGenerating ? 'Building Plan with Gemini...' : 'Generate Plan'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

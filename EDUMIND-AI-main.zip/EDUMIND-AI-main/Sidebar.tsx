import React from 'react';
import { 
  MessageSquare, 
  FlaskConical, 
  Lightbulb, 
  CalendarDays, 
  Award, 
  Timer, 
  BarChart3,
  Sparkles,
  ChevronRight,
  FileCheck2
} from 'lucide-react';

export type NavTab = 
  | 'chat'
  | 'testModule'
  | 'problemLab'
  | 'designThinking'
  | 'studyPlan'
  | 'quiz'
  | 'pomodoro'
  | 'analytics';

interface SidebarProps {
  activeTab: NavTab;
  onTabChange: (tab: NavTab) => void;
  activeSubject: string;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, onTabChange, activeSubject }) => {
  const navItems = [
    {
      id: 'chat' as NavTab,
      label: 'AI Tutor & Doubts',
      sublabel: `Tutor for ${activeSubject}`,
      icon: MessageSquare,
      color: 'text-indigo-400',
      activeBg: 'bg-indigo-600/15 border-indigo-500/40 text-indigo-300',
    },
    {
      id: 'testModule' as NavTab,
      label: 'Subject Test Center',
      sublabel: 'Timed Tests, Marks & Graphs',
      icon: FileCheck2,
      color: 'text-violet-400',
      activeBg: 'bg-violet-600/15 border-violet-500/40 text-violet-300',
    },
    {
      id: 'problemLab' as NavTab,
      label: 'Problem Lab & Solver',
      sublabel: 'Step-by-Step Derivations & Checks',
      icon: FlaskConical,
      color: 'text-amber-400',
      activeBg: 'bg-amber-600/15 border-amber-500/40 text-amber-300',
    },
    {
      id: 'designThinking' as NavTab,
      label: 'Design Thinking Studio',
      sublabel: '5-Phase Problem Solving Engine',
      icon: Lightbulb,
      color: 'text-emerald-400',
      activeBg: 'bg-emerald-600/15 border-emerald-500/40 text-emerald-300',
    },
    {
      id: 'studyPlan' as NavTab,
      label: 'Adaptive Study Planner',
      sublabel: 'Custom Sprints for Any Subject',
      icon: CalendarDays,
      color: 'text-cyan-400',
      activeBg: 'bg-cyan-600/15 border-cyan-500/40 text-cyan-300',
    },
    {
      id: 'quiz' as NavTab,
      label: 'Quizzes & Flashcards',
      sublabel: 'Active Recall across All Disciplines',
      icon: Award,
      color: 'text-purple-400',
      activeBg: 'bg-purple-600/15 border-purple-500/40 text-purple-300',
    },
    {
      id: 'pomodoro' as NavTab,
      label: 'Focus Timer & Ambience',
      sublabel: 'Pomodoro + Web Audio Soundscapes',
      icon: Timer,
      color: 'text-rose-400',
      activeBg: 'bg-rose-600/15 border-rose-500/40 text-rose-300',
    },
    {
      id: 'analytics' as NavTab,
      label: 'Mastery & Growth',
      sublabel: 'Holistic Academic Competencies',
      icon: BarChart3,
      color: 'text-sky-400',
      activeBg: 'bg-sky-600/15 border-sky-500/40 text-sky-300',
    },
  ];

  return (
    <aside className="w-64 lg:w-72 border-r border-slate-800/80 bg-slate-950/60 backdrop-blur-xl flex flex-col justify-between p-3 select-none shrink-0 h-[calc(100vh-4rem)]">
      {/* Top Nav List */}
      <div className="space-y-1">
        <div className="px-3 py-2 text-[11px] font-semibold tracking-wider uppercase text-slate-400 flex items-center justify-between">
          <span>Student Workspace</span>
          <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
        </div>

        <nav className="space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => onTabChange(item.id)}
                className={`w-full text-left px-3 py-2.5 rounded-xl text-xs font-medium border transition-all flex items-center justify-between group ${
                  isActive
                    ? `${item.activeBg} shadow-sm font-semibold`
                    : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 transition-colors ${
                      isActive
                        ? 'bg-slate-900/80 ring-1 ring-white/10'
                        : 'bg-slate-900/40 group-hover:bg-slate-800'
                    }`}
                  >
                    <Icon className={`w-4 h-4 ${item.color}`} />
                  </div>
                  <div className="truncate">
                    <p className={`truncate ${isActive ? 'text-white' : 'text-slate-300 group-hover:text-white'}`}>
                      {item.label}
                    </p>
                    <p className="text-[10px] text-slate-400 truncate font-normal">
                      {item.sublabel}
                    </p>
                  </div>
                </div>

                <ChevronRight
                  className={`w-3.5 h-3.5 shrink-0 transition-transform ${
                    isActive ? 'text-white translate-x-0.5' : 'text-slate-600 opacity-0 group-hover:opacity-100'
                  }`}
                />
              </button>
            );
          })}
        </nav>
      </div>

      {/* Bottom Cognitive Card: Design Thinking Tip */}
      <div className="p-3.5 rounded-2xl bg-gradient-to-br from-indigo-950/40 to-slate-900/80 border border-indigo-500/20 text-xs text-slate-300 relative overflow-hidden">
        <div className="absolute -right-4 -bottom-4 w-20 h-20 bg-indigo-500/10 rounded-full blur-xl pointer-events-none" />
        <div className="flex items-center gap-2 mb-1.5 font-semibold text-indigo-300">
          <Lightbulb className="w-4 h-4 text-amber-400" />
          <span>Design Thinking in Academia</span>
        </div>
        <p className="text-[11px] text-slate-400 leading-relaxed">
          "Empathize with why a question is difficult, define the core unknown, and test small prototypes before finalizing your answer."
        </p>
      </div>
    </aside>
  );
};

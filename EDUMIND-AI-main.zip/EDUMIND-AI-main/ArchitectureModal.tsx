import React, { useState, useEffect } from 'react';
import { 
  X, 
  Layers, 
  Cpu, 
  Lightbulb, 
  Code2,
  GitBranch,
  Repeat,
  Terminal
} from 'lucide-react';
import { bootPythonFrontendEngine, getLoadedPythonEngineSource } from '../utils/pythonEngine';

interface ArchitectureModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ArchitectureModal: React.FC<ArchitectureModalProps> = ({ isOpen, onClose }) => {
  const [activeSection, setActiveSection] = useState<'pythonStack' | 'patterns' | 'designThinking' | 'streams'>('pythonStack');
  const [pythonSource, setPythonSource] = useState<string>('');

  useEffect(() => {
    if (isOpen) {
      const cached = getLoadedPythonEngineSource();
      if (cached) {
        setPythonSource(cached);
      } else {
        bootPythonFrontendEngine()
          .then(() => setPythonSource(getLoadedPythonEngineSource()))
          .catch(() => {});
      }
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700/80 rounded-3xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="p-5 border-b border-slate-800 bg-slate-950/70 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-amber-500 to-emerald-400 flex items-center justify-center text-white shadow-md">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                Under-The-Hood Architecture Engine
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  Java OOP & Design Thinking Implemented via Code
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Core architectural logic, GoF design patterns, and cognitive pipelines powering Edumind AI
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switch */}
        <div className="px-6 py-2.5 bg-slate-950 border-b border-slate-800 flex flex-wrap items-center gap-2 text-xs">
          <button
            onClick={() => setActiveSection('pythonStack')}
            className={`px-3.5 py-1.5 rounded-xl font-semibold flex items-center gap-1.5 transition-all ${
              activeSection === 'pythonStack'
                ? 'bg-emerald-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>Python + React & Node.js</span>
          </button>

          <button
            onClick={() => setActiveSection('patterns')}
            className={`px-3.5 py-1.5 rounded-xl font-semibold flex items-center gap-1.5 transition-all ${
              activeSection === 'patterns'
                ? 'bg-amber-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Cpu className="w-3.5 h-3.5" />
            <span>GoF Design Patterns</span>
          </button>

          <button
            onClick={() => setActiveSection('designThinking')}
            className={`px-3.5 py-1.5 rounded-xl font-semibold flex items-center gap-1.5 transition-all ${
              activeSection === 'designThinking'
                ? 'bg-indigo-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Lightbulb className="w-3.5 h-3.5" />
            <span>Design Thinking 5-Phase Pipeline</span>
          </button>

          <button
            onClick={() => setActiveSection('streams')}
            className={`px-3.5 py-1.5 rounded-xl font-semibold flex items-center gap-1.5 transition-all ${
              activeSection === 'streams'
                ? 'bg-cyan-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Repeat className="w-3.5 h-3.5" />
            <span>Java Streams API Engine</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-xs text-slate-300">
          {activeSection === 'pythonStack' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-emerald-950/25 border border-emerald-500/30 space-y-2">
                <h3 className="text-sm font-bold text-emerald-300">
                  Full-Stack Split: Python + React Frontend & Node.js Chatbot Backend
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  <strong>Frontend (React 19 + Python 3 via Pyodide WebAssembly):</strong> React renders the UI while <code className="text-emerald-300">/python/edumind_engine.py</code> + <code className="text-emerald-300">Matplotlib</code> + <code className="text-emerald-300">NumPy</code> execute subject classification, test grading, quiz scoring, mastery calibration, competency radar charts, and Problem Lab verification directly in Python inside your browser.
                </p>
                <p className="text-xs text-slate-300 leading-relaxed">
                  <strong>Backend (Node.js + Express in server.ts):</strong> Streams real-time AI chatbot tutoring responses (<code className="text-cyan-300">POST /api/chat</code>), study plans, problem critiques, and custom AI tests via the Gemini SDK.
                </p>
              </div>

              <div className="rounded-xl bg-slate-950 border border-slate-800 overflow-hidden">
                <div className="px-3 py-2 bg-slate-900 border-b border-slate-800 flex items-center justify-between text-[11px]">
                  <span className="font-mono text-emerald-300 font-semibold">/public/python/edumind_engine.py</span>
                  <span className="text-slate-400">Active Browser Python Module</span>
                </div>
                <pre className="p-4 text-[11px] font-mono text-cyan-200/90 overflow-x-auto max-h-80 leading-relaxed">
                  <code>{pythonSource || '# Initializing Python 3 runtime (/python/edumind_engine.py)...'}</code>
                </pre>
              </div>
            </div>
          )}

          {activeSection === 'patterns' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-amber-950/20 border border-amber-500/20">
                <h3 className="text-sm font-bold text-amber-300 mb-1">
                  1. Gang of Four (GoF) Java Architectural Patterns
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  The Edumind AI codebase implements classical Java Object-Oriented patterns to manage all academic disciplines cleanly, loosely coupled, and extensibly.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                  <span className="font-bold text-white text-xs flex items-center gap-1.5 text-amber-400">
                    <GitBranch className="w-4 h-4" /> Strategy Pattern (`ITutoringStrategy`)
                  </span>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Decouples pedagogical delivery modes at runtime:
                  </p>
                  <pre className="p-2.5 bg-slate-900 rounded-lg font-mono text-[10px] text-emerald-300/90 overflow-x-auto">
{`interface ITutoringStrategy {
  formatResponseHeader(subject, topic): string;
  getSuggestedPills(subject): string[];
}
class SocraticStrategy implements ITutoringStrategy { ... }
class ConceptualDeepDiveStrategy implements ITutoringStrategy { ... }
class ExamDrillStrategy implements ITutoringStrategy { ... }
class DesignThinkingProblemStrategy implements ITutoringStrategy { ... }`}
                  </pre>
                </div>

                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                  <span className="font-bold text-white text-xs flex items-center gap-1.5 text-cyan-400">
                    <Code2 className="w-4 h-4" /> Builder & Factory Patterns
                  </span>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Creational abstractions for multi-week syllabi across any academic subject:
                  </p>
                  <pre className="p-2.5 bg-slate-900 rounded-lg font-mono text-[10px] text-emerald-300/90 overflow-x-auto">
{`class StudyPlanBuilder {
  setTitle(title): this;
  setSubject(subject): this;
  addPhase(num, name, focus, span, modules): this;
  build(): StudyPlan;
}
class StudyPlanFactory {
  createDefaultPlanForSubject(subject): StudyPlan;
}`}
                  </pre>
                </div>

                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                  <span className="font-bold text-white text-xs flex items-center gap-1.5 text-indigo-400">
                    <Repeat className="w-4 h-4" /> Observer Pattern (`LearningEventDispatcher`)
                  </span>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Event-driven decoupling of learning actions from profile updates:
                  </p>
                  <pre className="p-2.5 bg-slate-900 rounded-lg font-mono text-[10px] text-emerald-300/90 overflow-x-auto">
{`interface ILearningObserver {
  onLearningEvent(event, profile): Partial<StudentProfile>;
}
class StreakCounterObserver implements ILearningObserver { ... }
class MasteryScoreObserver implements ILearningObserver { ... }`}
                  </pre>
                </div>

                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                  <span className="font-bold text-white text-xs flex items-center gap-1.5 text-purple-400">
                    <Layers className="w-4 h-4" /> Chain of Responsibility Pattern
                  </span>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Passes student inquiries through cognitive classification handlers:
                  </p>
                  <pre className="p-2.5 bg-slate-900 rounded-lg font-mono text-[10px] text-emerald-300/90 overflow-x-auto">
{`SubjectClassifierHandler 
  -> CognitiveBloomHandler 
  -> DesignThinkingContextEnricher`}
                  </pre>
                </div>
              </div>
            </div>
          )}

          {activeSection === 'designThinking' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-emerald-950/20 border border-emerald-500/20">
                <h3 className="text-sm font-bold text-emerald-300 mb-1">
                  2. Design Thinking 5-Phase Cognitive Pipeline (`DesignThinkingPipeline`)
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  The core logic executes Stanford d.school's 5 phases (Empathize, Define, Ideate, Prototype, Test) to break down every academic inquiry.
                </p>
              </div>

              <div className="space-y-3">
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-start gap-3">
                  <span className="w-6 h-6 rounded-lg bg-indigo-500/20 text-indigo-400 font-bold text-xs flex items-center justify-center shrink-0">1</span>
                  <div>
                    <h4 className="font-bold text-indigo-300 text-xs">Phase 1: EMPATHIZE</h4>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      `DesignThinkingPipeline.empathize(profile, query, subject)` diagnoses whether the student is Confident, Struggling, Exam-Anxious, or Overwhelmed.
                    </p>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-start gap-3">
                  <span className="w-6 h-6 rounded-lg bg-cyan-500/20 text-cyan-400 font-bold text-xs flex items-center justify-center shrink-0">2</span>
                  <div>
                    <h4 className="font-bold text-cyan-300 text-xs">Phase 2: DEFINE</h4>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      `DesignThinkingPipeline.define(query, empathy, subject)` translates raw confusion into a structured "How Might We" (HMW) problem statement.
                    </p>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-start gap-3">
                  <span className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-400 font-bold text-xs flex items-center justify-center shrink-0">3</span>
                  <div>
                    <h4 className="font-bold text-amber-300 text-xs">Phase 3: IDEATE</h4>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      `DesignThinkingPipeline.ideate(...)` brainstorms multiple pedagogical avenues (Physical Analogy, Step-by-Step Derivation, Misconception Trap).
                    </p>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-start gap-3">
                  <span className="w-6 h-6 rounded-lg bg-purple-500/20 text-purple-400 font-bold text-xs flex items-center justify-center shrink-0">4</span>
                  <div>
                    <h4 className="font-bold text-purple-300 text-xs">Phase 4: PROTOTYPE</h4>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      `DesignThinkingPipeline.createPrototype(...)` builds a minimal worked example, mathematical model, or thesis wireframe.
                    </p>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-start gap-3">
                  <span className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-400 font-bold text-xs flex items-center justify-center shrink-0">5</span>
                  <div>
                    <h4 className="font-bold text-emerald-300 text-xs">Phase 5: TEST</h4>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      `DesignThinkingPipeline.test(...)` formulates a verification question and rubric to validate retention and active recall.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeSection === 'streams' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-cyan-950/20 border border-cyan-500/20">
                <h3 className="text-sm font-bold text-cyan-300 mb-1">
                  3. Java Streams API Engine (`src/architecture/javaStream.ts`)
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Demonstrates the Java 8+ `java.util.stream.Stream` functional pipeline in TypeScript, powering internal flashcard filtering, mastery calculation, and study schedule sorting.
                </p>
              </div>

              <pre className="p-4 bg-slate-950 rounded-xl font-mono text-[11px] text-emerald-300/90 leading-relaxed border border-slate-800 overflow-x-auto">
{`// JavaStream<T> implementation:
export class JavaStream<T> {
  public static of<T>(...items: T[]): JavaStream<T>;
  public static from<T>(iterable: Iterable<T>): JavaStream<T>;

  // Intermediate operations:
  public filter(predicate: (item: T) => boolean): JavaStream<T>;
  public map<R>(mapper: (item: T) => R): JavaStream<R>;
  public flatMap<R>(mapper: (item: T) => R[]): JavaStream<R>;
  public distinct(): JavaStream<T>;
  public sorted(comparator?: (a: T, b: T) => number): JavaStream<T>;

  // Terminal operations:
  public collect(): T[];
  public reduce<U>(identity: U, accumulator: (acc: U, item: T) => U): U;
  public anyMatch(predicate: (item: T) => boolean): boolean;
  public count(): number;
}

// Example usage in Edumind AI:
const topCards = JavaStream.from(allFlashcards)
  .filter(c => c.subject === activeSubject)
  .filter(c => !c.mastered)
  .sorted((a, b) => a.category.localeCompare(b.category))
  .collect();`}
              </pre>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-xl text-xs transition-colors"
          >
            Got it, return to Student Workspace
          </button>
        </div>
      </div>
    </div>
  );
};

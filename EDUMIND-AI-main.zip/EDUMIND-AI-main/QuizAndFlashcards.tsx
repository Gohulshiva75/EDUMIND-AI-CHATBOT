import React, { useState, useEffect } from 'react';
import { 
  Award, 
  Sparkles, 
  RotateCw, 
  CheckCircle2, 
  XCircle, 
  HelpCircle, 
  ChevronLeft, 
  ChevronRight, 
  BookOpen, 
  Layers, 
  MessageSquare,
  Check,
  RotateCcw,
  GraduationCap
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { ALL_SUBJECTS_FLASHCARDS } from '../../architecture/academicCurriculum';
import { CURATED_SUBJECT_TESTS } from '../../architecture/subjectTestsData';
import { Flashcard, QuizQuestion, StudentProfile, AcademicSubject } from '../../types';
import { generateQuiz } from '../../services/api';
import { JavaStream } from '../../architecture/javaStream';
import { evaluateQuizWithPython, calibrateMasteryWithPython } from '../../utils/pythonEngine';

interface QuizAndFlashcardsProps {
  studentProfile: StudentProfile;
  onUpdateProfile: (updated: Partial<StudentProfile>) => void;
  onAskTutor: (query: string) => void;
}

export const QuizAndFlashcards: React.FC<QuizAndFlashcardsProps> = ({
  studentProfile,
  onUpdateProfile,
  onAskTutor,
}) => {
  const [activeTab, setActiveTab] = useState<'flashcards' | 'quiz'>('flashcards');
  const [subjectFilter, setSubjectFilter] = useState<string>('All');

  // Flashcards state
  const [allCards, setAllCards] = useState<Flashcard[]>(ALL_SUBJECTS_FLASHCARDS);
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);

  // Filter cards using JavaStream
  const filteredCards = JavaStream.from(allCards)
    .filter((card) => subjectFilter === 'All' || card.subject === subjectFilter)
    .collect();

  const safeIndex = currentCardIndex < filteredCards.length ? currentCardIndex : 0;
  const currentCard = filteredCards[safeIndex] || allCards[0];

  // Multi-Subject Quiz state
  const [quizQuestions, setQuizQuestions] = useState<QuizQuestion[]>([
    {
      id: 'q-default-1',
      subject: 'Mathematics',
      questionText: 'When finding extrema of a differentiable function f(x), what condition guarantees that a critical point c is a local minimum?',
      options: [
        'f\'(c) = 0 and f\'\'(c) < 0',
        'f\'(c) = 0 and f\'\'(c) > 0',
        'f\'(c) > 0 and f\'\'(c) = 0',
        'f(c) = 0'
      ],
      correctIndex: 1,
      explanation: 'By the Second Derivative Test, if f\'(c) = 0 and f\'\'(c) > 0, the curve is concave upward at c, creating a local minimum cup.',
      conceptTag: 'Calculus & Optimization'
    },
    {
      id: 'q-default-2',
      subject: 'Physics & Astronomy',
      questionText: 'According to the Second Law of Thermodynamics, why can no real heat engine achieve 100% Carnot efficiency?',
      options: [
        'Because friction converts all work into kinetic energy',
        'Because some heat energy must always be expelled to a cold reservoir to satisfy non-decreasing entropy',
        'Because mass is converted into dark matter',
        'Because gravity prevents adiabatic expansion'
      ],
      correctIndex: 1,
      explanation: 'Kelvin-Planck statement: It is impossible for any device operating on a cycle to receive heat from a single reservoir and produce an equivalent amount of work without heat rejection to a lower temperature sink.',
      conceptTag: 'Thermodynamics & Entropy'
    },
    {
      id: 'q-default-3',
      subject: 'Biology & Medicine',
      questionText: 'During cellular respiration, what direct mechanical process phosphorylates ADP into ATP at ATP Synthase?',
      options: [
        'Direct glycolytic substrate breakdown in the cytoplasm',
        'Proton-motive force (H+ gradient) rotating the F0 rotor subunit across the mitochondrial membrane',
        'Photolysis of water molecules inside the nucleus',
        'Active transport of glucose via sodium symport'
      ],
      correctIndex: 1,
      explanation: 'Chemiosmosis: H+ ions flowing down their electrochemical gradient rotate the F0 subunit of ATP Synthase, driving conformational changes in the F1 catalytic head to generate ATP.',
      conceptTag: 'Cellular Bioenergetics'
    }
  ]);

  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [isQuizSubmitted, setIsQuizSubmitted] = useState(false);
  const [isGeneratingQuiz, setIsGeneratingQuiz] = useState(false);
  const [quizTopic, setQuizTopic] = useState(`${studentProfile.activeSubject} Core Principles & Problems`);

  useEffect(() => {
    setSubjectFilter(studentProfile.activeSubject);
    setCurrentCardIndex(0);
    setIsFlipped(false);
    setQuizTopic(`${studentProfile.activeSubject} Core Principles & Problems`);
    const curated = CURATED_SUBJECT_TESTS[studentProfile.activeSubject];
    if (curated?.questions?.length) {
      setQuizQuestions(
        curated.questions.slice(0, 3).map((q) => ({
          id: q.id,
          subject: studentProfile.activeSubject,
          questionText: q.questionText,
          snippetOrFormula: q.snippetOrFormula,
          options: q.options,
          correctIndex: q.correctIndex,
          explanation: q.explanation,
          conceptTag: q.conceptTag,
        }))
      );
      setSelectedAnswers({});
      setIsQuizSubmitted(false);
    }
  }, [studentProfile.activeSubject]);

  const handleNextCard = () => {
    setIsFlipped(false);
    setCurrentCardIndex((prev) => (prev + 1) % filteredCards.length);
  };

  const handlePrevCard = () => {
    setIsFlipped(false);
    setCurrentCardIndex((prev) => (prev - 1 + filteredCards.length) % filteredCards.length);
  };

  const handleToggleMastered = () => {
    if (!currentCard) return;
    setAllCards((prev) =>
      prev.map((c) => (c.id === currentCard.id ? { ...c, mastered: !c.mastered } : c))
    );
  };

  const handleSelectOption = (questionId: string, optionIndex: number) => {
    if (isQuizSubmitted) return;
    setSelectedAnswers((prev) => ({ ...prev, [questionId]: optionIndex }));
  };

  const handleSubmitQuiz = async () => {
    setIsQuizSubmitted(true);
    const evalRes = await evaluateQuizWithPython(quizQuestions, selectedAnswers);
    const percent = evalRes.percentage;

    if (percent >= 70) {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
      });
    }

    // Calibrate mastery via Python frontend engine
    const newMastery = await calibrateMasteryWithPython(
      studentProfile.masteryScores,
      'QUIZ_SUBMITTED',
      percent
    );

    onUpdateProfile({
      masteryScores: newMastery,
      completedTasksCount: (studentProfile.completedTasksCount || 0) + 1,
    });
  };

  const handleGenerateNewQuiz = async () => {
    setIsGeneratingQuiz(true);
    try {
      const data = await generateQuiz(quizTopic, studentProfile.activeSubject, 'medium', 3);
      setQuizQuestions(data.questions);
      setSelectedAnswers({});
      setIsQuizSubmitted(false);
    } catch (err: any) {
      alert(`Quiz generation error: ${err.message}`);
    } finally {
      setIsGeneratingQuiz(false);
    }
  };

  return (
    <div className="h-full flex flex-col bg-slate-950/60 overflow-hidden">
      {/* Header */}
      <div className="p-4 border-b border-slate-800/80 bg-slate-900/60 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30 flex items-center justify-center">
            <Award className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              Active Recall & Testing Center
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-purple-500/10 text-purple-300 border border-purple-500/20">
                Phase 5 Verification
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              Interactive flashcards and adaptive diagnostic micro-quizzes across all disciplines
            </p>
          </div>
        </div>

        {/* Tab switch */}
        <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800">
          <button
            onClick={() => setActiveTab('flashcards')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'flashcards'
                ? 'bg-purple-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Flashcards Deck ({allCards.filter(c => c.mastered).length}/{allCards.length})
          </button>
          <button
            onClick={() => setActiveTab('quiz')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'quiz'
                ? 'bg-purple-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Diagnostic Quiz ({quizQuestions.length} Questions)
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto p-6 max-w-4xl mx-auto w-full">
        {/* Flashcards View */}
        {activeTab === 'flashcards' && (
          <div className="flex flex-col items-center justify-center min-h-[500px] space-y-6">
            {/* Subject Filter Bar */}
            <div className="flex items-center gap-2 overflow-x-auto w-full max-w-xl pb-1 no-scrollbar text-xs">
              <span className="text-slate-400 font-semibold shrink-0">Filter:</span>
              {[
                'All',
                'Mathematics',
                'Physics & Astronomy',
                'Chemistry & BioChem',
                'Biology & Medicine',
                'Computer Science & AI',
                'Economics & Business',
                'History & Social Studies',
                'Literature & Philosophy',
                'Engineering',
                'General Academia'
              ].map((subj) => (
                <button
                  key={subj}
                  onClick={() => {
                    setSubjectFilter(subj);
                    setCurrentCardIndex(0);
                    setIsFlipped(false);
                  }}
                  className={`px-2.5 py-1 rounded-lg shrink-0 transition-colors ${
                    subjectFilter === subj
                      ? 'bg-purple-600/30 text-purple-200 border border-purple-500/40 font-semibold'
                      : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
                  }`}
                >
                  {subj === 'All' ? 'All Subjects' : subj.split(' ')[0]}
                </button>
              ))}
            </div>

            <div className="flex items-center justify-between w-full max-w-xl text-xs text-slate-400">
              <span className="font-semibold text-purple-300">
                Card {safeIndex + 1} of {filteredCards.length}
              </span>
              <span className="px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-medium">
                {currentCard?.subject} • {currentCard?.category}
              </span>
            </div>

            {/* Flip Card Canvas */}
            {currentCard && (
              <div
                onClick={() => setIsFlipped(!isFlipped)}
                className="w-full max-w-xl min-h-[320px] rounded-3xl bg-gradient-to-br from-slate-900 via-slate-900 to-indigo-950/40 border border-slate-700/80 p-8 flex flex-col justify-between shadow-2xl cursor-pointer transition-all hover:border-purple-500/50 relative select-none"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-semibold text-purple-400 tracking-wider uppercase">
                    {isFlipped ? 'Answer & Academic Rationale' : 'Question / Concept Prompt'}
                  </span>
                  <span className="text-xs text-slate-500 flex items-center gap-1">
                    <RotateCw className="w-3.5 h-3.5" /> Click to flip
                  </span>
                </div>

                <div className="my-auto py-4">
                  {!isFlipped ? (
                    <h3 className="text-lg md:text-xl font-bold text-white text-center leading-relaxed">
                      {currentCard.front}
                    </h3>
                  ) : (
                    <div className="space-y-3">
                      <p className="text-sm text-slate-200 leading-relaxed whitespace-pre-wrap">
                        {currentCard.back}
                      </p>
                      {currentCard.formulaOrExample && (
                        <pre className="p-3 bg-slate-950/90 rounded-xl text-xs font-mono text-emerald-300/90 overflow-x-auto border border-slate-800">
                          <code>{currentCard.formulaOrExample}</code>
                        </pre>
                      )}
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-between text-xs pt-3 border-t border-slate-800/80">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleToggleMastered();
                    }}
                    className={`flex items-center gap-1.5 px-3 py-1 rounded-lg border transition-colors ${
                      currentCard.mastered
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                        : 'bg-slate-800/60 text-slate-400 border-slate-700 hover:text-slate-200'
                    }`}
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>{currentCard.mastered ? 'Mastered ✓' : 'Mark as Mastered'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onAskTutor(`Deep dive into this ${currentCard.subject} concept: ${currentCard.front}`);
                    }}
                    className="text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>Ask Tutor to Explain</span>
                  </button>
                </div>
              </div>
            )}

            {/* Navigation buttons */}
            <div className="flex items-center gap-4">
              <button
                onClick={handlePrevCard}
                className="p-3 rounded-2xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                onClick={() => setIsFlipped(!isFlipped)}
                className="px-6 py-2.5 rounded-2xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs flex items-center gap-2 shadow-lg shadow-purple-600/20 transition-all"
              >
                <RotateCw className="w-4 h-4" />
                <span>Flip Card</span>
              </button>
              <button
                onClick={handleNextCard}
                className="p-3 rounded-2xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        )}

        {/* Quiz View */}
        {activeTab === 'quiz' && (
          <div className="space-y-6">
            {/* Quiz Generator Toolbar */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2 flex-1 min-w-[200px]">
                <span className="font-semibold text-slate-400 shrink-0">Quiz Topic:</span>
                <input
                  type="text"
                  value={quizTopic}
                  onChange={(e) => setQuizTopic(e.target.value)}
                  placeholder="e.g. Calculus Derivatives, Quantum Mechanics, Le Chatelier, Game Theory"
                  className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white outline-none focus:border-purple-500"
                />
              </div>

              <button
                onClick={handleGenerateNewQuiz}
                disabled={isGeneratingQuiz}
                className="px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-semibold flex items-center gap-1.5 disabled:opacity-50 transition-all shadow-sm"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{isGeneratingQuiz ? 'Authoring Questions...' : 'Generate Adaptive Quiz'}</span>
              </button>
            </div>

            {/* Questions List */}
            <div className="space-y-6">
              {quizQuestions.map((q, qIndex) => {
                const userSelected = selectedAnswers[q.id];
                const isAnswered = userSelected !== undefined;

                return (
                  <div
                    key={q.id}
                    className="p-6 rounded-2xl bg-slate-900/70 border border-slate-800 shadow-sm space-y-4"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-start gap-3">
                        <span className="w-7 h-7 rounded-xl bg-purple-500/20 text-purple-300 font-bold text-xs flex items-center justify-center shrink-0">
                          Q{qIndex + 1}
                        </span>
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            {q.subject && (
                              <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-cyan-300 font-normal">
                                {q.subject}
                              </span>
                            )}
                            <span className="text-[10px] font-semibold uppercase tracking-wider text-purple-400">
                              {q.conceptTag}
                            </span>
                          </div>
                          <h4 className="text-sm font-bold text-white leading-relaxed">
                            {q.questionText}
                          </h4>
                        </div>
                      </div>
                    </div>

                    {/* Formula or snippet if present */}
                    {q.snippetOrFormula && (
                      <pre className="p-3 bg-slate-950 rounded-xl text-xs font-mono text-emerald-300/90 overflow-x-auto border border-slate-800">
                        <code>{q.snippetOrFormula}</code>
                      </pre>
                    )}

                    {/* Options list */}
                    <div className="space-y-2 pt-1">
                      {q.options.map((option, optIdx) => {
                        const isChosen = userSelected === optIdx;
                        const isCorrect = optIdx === q.correctIndex;

                        let optionStyle = 'bg-slate-950/70 border-slate-800 hover:border-slate-700 text-slate-300';
                        if (isQuizSubmitted) {
                          if (isCorrect) {
                            optionStyle = 'bg-emerald-950/30 border-emerald-500 text-emerald-200 font-semibold';
                          } else if (isChosen && !isCorrect) {
                            optionStyle = 'bg-rose-950/30 border-rose-500 text-rose-200';
                          }
                        } else if (isChosen) {
                          optionStyle = 'bg-purple-600/20 border-purple-500 text-purple-200 font-semibold';
                        }

                        return (
                          <button
                            key={optIdx}
                            onClick={() => handleSelectOption(q.id, optIdx)}
                            className={`w-full text-left p-3 rounded-xl border text-xs flex items-center justify-between gap-3 transition-all ${optionStyle}`}
                          >
                            <div className="flex items-center gap-3">
                              <span className="w-5 h-5 rounded-full border border-slate-700 flex items-center justify-center text-[10px] font-mono shrink-0">
                                {String.fromCharCode(65 + optIdx)}
                              </span>
                              <span>{option}</span>
                            </div>

                            {isQuizSubmitted && isCorrect && (
                              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                            )}
                            {isQuizSubmitted && isChosen && !isCorrect && (
                              <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                            )}
                          </button>
                        );
                      })}
                    </div>

                    {/* Answer Explanation once submitted */}
                    {isQuizSubmitted && (
                      <div className="mt-4 p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-indigo-300 flex items-center gap-1.5">
                            <HelpCircle className="w-3.5 h-3.5" /> Conceptual Explanation
                          </span>
                          <button
                            onClick={() => onAskTutor(`Explain why option ${String.fromCharCode(65 + q.correctIndex)} is correct for: "${q.questionText}" in ${q.subject || studentProfile.activeSubject}`)}
                            className="text-indigo-400 hover:text-indigo-300 font-medium"
                          >
                            Clarify with Tutor
                          </button>
                        </div>
                        <p className="text-slate-300 leading-relaxed">{q.explanation}</p>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Quiz Action Bar */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-xs text-slate-400">
                  {Object.keys(selectedAnswers).length} of {quizQuestions.length} answered
                </span>
              </div>

              {!isQuizSubmitted ? (
                <button
                  onClick={handleSubmitQuiz}
                  disabled={Object.keys(selectedAnswers).length === 0}
                  className="px-6 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-purple-600/30 transition-all disabled:opacity-40"
                >
                  <Check className="w-4 h-4" />
                  <span>Submit Quiz & Grade</span>
                </button>
              ) : (
                <button
                  onClick={() => {
                    setSelectedAnswers({});
                    setIsQuizSubmitted(false);
                  }}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Retake Quiz</span>
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
